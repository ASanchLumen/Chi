# chi-documentation

## Project setup

```
npm install
```

### Compiles and hot-reloads for development

```
npm run serve
```

### Compiles and minifies for production

```
npm run build

npm run generate:pr -> Pull Request
npm run generate:production -> Production
```

### Lints and fixes files

```
npm run lint
npm run lint:checker
npm run prettier
npm run prettier:checker
```
