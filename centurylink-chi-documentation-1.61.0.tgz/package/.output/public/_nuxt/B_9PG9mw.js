import{an as i,am as m}from"./DBXeQHmC.js";const p=(s,o)=>{const r=o.dynamicComputedProps,a=i("size",r.size,r.size!=="md"),e=m(o,[a]);return`<${s}${e}></${s}>`};export{p as snippet};
