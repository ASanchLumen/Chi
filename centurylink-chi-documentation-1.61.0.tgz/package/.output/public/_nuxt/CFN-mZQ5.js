import{_ as d}from"./BPxlMu2A.js";import{_ as c}from"./DpMnMTV9.js";import{_ as p}from"./DnPF01B5.js";import{e as i,c as u,o as s,a as r,b as n,d as o,i as _,w as a}from"./DBXeQHmC.js";import"./DS5ErHUP.js";import"./CFKeqgEC.js";import"./B1maN0n6.js";import"./DY7FbNsl.js";import"./DlAUqK2U.js";import"./Bo0goINO.js";import"./sH0GR7G2.js";import"./CdcsEwU-.js";import"./DDFyDyTO.js";const g=`var elem = document.getElementById('range01');
var rangeSlider = chi.rangeSlider(elem);
// do stuff
rangeSlider.dispose();`,h=`var elem = document.getElementById('range01');
var rangeSlider = chi.rangeSlider(elem);
var elem2 = document.getElementById('range02');
var rangeSlider2 = chi.rangeSlider(elem2);
rangeSlider === rangeSlider2; // returns true

rangeSlider.dispose(); // Only have to do it once.`,f=i({__name:"_properties",setup(l){return(m,e)=>{const t=p;return s(),u("div",null,[e[0]||(e[0]=r("h3",null,"Preventing memory leaks",-1)),e[1]||(e[1]=r("p",{class:"-text"},"Rangeslider component has a dispose function to free all the resources attached to the element, such as event listeners and object data. You should call this method when you want to remove the component.",-1)),n(t,{lang:"javascript",code:g}),e[2]||(e[2]=r("p",{class:"-text"},[o("It is safe to call the "),r("code",null,"rangeSlider"),o(" method more than once, as it will return any previously created rangeSlider component associated with the element.")],-1)),n(t,{lang:"javascript",code:h})])}}}),R=i({__name:"index",setup(l){return(m,e)=>{const t=d;return s(),_(t,{"hide-builder":"",title:"Range slider",description:"Range sliders are used for inputting numeric values within a range."},{examples:a(()=>[n(c)]),properties:a(()=>[n(f)]),_:1})}}});export{R as default};
