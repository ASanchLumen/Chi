import{_ as L}from"./DY7FbNsl.js";import{_ as m}from"./DnPF01B5.js";import{_ as f}from"./CdcsEwU-.js";import{e as p,i as _,o as u,w as n,b as a,B as b,k as s,a as h,c as T,F as w}from"./DBXeQHmC.js";const C={searchInput:!0,checkbox:!1,columns:{from:{title:"From",description:"Description from"},to:{title:"To",description:"Description to"}}},x={tooltipMsg:"Tooltip message",icon:"atom",title:"Tranfer List - Modal Title",ariaLabel:"custom aria label"},c=[{value:"first",label:"First",selected:!1,locked:!1,wildcard:!1},{value:"second",label:"Second",selected:!1,locked:!1,wildcard:!1},{value:"third",label:"Third",selected:!0,locked:!0,wildcard:!1},{value:"fourth",label:"Fourth",selected:!0,locked:!0,wildcard:!1},{value:"fifth",label:"Fifth",selected:!0,locked:!1,wildcard:!1},{value:"sixth",label:"Sixth",selected:!0,locked:!1,wildcard:!0},{value:"seventh",label:"Seventh",selected:!0,locked:!1,wildcard:!0}],$=o=>`list: [
`+o.map(e=>`    {
      value: '${e.value}',
      label: '${e.label}',
      selected: ${e.selected},
      locked: ${e.locked},
      wildcard: ${e.wildcard},
    }`).join(`,
`)+`,
  ]`,k=o=>!o||!Object.keys(o)?.length?"":`
  modal: {
`+Object.entries(o).map(([e,t])=>`    ${e}: '${t}',`).join(`
`)+`
  }`,v=(o=[],e=!1,t)=>`<!-- Vue component -->
<ChiTransferList
  :transferListData="list"
  :config="config"${e?`
  modal`:""}${t?`
  :modal="modal"`:""}
/>

<!-- Config and Data -->
data: {
  config: {
    searchInput: true,
    checkbox: false,
    columns: {
      from: {
        title: 'From',
        description: 'Description from',
      },
      to: {
        title: 'To',
        description: 'Description to',
      },
    },
  },
  ${$(o)}${k(t)}
}`,D=p({__name:"_base",setup(o){const e=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint",disabled:!0}],t={vue:v(c),webcomponent:""};return(l,g)=>{const i=b("ChiTransferList"),r=m,d=f;return u(),_(d,{title:"Base",id:"base",tabs:e},{example:n(()=>[a(i,{transferListData:s(c),config:s(C)},null,8,["transferListData","config"])]),"code-vue":n(()=>[a(r,{lang:"html",code:t.vue},null,8,["code"])]),_:1})}}}),S={class:"-d--flex"},B=p({__name:"_modal",setup(o){const e=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint",disabled:!0}],t={vue:v(c,!0),webcomponent:""};return(l,g)=>{const i=b("ChiTransferList"),r=m,d=f;return u(),_(d,{title:"Modal",id:"modal",tabs:e,additionalStyle:"position: static;"},{example:n(()=>[h("div",S,[a(i,{transferListData:s(c),config:l.config,modal:""},null,8,["transferListData","config"])])]),"code-vue":n(()=>[a(r,{lang:"html",code:t.vue},null,8,["code"])]),_:1})}}}),M={class:"-d--flex"},y=p({__name:"_modal-config",setup(o){const e=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint",disabled:!0}],t={vue:v(c,!1,x),webcomponent:""};return(l,g)=>{const i=b("ChiTransferList"),r=m,d=f;return u(),_(d,{title:"Modal with custom config",id:"modal-config",tabs:e,additionalStyle:"position: static;"},{example:n(()=>[h("div",M,[a(i,{transferListData:s(c),config:s(C),modal:s(x)},null,8,["transferListData","config","modal"])])]),"code-vue":n(()=>[a(r,{lang:"html",code:t.vue},null,8,["code"])]),_:1})}}}),H=p({__name:"index",setup(o){return(e,t)=>{const l=L;return u(),T(w,null,[t[0]||(t[0]=h("h2",null,"Examples",-1)),a(l,null,{default:n(()=>[a(D),a(B),a(y)]),_:1})],64)}}});export{H as _};
