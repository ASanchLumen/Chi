import{_ as S}from"./DY7FbNsl.js";import{_ as g}from"./DnPF01B5.js";import{_ as D}from"./Bo0goINO.js";import{_}from"./CdcsEwU-.js";import{e as v,q as x,i as w,o as p,w as r,b as i,a as e,d as s,c as f,F as T,r as y,H as $,k as A,S as C,Q as E}from"./DBXeQHmC.js";import{c as H}from"./CQ7Psw0x.js";const I={class:"-position--relative -z--0 -overflow--hidden",style:{height:"20rem"}},L={class:"-p--3"},M={class:"-text -mb--3"},J=v({__name:"_interaction",setup(b){const t=x(null),n=[{active:!0,id:"webcomponent",label:"Web Component"},{id:"vue",label:"Vue"},{id:"htmlblueprint",label:"HTML Blueprint"}],c={webcomponent:`<!-- Trigger -->
<chi-button id="example__interaction-trigger" variant="flat" type="icon">
  <chi-icon icon="menu" size="sm--2"></chi-icon>
</chi-button>

<!-- Drawer -->
<chi-drawer id="example__interaction" position="left" backdrop no-header>
  <div class="-p--2 -pt--6 -text">Drawer content here</div>
</chi-drawer>

<!-- JavaScript -->
<script>
  var drawer = document.getElementById('example__interaction');
  var drawerTrigger = document.getElementById('example__interaction-trigger');
  drawerTrigger.addEventListener('click', function() {
    drawer.toggle();
    // Or:
    // drawer.active = !drawer.active;
  });
<\/script>`,vue:`<!-- Trigger -->
<button class="chi-button -flat -icon" @click="() => toggleDrawer()">
  <i class="chi-icon -sm--2 icon-menu" aria-hidden="true"></i>
</button>

<!-- Vue component -->
<ChiDrawer
  position="left"
  :active="this.drawerActive"
  :noHeader="true"
  backdrop
>
  <div class="-p--2 -pt--6 -text">Drawer content here</div>
</ChiDrawer>

<!-- Data and Methods -->
data: {
  drawerActive : false;
},
methods: {
  toggleDrawer() {
    this.drawerActive = !this.drawerActive;
  }
}`,htmlblueprint:`<!-- Trigger -->
<button
  id="example__interaction-trigger"
  class="chi-button -flat -icon chi-drawer__trigger"
  data-target="#example__interaction"
  aria-label="Toggle navigation"
>
  <div class="chi-button__content">
    <i class="chi-icon -sm--2 icon-menu" aria-hidden="true"></i>
  </div>
</button>

<!-- Drawer -->
<div class="chi-backdrop -closed">
  <div class="chi-backdrop__wrapper">
    <div id="example__interaction" class="chi-drawer -left">
      <button class="chi-button -icon -close" aria-label="Close">
        <div class="chi-button__content">
          <i class="chi-icon icon-x" aria-hidden="true"></i>
        </div>
      </button>
      <div class="chi-drawer__content">
        <div class="-p--2 -pt--6 -text">Drawer content here</div>
      </div>
    </div>
  </div>
</div>

<!-- JavaScript -->
<script>chi.drawer(document.getElementById('example__interaction-trigger'));<\/script>`},l=()=>{t.value.toggle()};return(o,a)=>{const d=g,u=D,m=_;return p(),w(m,{title:"Interaction",id:"interaction",tabs:n,padding:"-p--0"},{"example-description":r(()=>[...a[0]||(a[0]=[e("p",{class:"-text"},[s("Read this handy introduction to "),e("a",{href:"/getting-started/installation"},"HTML attributes and DOM properties")],-1)])]),example:r(()=>[e("div",I,[e("div",L,[e("div",{class:"-d--flex -align-items--center"},[e("button",{class:"chi-button -icon -flat","aria-label":"Toggle drawer",onClick:l},[...a[1]||(a[1]=[e("div",{class:"chi-button__content"},[e("i",{class:"chi-icon icon-menu -sm--2","aria-hidden":"true"})],-1)])]),a[2]||(a[2]=e("b",{class:"-ml--2"},"Click menu button to open Drawer",-1))]),(p(),f(T,null,y(2,h=>e("p",M,"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus eu dignissim nisi, gravida pharetra elit. Etiam eu urna orci. Nulla et lorem eleifend, ultrices massa id, molestie urna. Nulla nec quam in turpis fermentum dictum vitae ac nibh. Suspendisse lacus nisi, sollicitudin in commodo quis, euismod id enim. Donec semper nunc et tellus convallis, tristique varius turpis gravida. Quisque hendrerit magna ac bibendum molestie. Nullam scelerisque libero vitae lorem dignissim ullamcorper. Integer mollis auctor enim vel molestie. Etiam id vestibulum augue, vitae dapibus quam. Nunc tincidunt aliquet lacus nec malesuada. Donec ultricies augue non lorem eleifend, eget ullamcorper lacus elementum. Donec condimentum enim nec justo auctor, nec bibendum ipsum dapibus.")),64))]),e("chi-drawer",{position:"left",backdrop:"","no-header":"",ref_key:"drawer",ref:t},[...a[3]||(a[3]=[e("div",{class:"-p--2 -pt--6 -text"},"Drawer content here",-1)])],512)])]),"code-webcomponent":r(()=>[a[4]||(a[4]=e("div",{class:"chi-tab__description"},[s("Modify the "),e("code",null,"active"),s(" attribute or property to make the drawer show or hide. "),e("code",null,"chi-drawer"),s(" also supports three public methods to change its visibility: "),e("code",null,"show()"),s(", "),e("code",null,"hide()"),s(", "),e("code",null,"toggle()"),s(".")],-1)),i(d,{lang:"html",code:c.webcomponent},null,8,["code"])]),"code-vue":r(()=>[a[5]||(a[5]=e("div",{class:"chi-tab__description"},[s("Modify the "),e("code",null,"active"),s(" property to make the drawer show or hide. "),e("code",null,"ChiDrawer"),s(" also supports three public methods to change its visibility: "),e("code",null,"show()"),s(", "),e("code",null,"hide()"),s(", "),e("code",null,"toggle()"),s(".")],-1)),i(d,{lang:"html",code:c.vue},null,8,["code"])]),"code-htmlblueprint":r(()=>[i(u),a[6]||(a[6]=e("div",{class:"chi-tab__description"},[s("Use the function "),e("code",null,"chi.drawer(elem)"),s(" to instantiate a new drawer component in the DOM element passed as a parameter. You must use the trigger element as the parameter.")],-1)),i(d,{lang:"html",code:c.htmlblueprint},null,8,["code"])]),_:1})}}}),V={class:"-position--relative -z--0 -overflow--hidden",style:{height:"30rem"}},N={class:"-p--3"},z={class:"-text -mb--1"},q=["position"],O=v({__name:"_position",setup(b){const t=x("left"),n=["left","right","top","bottom"].map(o=>({id:o,active:o==="left",label:H(o)})),c=[{active:!0,id:"webcomponent",label:"Web Component"},{id:"vue",label:"Vue"},{id:"htmlblueprint",label:"HTML Blueprint"}],l=$(()=>({webcomponent:`<!-- Trigger -->
<chi-button id="example__${t.value}-trigger" variant="flat" type="icon">
  <chi-icon icon="menu" size="sm--2"></chi-icon>
</chi-button>

<!-- Drawer -->
<chi-drawer id="example__${t.value}" position="${t.value}" no-header>
  <div class="-p--2 -pt--6 -text">Drawer content here</div>
</chi-drawer>

<!-- JavaScript -->
<script>
  var drawer = document.getElementById('example__${t.value}');
  var drawerTrigger = document.getElementById('example__${t.value}-trigger');
  drawerTrigger.addEventListener('click', function() {
    drawer.toggle();
    // Or:
    // drawer.active = !drawer.active;
  });
<\/script>`,vue:`<!-- Trigger -->
<button class="chi-button -flat -icon" @click="() => toggleDrawer()">
  <i class="chi-icon -sm--2 icon-menu" aria-hidden="true"></i>
</button>

<!-- Vue component -->
<ChiDrawer
  position="${t.value}"
  :active="this.drawerActive"
  :noHeader="true"
  backdrop
>
  <div class="-p--2 -pt--6 -text">Drawer content here</div>
</ChiDrawer>

<!-- Data and Methods -->
data: {
  drawerActive : false;
},
methods: {
  toggleDrawer() {
    this.drawerActive = !this.drawerActive;
  }
}`,htmlblueprint:`<!-- Trigger -->
<button id="example__${t.value}-trigger" class="chi-button -flat -icon chi-drawer__trigger" data-target="#example__${t.value}" aria-label="Toggle navigation">
  <div class="chi-button__content">
    <i class="chi-icon -sm--2 icon-menu" aria-hidden="true"></i>
  </div>
</button>

<!-- Drawer -->
<div id="example__${t.value}" class="chi-drawer -${t.value}">
  <button class="chi-button -icon -close" aria-label="Close">
    <div class="chi-button__content">
      <i class="chi-icon icon-x" aria-hidden="true"></i>
    </div>
  </button>
  <div class="chi-drawer__content">
    <div class="-p--2 -pt--6 -text">Drawer content here</div>
  </div>
</div>

<!-- JavaScript -->
<script>chi.drawer(document.getElementById('example__${t.value}-trigger'));<\/script>`}));return(o,a)=>{const d=g,u=D,m=_;return p(),w(m,{title:"Position",id:"position",tabs:c,"head-tabs":A(n),onChiHeadTabsChange:a[0]||(a[0]=h=>t.value=h.id),padding:"-p--0"},{example:r(()=>[e("div",V,[e("div",N,[(p(),f(T,null,y(3,h=>e("div",z,"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus eu dignissim nisi, gravida pharetra elit. Etiam eu urna orci. Nulla et lorem eleifend, ultrices massa id, molestie urna. Nulla nec quam in turpis fermentum dictum vitae ac nibh. Suspendisse lacus nisi, sollicitudin in commodo quis, euismod id enim. Donec semper nunc et tellus convallis, tristique varius turpis gravida. Quisque hendrerit magna ac bibendum molestie. Nullam scelerisque libero vitae lorem dignissim ullamcorper. Integer mollis auctor enim vel molestie. Etiam id vestibulum augue, vitae dapibus quam. Nunc tincidunt aliquet lacus nec malesuada. Donec ultricies augue non lorem eleifend, eget ullamcorper lacus elementum. Donec condimentum enim nec justo auctor, nec bibendum ipsum dapibus.")),64))]),e("chi-drawer",{position:t.value,active:"","prevent-auto-hide":"","no-header":""},[...a[1]||(a[1]=[e("div",{class:"-p--2 -pt--6 -text"},"Drawer content here",-1)])],8,q)])]),"code-webcomponent":r(()=>[i(d,{class:"html",lang:"html",code:l.value.webcomponent},null,8,["code"])]),"code-vue":r(()=>[i(d,{class:"html",lang:"html",code:l.value.vue},null,8,["code"])]),"code-htmlblueprint":r(()=>[i(u),i(d,{class:"html",lang:"html",code:l.value.htmlblueprint},null,8,["code"])]),_:1},8,["head-tabs"])}}}),W=v({__name:"_backdrop",setup(b){const t=[{active:!0,id:"webcomponent",label:"Web Component"},{id:"vue",label:"Vue"},{id:"htmlblueprint",label:"HTML Blueprint"}],n={webcomponent:`<!-- Trigger -->
<chi-button id="example__backdrop-trigger" variant="flat" type="icon">
  <chi-icon icon="menu" size="sm--2"></chi-icon>
</chi-button>

<!-- Drawer -->
<chi-drawer id="example__backdrop" position="bottom" backdrop no-header>
  <div class="-p--2 -pt--6 -text">Drawer content here</div>
</chi-drawer>

<!-- JavaScript -->
<script>
  var drawer = document.getElementById('example__backdrop');
  var drawerTrigger = document.getElementById('example__backdrop-trigger');
  drawerTrigger.addEventListener('click', function() {
    drawer.toggle();
    // Or:
    // drawer.active = !drawer.active;
  });
<\/script>`,vue:`<!-- Trigger -->
<button class="chi-button -flat -icon" @click="() => toggleDrawer()">
  <i class="chi-icon -sm--2 icon-menu" aria-hidden="true"></i>
</button>

<!-- Vue component -->
<ChiDrawer
  position="bottom"
  :active="this.drawerActive"
  :noHeader="true"
  backdrop
>
  <div class="-p--2 -pt--6 -text">Drawer content here</div>
</ChiDrawer>

<!-- Data and Methods -->
data: {
  drawerActive : false;
},
methods: {
  toggleDrawer() {
    this.drawerActive = !this.drawerActive;
  }
}`,htmlblueprint:`<!-- Trigger -->
<button
  id="example__backdrop-trigger"
  class="chi-button -flat -icon chi-drawer__trigger"
  data-target="#example__backdrop"
  aria-label="Toggle navigation"
>
  <div class="chi-button__content">
    <i class="chi-icon -sm--2 icon-menu" aria-hidden="true"></i>
  </div>
</button>

<!-- Drawer -->
<div class="chi-backdrop -closed">
  <div class="chi-backdrop__wrapper">
    <div id="example__backdrop" class="chi-drawer -bottom">
      <button class="chi-button -icon -close" aria-label="Close">
        <div class="chi-button__content">
          <i class="chi-icon icon-x" aria-hidden="true"></i>
        </div>
      </button>
      <div class="chi-drawer__content">
        <div class="-p--2 -pt--6 -text">Drawer content here</div>
      </div>
    </div>
  </div>
</div>

<!-- JavaScript -->
<script>chi.drawer(document.getElementById('example__backdrop-trigger'));<\/script>`};return(c,l)=>{const o=g,a=D,d=_;return p(),w(d,{title:"Backdrop",id:"backdrop",tabs:t,padding:"-p--0"},{"example-description":r(()=>[...l[0]||(l[0]=[e("p",{class:"-text"},"An optional backdrop can be added to focus the user's attention on drawer content.",-1)])]),example:r(()=>[...l[1]||(l[1]=[e("div",{class:"-position--relative -z--0 -overflow--hidden",style:{height:"30rem"}},[e("chi-drawer",{position:"bottom",backdrop:"",active:"","prevent-auto-hide":"","no-header":""},[e("div",{class:"-p--2 -pt--6 -text"},"Drawer content here")])],-1)])]),"code-webcomponent":r(()=>[i(o,{class:"html",lang:"html",code:n.webcomponent},null,8,["code"])]),"code-vue":r(()=>[i(o,{class:"html",lang:"html",code:n.vue},null,8,["code"])]),"code-htmlblueprint":r(()=>[i(a),i(o,{lang:"html",code:n.htmlblueprint},null,8,["code"])]),_:1})}}}),R=v({__name:"_titled",setup(b){const t=[{active:!0,id:"webcomponent",label:"Web Component"},{id:"vue",label:"Vue"},{id:"htmlblueprint",label:"HTML Blueprint"}],n={webcomponent:`<!-- Trigger -->
<chi-button id="example__titled-trigger" variant="flat" type="icon">
  <chi-icon icon="menu" size="sm--2"></chi-icon>
</chi-button>

<!-- Drawer -->
<chi-drawer id="example__titled" position="left" title="Drawer title here" backdrop>
  <div class="-p--2 -text">Drawer content here</div>
</chi-drawer>

<!-- JavaScript -->
<script>
  var drawer = document.getElementById('example__titled');
  var drawerTrigger = document.getElementById('example__titled-trigger');
  drawerTrigger.addEventListener('click', function() {
    drawer.toggle();
    // Or:
    // drawer.active = !drawer.active;
  });
<\/script>`,vue:`<!-- Trigger -->
<button class="chi-button -flat -icon" @click="() => toggleDrawer()">
  <i class="chi-icon -sm--2 icon-menu" aria-hidden="true"></i>
</button>

<!-- Vue component -->
<ChiDrawer
  position="left"
  :active="this.drawerActive"
  title="Drawer title here"
  backdrop
>
  <div class="-p--2 -text">Drawer content here</div>
</ChiDrawer>

<!-- Data and Methods -->
data: {
  drawerActive : false;
},
methods: {
  toggleDrawer() {
    this.drawerActive = !this.drawerActive;
  }
}`,htmlblueprint:`<!-- Trigger -->
<button id="example__titled-trigger" class="chi-button -flat -icon chi-drawer__trigger" data-target="#example__titled" aria-label="Toggle navigation">
  <div class="chi-button__content">
    <i class="chi-icon -sm--2 icon-menu" aria-hidden="true"></i>
  </div>
</button>

<!-- Drawer -->
<div class="chi-backdrop -closed">
  <div class="chi-backdrop__wrapper">
    <div id="example__titled" class="chi-drawer -left">
      <div class="chi-drawer__header">
        <span class="chi-drawer__title">
          Drawer title here
        </span>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="-p--2 -text">Drawer content here</div>
      </div>
    </div>
  </div>
</div>

<!-- JavaScript -->
<script>chi.drawer(document.getElementById('example__titled-trigger'));<\/script>`};return(c,l)=>{const o=g,a=D,d=_;return p(),w(d,{title:"Titled",id:"titled",tabs:t,padding:"-p--0"},{example:r(()=>[...l[0]||(l[0]=[e("div",{class:"-position--relative -z--0 -overflow--hidden",style:{height:"30rem"}},[e("chi-drawer",{position:"left",title:"Drawer title here",backdrop:"",active:"","prevent-auto-hide":""},[e("div",{class:"-p--2 -text"},"Drawer content here")])],-1)])]),"code-webcomponent":r(()=>[i(o,{class:"html",lang:"html",code:n.webcomponent},null,8,["code"])]),"code-vue":r(()=>[i(o,{class:"html",lang:"html",code:n.vue},null,8,["code"])]),"code-htmlblueprint":r(()=>[i(a),i(o,{lang:"html",code:n.htmlblueprint},null,8,["code"])]),_:1})}}}),j={class:"-position--relative -z--0 -overflow--hidden",style:{height:"15rem"}},F=["non-closable"],U=["innerHTML"],Q=["innerHTML"],P=v({__name:"_close-button",setup(b){const t=x(!0),n=x("closable"),c=d=>{t.value=d.id==="closable",n.value=d.id},l=[{active:!0,id:"closable",label:"Closable"},{id:"non-closable",label:"Non closable"}],o={closable:{webcomponent:{code:`<!-- Trigger -->
<chi-button id="example__close-button-trigger" variant="flat" type="icon">
  <chi-icon icon="menu" size="sm--2"></chi-icon>
</chi-button>

<!-- Drawer -->
<chi-drawer id="example__close-button" position="left" backdrop no-header>
  <div class="-p--2 -pt--6 -text">Drawer content here</div>
</chi-drawer>

<!-- JavaScript -->
<script>
  var drawer = document.getElementById('example__close-button');
  var drawerTrigger = document.getElementById('example__close-button-trigger');
  drawerTrigger.addEventListener('click', function() {
    drawer.toggle();
    // Or:
    // drawer.active = !drawer.active;
  });
<\/script>`},vue:{code:`<!-- Trigger -->
<button class="chi-button -flat -icon" @click="() => toggleDrawer()">
  <i class="chi-icon -sm--2 icon-menu" aria-hidden="true"></i>
</button>

<!-- Vue component -->
<ChiDrawer
  position="left"
  :active="this.drawerActive"
  @chiDrawerHide="() => (this.drawerActive = false)"
  @chiDrawerClickOutside="() => (this.drawerActive = false)"
  backdrop
>
  <div class="-p--2 -pt--6 -text">Drawer content here</div>
</ChiDrawer>

<!-- Data and Methods -->
data: {
  drawerActive : false;
},
methods: {
  toggleDrawer() {
    this.drawerActive = !this.drawerActive;
  }
}`,description:`Drawer visibility depends on the prop <code>active</code>.
            Chi Vue Drawer component does not automatically hide when the close button is clicked as prop mutation is an anti-pattern in Vue.
            Use the events <code>chiDrawerHide</code> and <code>chiDrawerClickOutside</code> to set <code>active</code> to false and hide the Drawer.`},htmlBlueprint:{code:`<!-- Trigger -->
<button id="example__close-button-trigger" class="chi-button -flat -icon chi-drawer__trigger" data-target="#example__close-button" aria-label="Toggle navigation">
  <div class="chi-button__content">
    <i class="chi-icon -sm--2 icon-menu" aria-hidden="true"></i>
  </div>
</button>

<!-- Drawer -->
<div class="chi-backdrop -closed">
  <div class="chi-backdrop__wrapper">
    <div id="example__close-button" class="chi-drawer -left">
      <button class="chi-button -icon -close" aria-label="Close">
        <div class="chi-button__content">
          <i class="chi-icon icon-x" aria-hidden="true"></i>
        </div>
      </button>
      <div class="chi-drawer__content">
        <div class="-p--2 -pt--6 -text">Drawer content here</div>
      </div>
    </div>
  </div>
</div>

<!-- JavaScript -->
<script>chi.drawer(document.getElementById('example__close-button-trigger'));<\/script>`}},"non-closable":{webcomponent:{code:`<!-- Trigger -->
<chi-button id="example__close-button-trigger" variant="flat" type="icon">
  <chi-icon icon="menu" size="sm--2"></chi-icon>
</chi-button>

<!-- Drawer -->
<chi-drawer id="example__close-button" position="left" backdrop non-closable no-header>
  <div class="-p--2 -pt--6 -text">Drawer content here</div>
</chi-drawer>

<!-- JavaScript -->
<script>
  var drawer = document.getElementById('example__close-button');
  var drawerTrigger = document.getElementById('example__close-button-trigger');
  drawerTrigger.addEventListener('click', function() {
    drawer.toggle();
    // Or:
    // drawer.active = !drawer.active;
  });
<\/script>`,description:"Use the <code>non-closable</code> attribute to render Drawer without a close button"},vue:{code:`<!-- Trigger -->
<button class="chi-button -flat -icon" @click="() => toggleDrawer()">
  <i class="chi-icon -sm--2 icon-menu" aria-hidden="true"></i>
</button>

<!-- Vue component -->
<ChiDrawer
  position="left"
  :active="this.drawerActive"
  :nonClosable="true"
  :noHeader="true"
  backdrop
>
  <div class="-p--2 -pt--6 -text">Drawer content here</div>
</ChiDrawer>

<!-- Data and Methods -->
data: {
  drawerActive : false;
},
methods: {
  toggleDrawer() {
    this.drawerActive = !this.drawerActive;
  }
}`,description:"Use the prop <code>nonClosable</code> to render Drawer without a close button"},htmlBlueprint:{code:`<!-- Trigger -->
<button id="example__close-button-triger" class="chi-button -flat -icon chi-drawer__trigger" data-target="#example__close-button" aria-label="Toggle navigation">
  <div class="chi-button__content">
    <i class="chi-icon -sm--2 icon-menu" aria-hidden="true"></i>
  </div>
</button>

<!-- Drawer -->
<div class="chi-backdrop -closed">
  <div class="chi-backdrop__wrapper">
    <div id="example__close-button" class="chi-drawer -left">
      <div class="chi-drawer__content">
        <div class="-p--2 -pt--6 -text">Drawer content here</div>
      </div>
    </div>
  </div>
</div>

<!-- JavaScript -->
<script>chi.drawer(document.getElementById('example__close-button-triger'));<\/script>`}}},a=[{active:!0,id:"webcomponent",label:"Web Component"},{id:"vue",label:"Vue"},{id:"htmlblueprint",label:"HTML Blueprint"}];return(d,u)=>{const m=g,h=D,k=_;return p(),w(k,{title:"Close button",id:"close-button",tabs:a,"head-tabs":l,onChiHeadTabsChange:c,padding:"-p--0"},{"example-description":r(()=>[...u[0]||(u[0]=[e("p",{class:"-text"},"Close buttons provide users with a consistent way to exit Drawers. For special cases, such as requiring users to perform a task that auto-closes the Drawer when complete, a close button may be removed.",-1)])]),example:r(()=>[e("div",j,[e("chi-drawer",{position:"left","non-closable":!t.value,active:"",backdrop:"","prevent-auto-hide":"","no-header":""},[...u[1]||(u[1]=[e("div",{class:"-p--2 -pt--6 -text"},"Drawer content here",-1)])],8,F)])]),"code-webcomponent":r(()=>[o[n.value].webcomponent.description?(p(),f("div",{key:0,class:"chi-tab__description",innerHTML:o[n.value].webcomponent.description},null,8,U)):C("",!0),i(m,{lang:"html",code:o[n.value].webcomponent.code},null,8,["code"])]),"code-vue":r(()=>[o[n.value].vue.description?(p(),f("div",{key:0,class:"chi-tab__description",innerHTML:o[n.value].vue.description},null,8,Q)):C("",!0),i(m,{lang:"html",code:o[n.value].vue.code},null,8,["code"])]),"code-htmlblueprint":r(()=>[i(h),i(m,{lang:"html",code:o[n.value].htmlBlueprint.code},null,8,["code"])]),_:1})}}}),Y={class:"-position--relative -z--0 -overflow--hidden",style:{height:"30rem"}},G=["no-header"],K=v({__name:"_header",setup(b){const t=x("header"),n=x(!0),c=x(0),l={header:{webComponent:`<!-- Trigger -->
<chi-button id="example__header-trigger" variant="flat" type="icon">
  <chi-icon icon="menu" size="sm--2"></chi-icon>
</chi-button>

<!-- Drawer -->
<chi-drawer id="example__header" title="Drawer title here" position="bottom" backdrop>
  <div class="-p--2 -text">Drawer content here</div>
</chi-drawer>

<!-- JavaScript -->
<script>
  var drawer = document.getElementById('example__header');
  var drawerTrigger = document.getElementById('example__header-trigger');
  drawerTrigger.addEventListener('click', function() {
    drawer.toggle();
    // Or:
    // drawer.active = !drawer.active;
  });
<\/script>`,vue:`<!-- Trigger -->
<button class="chi-button -flat -icon" @click="() => toggleDrawer()">
  <i class="chi-icon -sm--2 icon-menu" aria-hidden="true"></i>
</button>

<!-- Vue component -->
<ChiDrawer
  position="bottom"
  :active="this.drawerActive"
  title="Drawer title here"
  backdrop
>
  <div class="-p--2 -text">Drawer content here</div>
</ChiDrawer>

<!-- Data and Methods -->
data: {
  drawerActive : false;
},
methods: {
  toggleDrawer() {
    this.drawerActive = !this.drawerActive;
  }
}`,htmlBlueprint:`<!-- Trigger -->
<button id="example__header-trigger" class="chi-button -flat -icon chi-drawer__trigger" data-target="#example__header" aria-label="Toggle navigation">
  <div class="chi-button__content">
    <i class="chi-icon -sm--2 icon-menu" aria-hidden="true"></i>
  </div>
</button>

<!-- Drawer -->
<div class="chi-backdrop -closed">
  <div class="chi-backdrop__wrapper">
    <div id="example__header" class="chi-drawer -bottom">
      <div class="chi-drawer__header">
        <span class="chi-drawer__title">
          Drawer title here
        </span>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="-p--2 -text">Drawer content here</div>
      </div>
    </div>
  </div>
</div>

<!-- JavaScript -->
<script>chi.drawer(document.getElementById('example__header-trigger'));<\/script>`},"no-header":{webComponent:`<!-- Trigger -->
<chi-button id="example__header-trigger" variant="flat" type="icon">
  <chi-icon icon="menu" size="sm--2"></chi-icon>
</chi-button>

<!-- Drawer -->
<chi-drawer id="example__header" position="bottom" backdrop no-header>
  <div class="-p--2 -text">Drawer content here</div>
</chi-drawer>

<!-- JavaScript -->
<script>
  var drawer = document.getElementById('example__header');
  var drawerTrigger = document.getElementById('example__header-trigger');
  drawerTrigger.addEventListener('click', function() {
    drawer.toggle();
    // Or:
    // drawer.active = !drawer.active;
  });
<\/script>`,vue:`<!-- Trigger -->
<button class="chi-button -flat -icon" @click="() => toggleDrawer()">
  <i class="chi-icon -sm--2 icon-menu" aria-hidden="true"></i>
</button>

<!-- Vue component -->
<ChiDrawer
  position="bottom"
  :active="this.drawerActive"
  :noHeader="true"
  backdrop
>
  <div class="-p--2 -text">Drawer content here</div>
</ChiDrawer>

<!-- Data and Methods -->
data: {
  drawerActive : false;
},
methods: {
  toggleDrawer() {
    this.drawerActive = !this.drawerActive;
  }
}`,htmlBlueprint:`<!-- Trigger -->
<button id="example__header-trigger" class="chi-button -flat -icon chi-drawer__trigger" data-target="#example__header" aria-label="Toggle navigation">
  <div class="chi-button__content">
    <i class="chi-icon -sm--2 icon-menu" aria-hidden="true"></i>
  </div>
</button>

<!-- Drawer -->
<div class="chi-backdrop -closed">
  <div class="chi-backdrop__wrapper">
    <div id="example__header" class="chi-drawer -bottom">
      <button class="chi-button -icon -close" aria-label="Close">
        <div class="chi-button__content">
          <i class="chi-icon icon-x" aria-hidden="true"></i>
        </div>
      </button>
      <div class="chi-drawer__content">
        <div class="-p--2 -text">Drawer content here</div>
      </div>
    </div>
  </div>
</div>

<!-- JavaScript -->
<script>chi.drawer(document.getElementById('example__header-trigger'));<\/script>`}},o=[{active:!0,id:"header",label:"Header"},{id:"no-header",label:"No header"}],a=[{active:!0,id:"webcomponent",label:"Web Component"},{id:"vue",label:"Vue"},{id:"htmlblueprint",label:"HTML Blueprint"}],d=u=>{n.value=u.id==="header",t.value=u.id,c.value++};return(u,m)=>{const h=g,k=D,B=_;return p(),w(B,{title:"Header",id:"header",tabs:a,"head-tabs":o,onChiHeadTabsChange:d,padding:"-p--0"},{"example-description":r(()=>[...m[0]||(m[0]=[e("p",{class:"-text"},"Header markup is optional. Remove it to make the content fill the drawer.",-1)])]),example:r(()=>[e("div",Y,[(p(),f("chi-drawer",{position:"bottom","no-header":!n.value,title:"Drawer title here",active:"",backdrop:"","prevent-auto-hide":"",key:c.value},[...m[1]||(m[1]=[e("div",{class:"-p--2 -text"},"Drawer content here",-1)])],8,G))])]),"code-webcomponent":r(()=>[i(h,{class:"html",lang:"html",code:l[t.value].webComponent},null,8,["code"])]),"code-vue":r(()=>[i(h,{class:"html",lang:"html",code:l[t.value].vue},null,8,["code"])]),"code-htmlblueprint":r(()=>[i(k),i(h,{class:"html",lang:"html",code:l[t.value].htmlBlueprint},null,8,["code"])]),_:1})}}}),X={class:"-d--flex -flex--column -justify-content--center"},Z=`<!-- Trigger Button -->
<chi-button id="drawer-trigger" variant="flat" type="icon">
  <chi-icon icon="menu" size="sm--2"></chi-icon>
  <span>Click to open drawer</span>
</chi-button>

<!-- Drawer -->
<chi-drawer id="drawer" title="Drawer title" position="left" backdrop>
  <div slot="footer" class="-d--flex">
    <chi-button color="primary">Save</chi-button>
    <chi-button>Reset</chi-button>
    <chi-button variant="flat">Cancel</chi-button>
  </div>
</chi-drawer>

<script>
  const trigger = document.getElementById('drawer-trigger');
  
  trigger.addEventListener('click', () => {
    const drawer = document.getElementById('drawer');
    
    drawer.toggle();
  });
<\/script>
`,ee=v({__name:"_footer",setup(b){const t=E("drawer");return(n,c)=>{const l=g,o=_;return p(),w(o,{title:"Footer",id:"footer",showSnippetTabs:!1},{example:r(()=>[e("div",X,[e("chi-button",{variant:"flat",type:"icon",onClick:c[0]||(c[0]=a=>t.value.toggle())},[...c[1]||(c[1]=[e("chi-icon",{icon:"menu",size:"sm--2"},null,-1),e("span",null,"Click to open drawer",-1)])]),e("chi-drawer",{ref_key:"drawer",ref:t,title:"Drawer title",position:"left",backdrop:""},[...c[2]||(c[2]=[e("div",{class:"-d--flex",slot:"footer",style:{gap:"1rem"}},[e("chi-button",{color:"primary"},"Save"),e("chi-button",null,"Reset"),e("chi-button",{variant:"flat"},"Cancel")],-1)])],512)])]),"code-htmlblueprint":r(()=>[i(l,{class:"html",lang:"html",code:Z})]),_:1})}}}),te={class:"-d--flex -flex--column -justify-content--center"},ie=`<!-- Trigger Button -->
<chi-button id="drawer-trigger" variant="flat" type="icon">
  <chi-icon icon="menu" size="sm--2"></chi-icon>
  <span>Click to open drawer</span>
</chi-button>

<!-- Drawer -->
<chi-drawer id="drawer" title="Drawer title" position="left" backdrop backlink="Back link" backlinkHref="#"></chi-drawer>

<script>
  const trigger = document.getElementById('drawer-trigger');
  
  trigger.addEventListener('click', () => {
    const drawer = document.getElementById('drawer');
    
    drawer.toggle();
  });
<\/script>
`,re=v({__name:"_backlink",setup(b){const t=E("drawer");return(n,c)=>{const l=g,o=_;return p(),w(o,{title:"Backlink",id:"backlink",showSnippetTabs:!1},{example:r(()=>[e("div",te,[e("chi-button",{variant:"flat",type:"icon",onClick:c[0]||(c[0]=a=>t.value.toggle())},[...c[1]||(c[1]=[e("chi-icon",{icon:"menu",size:"sm--2"},null,-1),e("span",null,"Click to open drawer",-1)])]),e("chi-drawer",{ref_key:"drawer",ref:t,title:"Drawer title",position:"left",backdrop:"",backlink:"Back link",backlinkHref:"#"},null,512)])]),"code-htmlblueprint":r(()=>[i(l,{class:"html",lang:"html",code:ie})]),_:1})}}}),se=v({__name:"index",setup(b){return(t,n)=>{const c=S;return p(),f(T,null,[n[0]||(n[0]=e("h2",null,"Examples",-1)),i(c,{placeholder:"Loading..."},{default:r(()=>[i(J),i(O),i(W),i(R),i(P),i(K),i(ee),i(re)]),_:1})],64)}}});export{se as _};
