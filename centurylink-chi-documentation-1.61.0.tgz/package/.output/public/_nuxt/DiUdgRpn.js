import{_ as u}from"./DnPF01B5.js";import{_ as d}from"./CdcsEwU-.js";import{e as l,i as g,o as p,w as i,b as a,a as n,c as h}from"./DBXeQHmC.js";const b=l({__name:"_base",setup(r){const s=[{active:!0,id:"webcomponent",label:"Web Component"},{id:"vue",label:"Vue"},{id:"htmlblueprint",label:"HTML Blueprint"}],t={webcomponent:`<!-- For light backgrounds -->
<chi-pagination pages="3" current-page="2" size="xs" compact first-last></chi-pagination>

<!-- For dark backgrounds -->
<chi-pagination pages="3" current-page="2" size="xs" compact inverse></chi-pagination>`,htmlblueprint:`<nav class="chi-pagination -compact" role="navigation" aria-label="Pagination">
  <div class="chi-pagination__content">
    <div class="chi-pagination__start"></div>
    <div class="chi-pagination__center">
      <div class="chi-pagination__button-group chi-button-group">
        <button class="chi-button -icon -flat -xs" aria-label="Previous page" type="button">
          <div class="chi-button__content">
            <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-pagination__label">
        <strong>2</strong>
        <span>of</span>
        <strong>3</strong>
      </div>
      <div class="chi-pagination__button-group chi-button-group">
        <button class="chi-button -icon -flat -xs" aria-label="Next page" type="button">
          <div class="chi-button__content">
            <i class="chi-icon icon-chevron-right" aria-hidden="true"></i>
          </div>
        </button>
      </div>
    </div>
    <div class="chi-pagination__end"></div>
  </div>
</nav>`,vue:'<ChiPagination :pages="3" :currentPage="2" :compact="true" :firstLast="true" size="xs" />'};return(_,e)=>{const o=u,c=d;return p(),g(c,{title:"Base",id:"base-compact-portal",tabs:s,padding:"-p--0",titleSize:"h4"},{example:i(()=>[...e[0]||(e[0]=[n("div",{class:"chi-grid -no-gutter"},[n("div",{class:"chi-col -w--12"},[n("div",{class:"-p--3"},[n("chi-pagination",{pages:"3","current-page":"2",size:"xs",compact:"","first-last":""})])])],-1)])]),"code-webcomponent":i(()=>[a(o,{class:"html",lang:"html",code:t.webcomponent},null,8,["code"])]),"code-vue":i(()=>[a(o,{class:"html",lang:"html",code:t.vue},null,8,["code"])]),"code-htmlblueprint":i(()=>[a(o,{class:"html",lang:"html",code:t.htmlblueprint},null,8,["code"])]),_:1})}}}),m=l({__name:"_results-label",setup(r){const s=[{active:!0,id:"webcomponent",label:"Web Component"},{id:"vue",label:"Vue"},{id:"htmlblueprint",label:"HTML Blueprint"}],t={webcomponent:'<chi-pagination pages="12" current-page="3" results="240" size="xs"></chi-pagination>',htmlblueprint:`<nav class="chi-pagination -compact" role="navigation" aria-label="Pagination">
  <div class="chi-pagination__content">
    <div class="chi-pagination__start">
      <div class="chi-pagination__results">
        <span class="chi-pagination__label">240 Results</span>
      </div>
    </div>
    <div class="chi-pagination__center">
      <div class="chi-pagination__button-group chi-button-group">
        <button class="chi-button -icon -flat -xs" aria-label="Previous page" type="button">
          <div class="chi-button__content">
            <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-pagination__label">
        <strong>3</strong>
        <span>of</span>
        <strong>12</strong>
      </div>
      <div class="chi-pagination__button-group chi-button-group">
        <button class="chi-button -icon -flat -xs" aria-label="Next page" type="button">
          <div class="chi-button__content">
            <i class="chi-icon icon-chevron-right" aria-hidden="true"></i>
          </div>
        </button>
      </div>
    </div>
    <div class="chi-pagination__end"></div>
  </div>
</nav>`,vue:'<ChiPagination :pages="3" :results="240" :currentPage="2" :compact="true" :firstLast="true" size="xs" />'};return(_,e)=>{const o=u,c=d;return p(),g(c,{title:"Results Label",id:"results-label-portal",tabs:s,padding:"-p--0"},{"example-description":i(()=>[...e[0]||(e[0]=[n("p",{class:"-text"},"Add a label to indicate the total number of results.",-1)])]),example:i(()=>[...e[1]||(e[1]=[n("div",{class:"chi-grid -no-gutter"},[n("div",{class:"chi-col -w--12"},[n("div",{class:"-p--3"},[n("chi-pagination",{pages:"12","current-page":"3",size:"xs",results:"240",compact:"","first-last":""})])])],-1)])]),"code-webcomponent":i(()=>[a(o,{class:"html",lang:"html",code:t.webcomponent},null,8,["code"])]),"code-vue":i(()=>[a(o,{class:"html",lang:"html",code:t.vue},null,8,["code"])]),"code-htmlblueprint":i(()=>[a(o,{class:"html",lang:"html",code:t.htmlblueprint},null,8,["code"])]),_:1})}}}),w=l({__name:"index",setup(r){return(s,t)=>(p(),h("div",null,[t[0]||(t[0]=n("h3",null,"Compact",-1)),a(b),a(m)]))}});export{w as _};
