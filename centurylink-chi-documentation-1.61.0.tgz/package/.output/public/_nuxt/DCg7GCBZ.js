import{a as i,_ as c}from"./BPxlMu2A.js";import{_ as d}from"./ambNZcWR.js";import{c as m,o as r,a as n,b as t,F as p,e as u,i as g,w as o}from"./DBXeQHmC.js";import{_}from"./DlAUqK2U.js";import"./DS5ErHUP.js";import"./CFKeqgEC.js";import"./B1maN0n6.js";import"./DY7FbNsl.js";import"./DnPF01B5.js";import"./CdcsEwU-.js";import"./DDFyDyTO.js";function f(l,e){const s=i;return r(),m(p,null,[e[0]||(e[0]=n("h2",null,"Web Component",-1)),t(s,{tag:"chi-customize-panel"}),e[1]||(e[1]=n("h3",null,"Interfaces and types",-1)),e[2]||(e[2]=n("section",{class:"chi-table -bordered -my--3"},[n("div",{style:{"overflow-x":"auto"}},[n("table",{class:"-types",cellpadding:"0",cellspacing:"0"},[n("thead",null,[n("tr",null,[n("th",null,[n("div",null,"Name")]),n("th",null,[n("div",null,"Interface")])])]),n("tbody",null,[n("tr",null,[n("td",null,[n("div",null,[n("code",null,"CustomizePanelItem")])]),n("td",{class:"-p--0"},[n("pre",{class:"-mb--0"},`{
  label: string;
  description?: string;
  selected?: boolean;
  locked?: boolean;
  id?: string;
  checked?: boolean;
  infoIcon?: {
    message?: string;
    icon?: string;
    color?: IconColors;
    size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '';
  };
}`)])]),n("tr",null,[n("td",null,[n("div",null,[n("code",null,"CustomizePanelLabelConfig")])]),n("td",{class:"-p--0"},[n("pre",{class:"-mb--0"},`{
  itemsName?: string;
  title?: string;
  sortPanel?: {
    title?: string;
    button?: {
      add?: string;
      save?: string;
      reset?: string;
      cancel?: string;
    };
    noResults?: {
      message?: string;
      icon?: string;
    };
  };
  addPanel?: {
    title?: string;
    backLink?: string;
    button?: {
      save?: string;
      cancel?: string;
    };
    searchPlaceholder?: string;
    noResults?: {
      message?: string;
      icon?: string;
    };
  };
}`)])])])])])],-1))],64)}const b={},x=_(b,[["render",f]]),$=u({__name:"index",setup(l){return(e,s)=>{const a=c;return r(),g(a,{"hide-builder":"",title:"Customize Panel",description:"Customize Panel is a dual-panel drawer that enables users to manage their content preferences. It features a selection area for adding new items and a dedicated sorting view to arrange them via drag-and-drop."},{examples:o(()=>[t(d)]),properties:o(()=>[t(x)]),_:1})}}});export{$ as default};
