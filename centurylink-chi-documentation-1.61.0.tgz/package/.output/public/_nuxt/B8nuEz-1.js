import{am as r}from"./DBXeQHmC.js";const p=(t,n)=>{const o=r(n);return`<${t}${o}></${t}>`};export{p as snippet};
