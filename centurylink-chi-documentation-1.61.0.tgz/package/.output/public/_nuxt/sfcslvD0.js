import{_ as u}from"./DnPF01B5.js";import{_ as g}from"./CdcsEwU-.js";import{e as d,i as p,o as r,w as s,a as e,b as l,d as i,g as h,c as x,S as y,k as w}from"./DBXeQHmC.js";import{_ as f}from"./DDFyDyTO.js";import{_ as S}from"./Bo0goINO.js";const C=d({__name:"_base",setup(m){const o={webcomponent:`<!-- 0% -->
<div class="chi-label">0%</div>
<chi-progress value="0" max="100"></chi-progress>

<!-- 50% -->
<div class="chi-label">50%</div>
<chi-progress value="50" max="100"></chi-progress>

<!-- 100% -->
<div class="chi-label">100%</div>
<chi-progress value="100" max="100"></chi-progress>`,htmlblueprint:`<!-- 0% -->
<div class="chi-label" id="example-1">0%</div>
<progress aria-labelledby="example-1" value="0" max="100"></progress>

<!-- 50% -->
<div class="chi-label" id="example-2">50%</div>
<progress aria-labelledby="example-2" value="50" max="100"></progress>

<!-- 100% -->
<div class="chi-label" id="example-3">100%</div>
<progress aria-labelledby="example-3" value="100" max="100"></progress>`};return(c,a)=>{const t=u,n=g;return r(),p(n,{title:"Base",id:"base"},{example:s(()=>[...a[0]||(a[0]=[e("div",{class:"-py--2"},[e("div",{class:"chi-label"},"0%"),e("chi-progress",{value:"0",max:"100"})],-1),e("div",{class:"-py--2"},[e("div",{class:"chi-label"},"50%"),e("chi-progress",{value:"50",max:"100"})],-1),e("div",{class:"-py--2"},[e("div",{class:"chi-label"},"100%"),e("chi-progress",{value:"100",max:"100"})],-1)])]),"code-webcomponent":s(()=>[l(t,{class:"html",lang:"html",code:o.webcomponent},null,8,["code"])]),"code-htmlblueprint":s(()=>[a[1]||(a[1]=e("div",{class:"chi-tab__description"},[i("To render a progress element, use the "),e("code",null,"progress"),i(" HTML5 tag. Set the value attribute to indicate the current progress.")],-1)),l(t,{lang:"html",code:o.htmlblueprint},null,8,["code"])]),_:1})}}}),k=d({__name:"_contextual",setup(m){const o=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],c={webcomponent:"",htmlblueprint:`<!-- Trigger -->
<button id="modal-trigger" class="chi-button chi-modal__trigger" data-target="#modal">
  Launch center modal
</button>

<!-- Modal -->
<div class="chi-backdrop -closed">
  <div class="chi-backdrop__wrapper">
    <section id="modal" class="chi-modal" role="dialog" aria-label="Modal description" aria-modal="true">
      <div class="chi-modal__content">
        <div class="chi-label" id="example-2">50%</div>
        <progress aria-labelledby="example-2" value="50" max="100"></progress>
      </div>
    </section>
  </div>
</div>

<!-- JavaScript -->
<script>chi.modal(document.getElementById('modal-trigger'));<\/script>`};return(a,t)=>{const n=f,b=u,v=S,_=g;return r(),p(_,{title:"Contextual",id:"contextual",tabs:o,padding:"-p--0"},{"example-description":s(()=>[l(n,{id:"progress-in-modals",title:"Progress in Modals",titleSize:"h4"})]),example:s(()=>[...t[0]||(t[0]=[e("div",{class:"chi-backdrop -position--relative -py--6"},[e("div",{class:"chi-backdrop__wrapper"},[e("section",{class:"chi-modal",id:"modal",role:"dialog","aria-label":"Modal description","aria-modal":"true"},[e("div",{class:"chi-modal__content"},[e("div",{class:"chi-label",id:"example-2"},"50%"),e("progress",{class:"-info","aria-labelledby":"example-2",value:"50",max:"100"})])])])],-1)])]),"code-webcomponent":s(()=>[l(b,{class:"html",lang:"html",code:c.webcomponent},null,8,["code"])]),"code-htmlblueprint":s(()=>[l(v),l(b,{class:"html",lang:"html",code:c.htmlblueprint},null,8,["code"])]),_:1})}}}),T=d({__name:"_semantic_states",setup(m){const o={webcomponent:`<!-- Success -->
<div class="chi-label">Success</div>
<chi-progress value="75" max="100" state="success"></chi-progress>

<!-- Warning -->
<div class="chi-label">Warning</div>
<chi-progress value="50" max="100" state="warning"></chi-progress>

<!-- Danger -->
<div class="chi-label">Danger</div>
<chi-progress value="25" max="100" state="danger"></chi-progress>`,htmlblueprint:`<!-- Success -->
<div class="chi-label" id="example-5">Success</div>
<progress aria-labelledby="example-5" class="-success" value="75" max="100"></progress>

<!-- Warning -->
<div class="chi-label" id="example-6">Warning</div>
<progress aria-labelledby="example-6" class="-warning" value="50" max="100"></progress>

<!-- Danger -->
<div class="chi-label" id="example-7">Danger</div>
<progress aria-labelledby="example-7" class="-danger" value="25" max="100"></progress>`};return(c,a)=>{const t=u,n=g;return r(),p(n,{title:"Semantic States",id:"semantic_states"},{"example-description":s(()=>[...a[0]||(a[0]=[e("p",{class:"-text"},[i("Use semantic colors to communicate meaning to users. Use green ("),e("code",null,"-success"),i(") for positive, blue (base state) for informative, red ("),e("code",null,"-danger"),i(") for negative, and yellow ("),e("code",null,"-warning"),i(") for needs attention.")],-1)])]),example:s(()=>[...a[1]||(a[1]=[e("div",{class:"-py--2"},[e("div",{class:"chi-label"},"Success"),e("chi-progress",{value:"75",max:"100",state:"success"})],-1),e("div",{class:"-py--2"},[e("div",{class:"chi-label"},"Warning"),e("chi-progress",{value:"50",max:"100",state:"warning"})],-1),e("div",{class:"-py--2"},[e("div",{class:"chi-label"},"Danger"),e("chi-progress",{value:"25",max:"100",state:"danger"})],-1)])]),"code-webcomponent":s(()=>[l(t,{class:"html",lang:"html",code:o.webcomponent},null,8,["code"])]),"code-htmlblueprint":s(()=>[l(t,{class:"html",lang:"html",code:o.htmlblueprint},null,8,["code"])]),_:1})}}}),N=d({__name:"index",setup(m){const o=h();return(c,a)=>(r(),x("div",null,[a[0]||(a[0]=e("h2",null,"Examples",-1)),l(C),l(k),["lumen","centurylink"].includes(w(o))?(r(),p(T,{key:0})):y("",!0)]))}});export{N as _};
