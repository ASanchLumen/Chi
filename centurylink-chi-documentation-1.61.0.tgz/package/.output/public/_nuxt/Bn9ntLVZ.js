import{am as a,aD as n,ar as r}from"./DBXeQHmC.js";const c=(i,o)=>{const t="ChiTooltip",s=a(o),e=`<button class="${n.BUTTON}">Hover me to see tooltip</button>`;return[`<${t}${s}>`,...r([e]),`</${t}>`].join(`
`)};export{c as snippet};
