import{am as c,an as r}from"./DBXeQHmC.js";const g=(e,s)=>{const{helperMessageText:i,helperMessage:n,size:a}=s.dynamicComputedProps,o=r("helper-message",i,!!n),t=r("size",a,a!=="md"),p="phone-input",l=`id="${p}"`,m=`<chi-label for="${p}">Phone Number</chi-label>`,h=c(s,[o,l,t]);return[m,`<${e}${h}></${e}>`].join(`
`)};export{g as snippet};
