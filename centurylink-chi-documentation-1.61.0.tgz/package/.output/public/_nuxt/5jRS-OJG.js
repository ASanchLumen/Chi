import{_ as h}from"./DnPF01B5.js";import{g as b,Q as g,H as y,R as C,c as v,o as D,a,b as r,F as f}from"./DBXeQHmC.js";const w={columnResize:!1,selectable:!0,style:{portal:!1,noBorder:!1,bordered:!1,hover:!1,size:"md",striped:!0},pagination:{activePage:1,compact:!1,firstLast:!0,pageJumper:!1},resultsPerPage:3,defaultSort:{key:"name",sortBy:"string",direction:"ascending"},showExpandAll:!0,showSelectAllDropdown:!0,actions:[{label:"View",icon:"icon-check-alt",onClick:e=>{console.log(JSON.stringify(e))}},{label:"Edit",icon:"icon-edit",onClick:()=>console.log("Edited")},{label:"Download",icon:"icon-circle-arrow-down",hide:["desktop"],onClick:()=>console.log("downloaded")},{label:"Delete",icon:"icon-delete",onClick:()=>console.log("deleted")}]},x={columnResize:!1,selectable:!0,style:{portal:!0,noBorder:!1,bordered:!1,hover:!0,size:"md",striped:!0},pagination:{activePage:1,compact:!0,firstLast:!0,pageJumper:!1},resultsPerPage:3,defaultSort:{key:"name",sortBy:"string",direction:"ascending"},showExpandAll:!0,showSelectAllDropdown:!0,actions:[{label:"View",icon:"icon-check-alt",onClick:e=>{console.log(JSON.stringify(e))}},{label:"Edit",icon:"icon-edit",onClick:()=>console.log("Edited")},{label:"Download",icon:"icon-circle-arrow-down",hide:["desktop"],onClick:()=>console.log("downloaded")},{label:"Delete",icon:"icon-delete",onClick:()=>console.log("deleted")}]},N={columnResize:!0,selectable:!0,style:{connect:!0,portal:!0,noBorder:!1,bordered:!1,hover:!0,size:"md",striped:!0},pagination:{activePage:1,compact:!0,firstLast:!0,pageJumper:!1},resultsPerPage:3,defaultSort:{key:"name",sortBy:"string",direction:"ascending"},showExpandAll:!0,showSelectAllDropdown:!0,actions:[{label:"View",icon:"icon-check-alt",onClick:e=>{console.log(JSON.stringify(e))}},{label:"Edit",icon:"icon-edit",onClick:()=>console.log("Edited")},{label:"Download",icon:"icon-circle-arrow-down",hide:["desktop"],onClick:()=>console.log("downloaded")},{label:"Delete",icon:"icon-delete",onClick:()=>console.log("deleted")}]},T={name:{label:"Name",sortable:!0,sortBy:"name",sortDataType:"string",key:!0,bold:!0},status:{label:"Status",sortable:!0,sortBy:"status",sortDataType:"string",description:"Helpful information goes here."},userID:{label:"User ID",key:!0,icon:"user"},lastLogin:{label:"Last Login",key:!0}},O=[{expanded:!0,id:"name-1",data:[{template:"name",payload:{name:"Name 1",id:"name-1"}},{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-1","18 Dec 2020 3:26 p.m."],nestedContent:{table:{data:[{id:"child-1-name-1",data:["Child 1 Name 1",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-1","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"grandchild-1-name-1",data:["Grand Child 1 Name 1",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-1","18 Dec 2020 2:38 a.m."]},{id:"grandchild-2-name-1",data:["Grand Child 2 Name 1",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-1","18 Dec 2020 2:38 a.m."]}]}}},{id:"child-2-name-1",data:["Child 2 Name 1",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-1","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"grandchild-3-name-1",data:["Grand Child 3 Name 1",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-1","18 Dec 2020 2:38 a.m."]},{id:"grandchild-4-name-1",data:["Grand Child 4 Name 1",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-1","18 Dec 2020 2:38 a.m."]}]}}}]}}},{id:"name-2",data:[{template:"name",payload:{name:"Name 2",id:"name-2"}},{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-2","18 Dec 2020 3:26 p.m."],nestedContent:{table:{data:[{id:"child-1-name-2",data:["Child 1 Name 2",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-2","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"grandchild-1-name-2",data:["Grand Child 1 Name 2",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-2","18 Dec 2020 2:38 a.m."]},{id:"grandchild-2-name-2",data:["Grand Child 2 Name 2",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-2","18 Dec 2020 2:38 a.m."]}]}}},{id:"child-2-name-2",data:["Child 2 Name 2",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-2","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"grandchild-3-name-2",data:["Grand Child 3 Name 2",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-2","18 Dec 2020 2:38 a.m."]},{id:"grandchild-4-name-2",data:["Grand Child 4 Name 2",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-2","18 Dec 2020 2:38 a.m."]}]}}}]}}},{id:"name-3",data:[{template:"name",payload:{name:"Name 3",id:"name-3"}},{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-3","18 Dec 2020 3:26 p.m."],nestedContent:{table:{data:[{id:"child-1-name-3",data:["Child 1 Name 3",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-3","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"grandchild-1-name-3",data:["Grand Child 1 Name 3",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-3","18 Dec 2020 2:38 a.m."]},{id:"grandchild-2-name-3",data:["Grand Child 2 Name 3",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-3","18 Dec 2020 2:38 a.m."]}]}}},{id:"child-2-name-3",data:["Child 2 Name 3",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-3","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"grandchild-3-name-3",data:["Grand Child 3 Name 3",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-3","18 Dec 2020 2:38 a.m."]},{id:"grandchild-4-name-3",data:["Grand Child 4 Name 3",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-3","18 Dec 2020 2:38 a.m."]}]}}}]}}},{id:"name-4",data:[{template:"name",payload:{name:"Name 4",id:"name-4"}},{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-4","18 Dec 2020 3:26 p.m."],nestedContent:{table:{data:[{id:"child-1-name-4",data:["Child 1 Name 4",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-4","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"grandchild-1-name-4",data:["Grand Child 1 Name 4",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-4","18 Dec 2020 2:38 a.m."]},{id:"grandchild-2-name-4",data:["Grand Child 2 Name 4",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-4","18 Dec 2020 2:38 a.m."]}]}}},{id:"child-2-name-4",data:["Child 2 Name 4",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-4","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"grandchild-3-name-4",data:["Grand Child 3 Name 4",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-4","18 Dec 2020 2:38 a.m."]},{id:"grandchild-4-name-4",data:["Grand Child 4 Name 4",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-4","18 Dec 2020 2:38 a.m."]}]}}}]}}},{id:"name-5",data:[{template:"name",payload:{name:"Name 5",id:"name-5"}},{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-5","18 Dec 2020 3:26 p.m."],nestedContent:{table:{data:[{id:"child-1-name-5",data:["Child 1 Name 5",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-5","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"grandchild-1-name-5",data:["Grand Child 1 Name 5",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-5","18 Dec 2020 2:38 a.m."]},{id:"grandchild-2-name-5",data:["Grand Child 2 Name 5",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-5","18 Dec 2020 2:38 a.m."]}]}}},{id:"child-2-name-5",data:["Child 2 Name 5",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-5","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"grandchild-3-name-5",data:["Grand Child 3 Name 5",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-5","18 Dec 2020 2:38 a.m."]},{id:"grandchild-4-name-5",data:["Grand Child 4 Name 5",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"user-name-5","18 Dec 2020 2:38 a.m."]}]}}}]}}},{id:"name-6",data:[{template:"name",payload:{name:"Name 6",id:"name-6"}},{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-6","18 Dec 2020 3:26 p.m."],nestedContent:{table:{data:[{id:"child-1-name-6",data:["Child 1 Name 6",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-6","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"grandchild-1-name-6",data:["Grand Child 1 Name 6",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-6","18 Dec 2020 2:38 a.m."]},{id:"grandchild-2-name-6",data:["Grand Child 2 Name 6",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-6","18 Dec 2020 2:38 a.m."]}]}}},{id:"child-2-name-6",data:["Child 2 Name 6",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-6","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"grandchild-3-name-6",data:["Grand Child 3 Name 6",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-6","18 Dec 2020 2:38 a.m."]},{id:"grandchild-4-name-6",data:["Grand Child 4 Name 6",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"user-name-6","18 Dec 2020 2:38 a.m."]}]}}}]}}}],c=`<!-- Vue component -->
<ChiDataTable :config="config" :dataTableData="table" ref="dataTableComplex">
  <template #status="payload">
    <chi-icon :icon="payload.icon" :color="payload.color" aria-hidden="true"></chi-icon>
    <span class="-text--truncate -pl--1">
      {{ payload.status }}
    </span>
  </template>
  <template #name="payload">
    <ExamplePopover :name="payload.name" :id="payload.id" />
  </template>
  <template #toolbar>
    <ChiDataTableToolbar>
      <template v-slot:start></template>
      <template v-slot:end>
        <chi-button @chiClick="printTable" variant="flat" type="icon" aria-label="Print data table complex example">
          <chi-icon icon="print"></chi-icon>
        </chi-button>
      </template>
    </ChiDataTableToolbar>
  </template>
  <template #bulk-actions>
    <div class="chi-bulk-actions__buttons">
      <div class="chi-bulk-actions__buttons-mobile -z--40">
        <chi-button variant="flat" type="icon" aria-label="Edit">
          <chi-icon icon="edit"></chi-icon>
        </chi-button>
        <chi-button variant="flat" type="icon" aria-label="Compose">
          <chi-icon icon="compose"></chi-icon>
        </chi-button>
        <chi-button variant="flat" type="icon" aria-label="Delete">
          <chi-icon icon="delete"></chi-icon>
        </chi-button>
        <chi-button variant="flat" type="icon" aria-label="Print">
          <chi-icon icon="print"></chi-icon>
        </chi-button>
      </div>
      <div class="chi-bulk-actions__buttons-desktop">
        <chi-button size="xs" aria-label="Download">
          <chi-icon icon="arrow-to-bottom"></chi-icon>
          <span> Download </span>
        </chi-button>
        <chi-button size="xs" aria-label="Compose">
          <chi-icon icon="arrow-to-bottom"></chi-icon>
          <span> Compose </span>
        </chi-button>
        <chi-button size="xs" aria-label="Delete">
          <chi-icon icon="arrow-to-bottom"></chi-icon>
          <span> Delete </span>
        </chi-button>
        <chi-button size="xs" aria-label="Print">
          <chi-icon icon="arrow-to-bottom"></chi-icon>
          <span> Print </span>
        </chi-button>
      </div>
    </div>
  </template>
</ChiDataTable>`,_=`<!-- Vue component -->
<ChiDataTable :config="config" :dataTableData="table" ref="dataTableComplex">
  <template #status="payload">
    <chi-icon :icon="payload.icon" :color="payload.color" aria-hidden="true"></chi-icon>
    <span class="-text--truncate -pl--1">
      {{ payload.status }}
    </span>
  </template>
  <template #name="payload">
    <ExamplePopover :name="payload.name" :id="payload.id" />
  </template>
</ChiDataTable>`,k=`<!-- Template -->
<template>
  <div class="-text--truncate">
    <a
      :id="\`name-popover-button-\${id}\`"
      href="#"
      :data-target="\`#name-popover-\${id}\`"
      position="top-start">
      {{id}}
    </a>
    <section
      class="chi-popover"
      :id="\`name-popover-\${id}\`"
      aria-modal="true"
      role="dialog"
      :aria-label="name"
    >
      <div class="chi-popover__content">
        {{ name }}
      </div>
    </section>
  </div>
</template>

<!-- Mounted -->
mounted() {
  let hoverAnimationTimeout: ReturnType<typeof setTimeout> | undefined;
  const buttonOpenOnHover = document.getElementById(\`ticket-popover-button-\${this.$props.id}\`);
  const popover = chi.popover(buttonOpenOnHover);

  if (buttonOpenOnHover) {
    buttonOpenOnHover.addEventListener('mouseenter', function() {
      hoverAnimationTimeout = setTimeout(() => {
        popover.show();
      }, 300);
    });

    buttonOpenOnHover.addEventListener('mouseleave', function() {
      if (hoverAnimationTimeout) {
        clearTimeout(hoverAnimationTimeout);
      }
      popover.hide();
    });
  }
}
beforeDestroy() {
  this.popover.dispose();
}`,t=e=>JSON.stringify(e,null,2).replace(/"([^"]+)":/g,"$1:"),E=t(w),S=t(x),P=t(N),n=t(T),o=t(O),G=`${c}

<!-- imports -->
import ExamplePopover from './ExamplePopover.vue';

<!-- Config and Data -->
const config = ${E};

const head = ${n};

const body = ${o};

data() {
  return {
    config,
    table: {
      head,
      body
    }
  };
},
methods: {
  printTable() {
    this.$refs.dataTableComplex.print('Data table - Complex');
  }
}`,$=`${c}

<!-- imports -->
import ExamplePopover from './ExamplePopover.vue';

<!-- Config and Data -->
const config = ${S};

const head = ${n};

const body = ${o};

const table = { head, body };

data() {
  return {
    config,
    table: {
      head,
      body
    }
  };
},
methods: {
  printTable() {
    this.$refs.dataTableComplex.print('Data table - Complex');
  }
}`,B=`${_}

<!-- imports -->
import ExamplePopover from './ExamplePopover.vue';

<!-- Config and Data -->
const config = ${P};

const head = ${n};

const body = ${o};

data() {
  return {
    config,
    table: {
      head,
      body
    }
  };
},
methods: {
  printTable() {
    this.$refs.dataTableComplex.print('Data table - Complex');
  }
}`,z={class:"chi-col -w--10 -w-sm--9",slot:"panels",ref:"panels"},A={class:"chi-tabs-panel",id:"snippet-data-table",role:"tabpanel"},H={class:"chi-tabs-panel",id:"snippet-popover",role:"tabpanel"},L={__name:"vue-snippets",setup(e){const m=b(),l=g("snippetTabs"),p=[{label:"ExampleDataTable.vue",id:"snippet-data-table"},{label:"ExamplePopover.vue",id:"snippet-popover"}],i=y(()=>({dataTableExample:u(),popoverExample:k})),u=()=>{switch(m.value){case"portal":case"brightspeed":case"colt":return $;case"connect":return B;default:return G}};return C(()=>{l.value&&setTimeout(()=>{l.value.activeTab="snippet-data-table"},1e3)}),(V,d)=>{const s=h;return D(),v(f,null,[d[0]||(d[0]=a("div",{class:"chi-tab__description -p--2"},"Create reusable Vue components based on your needs and use them as custom templates for Data Table cells and row accordions",-1)),a("chi-tabs",{class:"-bg--grey-15 -bt--1",tabs:p,vertical:"","extra-class":"-br--1 -pt--3 -h--100",ref:"snippetTabs"},[a("div",z,[a("div",A,[r(s,{lang:"html",code:i.value.dataTableExample},null,8,["code"])]),a("div",H,[r(s,{lang:"html",code:i.value.popoverExample},null,8,["code"])])],512)],512)],64)}}},j=Object.freeze(Object.defineProperty({__proto__:null,default:L},Symbol.toStringTag,{value:"Module"}));export{L as _,w as a,O as b,N as c,x as d,T as h,j as v};
