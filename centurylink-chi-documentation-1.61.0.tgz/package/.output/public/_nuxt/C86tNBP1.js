import{am as r}from"./DBXeQHmC.js";const t=(o,p)=>`<${o}${r(p)}></${o}>`;export{t as snippet};
