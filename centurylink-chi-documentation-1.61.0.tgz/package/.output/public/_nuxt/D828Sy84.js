import{aw as $,am as a}from"./DBXeQHmC.js";const u=(n,t)=>{const o=t.dynamicComputedProps,p=[o.dropdown?`extra-class="${$.TRIGGER}"`:""],i=o?.type==="icon"||o?.type==="float"?`<chi-icon icon="${o?.iconButton}" />`:o.text,s=o?.showIcon&&o?.checkboxIconLeft?`<chi-icon icon="${o?.iconLeft}" />`:"",e=o?.showIcon&&o?.checkboxIconRight?`<chi-icon icon="${o?.iconRight}" />`:"",h=a(t,p),c=[];return s&&c.push(`  ${s}`),i&&c.push(`  ${i}`),e&&c.push(`  ${e}`),`<${n}${h}>
${c.join(`
`)}
</${n}>`};export{u as snippet};
