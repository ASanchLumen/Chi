import{_ as C}from"./DnPF01B5.js";import{_ as $}from"./Bo0goINO.js";import{_ as y}from"./CdcsEwU-.js";import{e as f,Q as g,R as E,i as B,o as v,w as a,b as t,a as c,d as u,q as V,c as k,r as W,F as R,t as F,k as S,S as N,g as U}from"./DBXeQHmC.js";function l(n,o=!1,i=3){const e="  ".repeat(i),_=`<div class="chi-accordion__title">${n}</div>`,h='<i class="chi-icon icon-chevron-down" aria-hidden="true"></i>';return o?`${_}
${e}${h}`:`${h}
${e}${_}`}const M=["portal"],L=f({__name:"_base",props:{portal:{type:Boolean}},setup(n){const o=n,i=g("example-base");E(()=>{i.value&&(i.value.accordions=[{title:"Accordion 1",text:"Content goes here"},{title:"Accordion 2",text:"Content goes here",expanded:!0},{title:"Accordion 3",text:"Content goes here"},{title:"Accordion 4",text:"Content goes here"}])});const e={webcomponent:`<chi-accordion id="example-base"${o.portal?" portal":""}></chi-accordion>
  
<script>
  const accordionBase = document.getElementById('example-base');

  accordionBase.accordions = [
    { title: 'Accordion 1', text: 'Content goes here' },
    { title: 'Accordion 2', text: 'Content goes here', expanded: true },
    { title: 'Accordion 3', text: 'Content goes here' },
    { title: 'Accordion 4', text: 'Content goes here' }
  ];
<\/script>`,htmlblueprint:`<div class="chi-accordion" id="example-base">
  <div class="chi-accordion__item">
    <button class="chi-accordion__trigger">
      ${l("Accordion 1",o.portal)}
    </button>
    <div class="chi-accordion__content">
      <p class="chi-accordion__text">Content goes here</p>
    </div>
  </div>
  <div class="chi-accordion__item -expanded">
    <button class="chi-accordion__trigger">
      ${l("Accordion 2",o.portal)}
    </button>
    <div class="chi-accordion__content">
      <p class="chi-accordion__text">Content goes here</p>
    </div>
  </div>
  <div class="chi-accordion__item">
    <button class="chi-accordion__trigger">
      ${l("Accordion 3",o.portal)}
    </button>
    <div class="chi-accordion__content">
      <p class="chi-accordion__text">Content goes here</p>
    </div>
  </div>
  <div class="chi-accordion__item">
    <button class="chi-accordion__trigger">
      ${l("Accordion 4",o.portal)}
    </button>
    <div class="chi-accordion__content">
      <p class="chi-accordion__text">Content goes here</p>
    </div>
  </div>
</div>

<script>
  const accordionBase = document.getElementById('example-base');

  if (accordionBase) {
    chi.accordion(accordionBase);
  }
<\/script>`};return(_,h)=>{const p=C,s=$,m=y;return v(),B(m,{title:"Base",padding:"-p--3 -p-lg--6",id:"base"},{example:a(()=>[c("chi-accordion",{ref:"example-base",portal:n.portal},null,8,M)]),"code-webcomponent":a(()=>[t(p,{class:"html",lang:"html",code:e.webcomponent},null,8,["code"])]),"code-htmlblueprint":a(()=>[t(s),t(p,{lang:"html",code:e.htmlblueprint},null,8,["code"])]),_:1})}}}),Q=["portal"],G=f({__name:"_card",props:{portal:{type:Boolean}},setup(n){const o=n,i=g("example-card");E(()=>{i.value&&(i.value.accordions=[{title:"Accordion 1",text:"Content goes here"},{title:"Accordion 2",text:"Content goes here",expanded:!0},{title:"Accordion 3",text:"Content goes here"},{title:"Accordion 4",text:"Content goes here"}])});const e={webcomponent:`<chi-accordion id="example-card" card${o.portal?" portal":""}></chi-accordion>

<script>
  const accordionCard = document.getElementById('example-card');

  accordionCard.accordions = [
    { title: 'Accordion 1', text: 'Content goes here' },
    { title: 'Accordion 2', text: 'Content goes here', expanded: true },
    { title: 'Accordion 3', text: 'Content goes here' },
    { title: 'Accordion 4', text: 'Content goes here' }
  ];
<\/script>`,htmlblueprint:`<div class="chi-accordion -card" id="example-card">
  <div class="chi-accordion__item">
    <button class="chi-accordion__trigger">
      ${l("Accordion 1",o.portal)}
    </button>
    <div class="chi-accordion__content">
      <p class="chi-accordion__text">Content goes here</p>
    </div>
  </div>
  <div class="chi-accordion__item -expanded">
    <button class="chi-accordion__trigger">
      ${l("Accordion 2",o.portal)}
    </button>
    <div class="chi-accordion__content">
      <p class="chi-accordion__text">Content goes here</p>
    </div>
  </div>
  <div class="chi-accordion__item">
    <button class="chi-accordion__trigger">
      ${l("Accordion 3",o.portal)}
    </button>
    <div class="chi-accordion__content">
      <p class="chi-accordion__text">Content goes here</p>
    </div>
  </div>
  <div class="chi-accordion__item">
    <button class="chi-accordion__trigger">
      ${l("Accordion 4",o.portal)}
    </button>
    <div class="chi-accordion__content">
      <p class="chi-accordion__text">Content goes here</p>
    </div>
  </div>
</div>

<script>
  const accordionCard = document.getElementById('example-card');

  if (accordionCard) {
    chi.accordion(accordionCard);
  }
<\/script>`};return(_,h)=>{const p=C,s=$,m=y;return v(),B(m,{title:"Card",id:"card",padding:"-p--3 -p-lg--6"},{example:a(()=>[c("chi-accordion",{ref:"example-card",portal:n.portal,card:""},null,8,Q)]),"code-webcomponent":a(()=>[t(p,{class:"html",lang:"html",code:e.webcomponent},null,8,["code"])]),"code-htmlblueprint":a(()=>[t(s),t(p,{lang:"html",code:e.htmlblueprint},null,8,["code"])]),_:1})}}}),K=["portal"],P={slot:"main-accordion-content"},X=["portal"],Y={slot:"parent-accordion-1-content"},Z=["portal"],oo={slot:"child-accordion-content"},co=["portal"],to={slot:"parent-accordion-2-content"},no=["portal"],O=f({__name:"_nested",props:{portal:{type:Boolean}},setup(n){const o=n,i=g("main-accordion"),e=g("parent-accordion"),_=g("child-accordion-1"),h=g("child-accordion-2"),p=g("grandchild-accordion"),s=(d,r)=>{d?.value&&(d.value.accordions=r)};E(()=>{s(i,[{title:"Click me to expand Accordion",template:"main-accordion-content"}]),s(e,[{title:"Accordion 1",template:"parent-accordion-1-content"},{title:"Accordion 2",template:"parent-accordion-2-content"}]),s(_,[{title:"Accordion 1.1",template:"child-accordion-content"},{title:"Accordion 1.2",text:"Content of Accordion item 1.2"}]),s(p,[{title:"Accordion 1.1.1",text:"Content of Accordion item 1.1.1"}]),s(h,[{title:"Accordion 2.1",text:"Content of Accordion item 2.1"}])});const m=o.portal?" portal":"",A={webcomponent:`<chi-accordion id="main-accordion"${m}>
  <div slot="main-accordion-content">
    <chi-accordion id="parent-accordion"${m}>
      <div slot="parent-accordion-1-content">
        <p class="chi-accordion__text">Content of Accordion item 1</p>
        <chi-accordion id="child-accordion-1"${m}>
          <div slot="child-accordion-content">
            <p class="chi-accordion__text -mb--2">Content of Accordion item 1.1</p>
            <chi-accordion id="grandchild-accordion"${m}></chi-accordion>
          </div>
        </chi-accordion>
      </div>
      <div slot="parent-accordion-2-content">
        <p class="chi-accordion__text">Content of Accordion item 2</p>
        <chi-accordion id="child-accordion-2"${m}></chi-accordion>
      </div>
    </chi-accordion>
  </div>
</chi-accordion>

<script>
  const mainAccordion = document.getElementById('main-accordion');
  const parentAccordion = document.getElementById('parent-accordion');
  const childAccordionOne = document.getElementById('child-accordion-1');
  const childAccordionTwo = document.getElementById('child-accordion-2');
  const grandchildAccordion = document.getElementById('grandchild-accordion');

  mainAccordion.accordions = [{ title: 'Click me to expand Accordion', template: 'main-accordion-content' }];
  parentAccordion.accordions = [
    { title: 'Accordion 1', template: 'parent-accordion-1-content' },
    { title: 'Accordion 2', template: 'parent-accordion-2-content' },
  ];
  childAccordionOne.accordions = [
    { title: 'Accordion 1.1', template: 'child-accordion-content' },
    { title: 'Accordion 1.2', text: 'Content of Accordion item 1.2' },
  ];
  grandchildAccordion.accordions = [{ title: 'Accordion 1.1.1', text: 'Content of Accordion item 1.1.1' }];
  childAccordionTwo.accordions = [{ title: 'Accordion 2.1', text: 'Content of Accordion item 2.1' }];
<\/script>`,htmlblueprint:`<div class="chi-accordion" id="example-nested">
  <div class="chi-accordion__item">
    <button class="chi-accordion__trigger">
      ${l("Click me to expand Accordion",o.portal)}
    </button>
    <div class="chi-accordion__content">
      <div class="chi-accordion">
        <div class="chi-accordion__item">
          <button class="chi-accordion__trigger">
            ${l("Accordion 1",o.portal,6)}
          </button>
          <div class="chi-accordion__content">
            <p class="chi-accordion__text">Content of Accordion item 1</p>
            <div class="chi-accordion">
              <div class="chi-accordion__item">
                <button class="chi-accordion__trigger">
                  ${l("Accordion 1.1",o.portal,9)}
                </button>
                <div class="chi-accordion__content">
                  <p class="chi-accordion__text">Content of Accordion item 1.1</p>
                  <div class="chi-accordion">
                    <div class="chi-accordion__item">
                      <button class="chi-accordion__trigger">
                        ${l("Accordion 1.1.1",o.portal,12)}
                      </button>
                      <div class="chi-accordion__content">
                        <p class="chi-accordion__text">Content of Accordion item 1.1.1</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="chi-accordion">
              <div class="chi-accordion__item">
                <button class="chi-accordion__trigger">
                  ${l("Accordion 1.2",o.portal,9)}
                </button>
                <div class="chi-accordion__content">
                  <p class="chi-accordion__text">Content of Accordion item 1.2</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="chi-accordion__item">
          <button class="chi-accordion__trigger">
           ${l("Accordion 2",o.portal,6)}
          </button>
          <div class="chi-accordion__content">
            <p class="chi-accordion__text">Content of Accordion item 2</p>
            <div class="chi-accordion">
              <div class="chi-accordion__item">
                <button class="chi-accordion__trigger">
                  ${l("Accordion 2.1",o.portal,9)}
                </button>
                <div class="chi-accordion__content">
                  <p class="chi-accordion__text">Content of Accordion item 2.1</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  const accordionNested = document.getElementById('example-nested');

if (accordionNested) {
  chi.accordion(accordionNested);
}
<//script>`};return(d,r)=>{const x=C,b=$,w=y;return v(),B(w,{title:"Nested",id:"nested",padding:"-p--3 -p-lg--6"},{example:a(()=>[c("chi-accordion",{ref:"main-accordion",portal:n.portal},[c("div",P,[c("chi-accordion",{ref:"parent-accordion",portal:n.portal},[c("div",Y,[r[1]||(r[1]=c("p",{class:"chi-accordion__text"},"Content of Accordion item 1",-1)),c("chi-accordion",{ref:"child-accordion-1",portal:n.portal},[c("div",oo,[r[0]||(r[0]=c("p",{class:"chi-accordion__text -mb--2"},"Content of Accordion item 1.1",-1)),c("chi-accordion",{ref:"grandchild-accordion",portal:n.portal},null,8,co)])],8,Z)]),c("div",to,[r[2]||(r[2]=c("p",{class:"chi-accordion__text"},"Content of Accordion item 2",-1)),c("chi-accordion",{ref:"child-accordion-2",portal:n.portal},null,8,no)])],8,X)])],8,K)]),"code-webcomponent":a(()=>[t(x,{lang:"html",code:A.webcomponent},null,8,["code"])]),"code-htmlblueprint":a(()=>[t(b),t(x,{lang:"html",code:A.htmlblueprint},null,8,["code"])]),_:1})}}}),io=["portal"],eo={slot:"parent-accordion-content"},ao=["portal"],J=f({__name:"_methods",props:{portal:{type:Boolean}},setup(n){const o=n,i=g("parent-accordion"),e=g("child-accordion");E(()=>{i.value&&(i.value.accordions=[{title:"Accordion",template:"parent-accordion-content",expanded:!0}]),e.value&&(e.value.accordions=[{title:"Accordion 1",text:"Content of Accordion item 1"},{title:"Accordion 2",text:"Content of Accordion item 2"}])});const _=p=>e.value.toggle(p),h={webcomponent:`<chi-button id="toggle-accordion-1"> Toggle item 1 </chi-button>
<chi-button id="toggle-accordion-2" class="-ml--1"> Toggle item 2 </chi-button>
  
<chi-accordion id="parent-accordion" class="-d--block -mt--2"${o.portal?" portal":""}>
  <div slot="parent-accordion-content">
    <chi-accordion id="child-accordion"${o.portal?" portal":""}></chi-accordion>
  </div>
</chi-accordion>

<script>
  const parentAccordion = document.getElementById('parent-accordion');
  const childAccordion = document.getElementById('child-accordion');
  const toggleAccordionOne = document.getElementById("toggle-accordion-1");
  const toggleAccordionTwo = document.getElementById("toggle-accordion-2");

  parentAccordion.accordions = [{ title: 'Accordion', template: 'parent-accordion-content', expanded: true }];
  childAccordion.accordions = [
    { title: 'Accordion 1', text: 'Content of Accordion item 1' },
    { title: 'Accordion 2', text: 'Content of Accordion item 2' },
   ];

  toggleAccordionOne.addEventListener("click", () => childAccordion.toggle(0));
  toggleAccordionTwo.addEventListener("click", () => childAccordion.toggle(1));
<\/script>`,htmlblueprint:`<button class="chi-button" id="toggle-accordion-1">Toggle item 1</button>
<button class="chi-button" id="toggle-accordion-2">Toggle item 2</button>

<div class="chi-accordion" id="individual-accordion-items">
  <div class="chi-accordion__item -expanded">
    <button class="chi-accordion__trigger">
      ${l("Accordion",o.portal)}
    </button>
    <div class="chi-accordion__content">
      <div class="chi-accordion">
        <div class="chi-accordion__item" id="invividual-accordion-item-1">
          <button class="chi-accordion__trigger">
            ${l("Accordion item 1",o.portal,6)}
          </button>
          <div class="chi-accordion__content">
            <p class="chi-accordion__text">Content of Accordion item 1</p>
          </div>
        </div>
        <div class="chi-accordion__item" id="invividual-accordion-item-2">
          <button class="chi-accordion__trigger">
            ${l("Accordion item 2",o.portal,6)}
          </button>
          <div class="chi-accordion__content">
            <p class="chi-accordion__text">Content of Accordion item 2</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  const individualAccordions = chi.accordion(document.getElementById("individual-accordion-items"));
  const toggleAccordionOne = document.getElementById("toggle-accordion-1");
  const toggleAccordionTwo = document.getElementById("toggle-accordion-2");

  toggleAccordionOne.addEventListener("click", () => {
    individualAccordions.toggle(document.getElementById("invividual-accordion-item-1"));
  });

  toggleAccordionTwo.addEventListener("click", () => {
    individualAccordions.toggle(document.getElementById("invividual-accordion-item-2"));
  });
<\/script>`};return(p,s)=>{const m=C,A=$,d=y;return v(),B(d,{title:"Show / Hide / Toggle of individual items of Accordion",id:"methods",padding:"-p--3 p-lg--6"},{example:a(()=>[c("chi-button",{onClick:s[0]||(s[0]=r=>_(0))},"Toggle item 1"),c("chi-button",{class:"-ml--1",onClick:s[1]||(s[1]=r=>_(1))},"Toggle item 2"),c("chi-accordion",{class:"-d--block -mt--2",ref:"parent-accordion",portal:n.portal},[c("div",eo,[c("chi-accordion",{ref:"child-accordion",portal:n.portal},null,8,ao)])],8,io)]),"code-webcomponent":a(()=>[t(m,{class:"html",lang:"html",code:h.webcomponent},null,8,["code"])]),"code-htmlblueprint":a(()=>[t(A),t(m,{lang:"html",code:h.htmlblueprint},null,8,["code"])]),_:1})}}}),ro=["portal"],lo={slot:"main-accordion-content"},so=["portal"],po={slot:"parent-accordion-1-content"},mo=["portal"],ho={slot:"parent-accordion-2-content"},_o=["portal"],D=f({__name:"_expand_collapse_all",props:{portal:{type:Boolean}},setup(n){const o=n,i=g("main-accordion"),e=g("parent-accordion"),_=g("child-accordion-1"),h=g("child-accordion-2"),p=[i,e,_,h],s=()=>p.forEach(x=>x.value?.show()),m=()=>p.forEach(x=>x.value?.hide()),A=(x,b)=>{x?.value&&(x.value.accordions=b)};E(()=>{A(i,[{title:"Accordion",template:"main-accordion-content",expanded:!0}]),A(e,[{title:"Accordion item 1",template:"parent-accordion-1-content"},{title:"Accordion item 2",template:"parent-accordion-2-content"}]),A(_,[{title:"Accordion item 1.1",text:"Content of Accordion item 1.1"},{title:"Accordion item 1.2",text:"Content of Accordion item 1.2"}]),A(h,[{title:"Accordion item 2.1",text:"Content of Accordion item 2.1"},{title:"Accordion item 2.2",text:"Content of Accordion item 2.2"}])});const d=o.portal?" portal":"",r={webcomponent:`<chi-button id="expand-all-button">Expand all</chi-button>
<chi-button id="collapse-all-button" class="-ml--1">Collapse all</chi-button>

<chi-accordion id="main-accordion" class="-d--block -mt--2"${d}>
  <div slot="main-accordion-content">
    <chi-accordion id="parent-accordion"${d}>
      <div slot="parent-accordion-1-content">
        <p class="chi-accordion__text">Content of Accordion item 1</p>
        <chi-accordion id="child-accordion-1"${d}></chi-accordion>
      </div>
      <div slot="parent-accordion-2-content">
        <p class="chi-accordion__text">Content of Accordion item 2</p>
        <chi-accordion id="child-accordion-2"${d}></chi-accordion>
      </div>
    </chi-accordion>
  </div>
</chi-accordion>

<script>
  const mainAccordion = document.getElementById('main-accordion');
  const parentAccordion = document.getElementById('parent-accordion');
  const childAccordionOne = document.getElementById('child-accordion-1');
  const childAccordionTwo = document.getElementById('child-accordion-2');
  const expandAllButton = document.getElementById("expand-all-button");
  const collapseAllButton = document.getElementById("collapse-all-button");

  mainAccordion.accordions = [{ title: 'Accordion', template: 'main-accordion-content', expanded: true }];
  parentAccordion.accordions = [
    { title: 'Accordion item 1', template: 'parent-accordion-1-content' },
    { title: 'Accordion item 2', template: 'parent-accordion-2-content' },
  ];
  childAccordionOne.accordions = [
    { title: 'Accordion item 1.1', text: 'Content of Accordion item 1.1' },
    { title: 'Accordion item 1.2', text: 'Content of Accordion item 1.2' },
  ];
  childAccordionTwo.accordions = [
    { title: 'Accordion item 2.1', text: 'Content of Accordion item 2.1' },
    { title: 'Accordion item 2.2', text: 'Content of Accordion item 2.2' }
  ];

  const accordions = [mainAccordion, parentAccordion, childAccordionOne, childAccordionTwo];

  const expandAll = () => accordions.forEach(accordion => accordion.show());
  const collapseAll = () => accordions.forEach(accordion => accordion.hide());

  expandAllButton.addEventListener("click", expandAll);
  collapseAllButton.addEventListener("click", collapseAll);
<\/script>`,htmlblueprint:`<button class="chi-button" id="expand-all">Expand all</button>
<button class="chi-button" id="collapse-all">Collapse all</button>

<div class="chi-accordion" id="expand-collapse">
  <div class="chi-accordion__item -expanded">
    <button class="chi-accordion__trigger">
      ${l("Accordion",o.portal)}
    </button>
    <div class="chi-accordion__content">
      <div class="chi-accordion">
        <div class="chi-accordion__item">
          <button class="chi-accordion__trigger">
            ${l("Accordion item 1",o.portal,6)}
          </button>
          <div class="chi-accordion__content">
            <p class="chi-accordion__text">Content of Accordion item 1</p>
            <div class="chi-accordion">
              <div class="chi-accordion__item">
                <button class="chi-accordion__trigger">
                  ${l("Accordion item 1.1",o.portal,9)}
                </button>
                <div class="chi-accordion__content">
                  <p class="chi-accordion__text">Content of Accordion item 1.1</p>
                </div>
              </div>
              <div class="chi-accordion__item">
                <button class="chi-accordion__trigger">
                  ${l("Accordion item 1.2",o.portal,9)}
                </button>
                <div class="chi-accordion__content">
                  <p class="chi-accordion__text">Content of Accordion item 1.2</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="chi-accordion__item">
          <button class="chi-accordion__trigger">
            ${l("Accordion item 2",o.portal,6)}
          </button>
          <div class="chi-accordion__content">
            <p class="chi-accordion__text">Content of Accordion item 2</p>
            <div class="chi-accordion">
              <div class="chi-accordion__item">
                <button class="chi-accordion__trigger">
                  ${l("Accordion item 2.1",o.portal,9)}
                </button>
                <div class="chi-accordion__content">
                  <p class="chi-accordion__text">Content of Accordion item 2.1</p>
                </div>
              </div>
              <div class="chi-accordion__item">
                <button class="chi-accordion__trigger">
                  ${l("Accordion item 2.2",o.portal,9)}
                </button>
                <div class="chi-accordion__content">
                  <p class="chi-accordion__text">Content of Accordion item 2.2</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  const expandCollapseAccordion = chi.accordion(document.getElementById("expand-collapse"));
  const expandAll = document.getElementById("expand-all");
  const collapseAll = document.getElementById("collapse-all");

  expandAll.addEventListener("click", () => expandCollapseAccordion.expandAll());
  collapseAll.addEventListener("click", () => expandCollapseAccordion.collapseAll());
<\/script>`};return(x,b)=>{const w=C,I=$,T=y;return v(),B(T,{title:"Expand / Collapse all Accordion items",id:"expand_collapse_all",padding:"-p--3 p-lg--6"},{example:a(()=>[c("chi-button",{onClick:s},"Expand all"),c("chi-button",{class:"-ml--1",onClick:m},"Collapse all"),c("chi-accordion",{class:"-d--block -mt--2",ref:"main-accordion",portal:n.portal},[c("div",lo,[c("chi-accordion",{ref:"parent-accordion",portal:n.portal},[c("div",po,[b[0]||(b[0]=c("p",{class:"chi-accordion__text"},"Content of Accordion item 1",-1)),c("chi-accordion",{ref:"child-accordion-1",portal:n.portal},null,8,mo)]),c("div",ho,[b[1]||(b[1]=c("p",{class:"chi-accordion__text"},"Content of Accordion item 2",-1)),c("chi-accordion",{ref:"child-accordion-2",portal:n.portal},null,8,_o)])],8,so)])],8,ro)]),"code-webcomponent":a(()=>[t(w,{class:"html",lang:"html",code:r.webcomponent},null,8,["code"])]),"code-htmlblueprint":a(()=>[t(I),t(w,{lang:"html",code:r.htmlblueprint},null,8,["code"])]),_:1})}}}),uo=["portal"],j=f({__name:"_disabled",props:{portal:{type:Boolean}},setup(n){const o=n,i=g("example-disabled");E(()=>{i.value&&(i.value.accordions=[{title:"Accordion 1",text:"Content goes here",disabled:!0}])});const e={webcomponent:`<chi-accordion id="example-disabled"${o.portal?" portal":""}></chi-accordion>

<script>
  const accordionDisabled = document.getElementById('example-disabled');

  accordionDisabled.accordions = [{ title: 'Accordion 1', text: 'Content goes here', disabled: true }];
<\/script>`,htmlblueprint:`<div class="chi-accordion">
  <div class="chi-accordion__item">
    <button class="chi-accordion__trigger -disabled">
      ${l("Accordion 1",o.portal)}
    </button>
    <div class="chi-accordion__content">
      <p class="chi-accordion__text">Content goes here</p>
    </div>
  </div>
</div>`};return(_,h)=>{const p=C,s=$,m=y;return v(),B(m,{title:"Disabled",id:"disabled",padding:"-p--3 p-lg--6"},{"example-description":a(()=>[...h[0]||(h[0]=[c("p",{class:"-text"},[u("Make Accordions appear inactive by adding the property "),c("code",null,"disabled"),u(" in accordions list.")],-1)])]),example:a(()=>[c("chi-accordion",{ref:"example-disabled",portal:n.portal},null,8,uo)]),"code-webcomponent":a(()=>[t(p,{class:"html",lang:"html",code:e.webcomponent},null,8,["code"])]),"code-htmlblueprint":a(()=>[t(s),t(p,{lang:"html",code:e.htmlblueprint},null,8,["code"])]),_:1})}}}),go=["portal"],q=f({__name:"_truncated",props:{portal:{type:Boolean}},setup(n){const o=n,i=g("example-truncated");E(()=>{i.value&&(i.value.accordions=[{title:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis tellus enim. Nulla facilisi. Donec tortor elit, finibus ut lacus vel, elementum accumsan ex",text:"Content goes here"}])});const e={webcomponent:`<chi-accordion id="example-truncated" truncated${o.portal?" portal":""}></chi-accordion>

<script>
  const accordionTruncated = document.getElementById('example-truncated');

  accordionTruncated.accordions = [
    {
      title:
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis tellus enim. Nulla facilisi. Donec tortor elit, finibus ut lacus vel, elementum accumsan ex',
      text: 'Content goes here',
    },
  ];
<\/script>`,htmlblueprint:`<div id="example-truncated" class="chi-accordion -truncated">
  <div class="chi-accordion__item">
    <button class="chi-accordion__trigger">
      ${l("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis tellus enim. Nulla facilisi. Donec tortor elit, finibus ut lacus vel, elementum accumsan ex",o.portal)}
    </button>
    <div class="chi-accordion__content">
      <p class="chi-accordion__text">Content goes here</p>
    </div>
  </div>
</div>

<script>
  const accordionTruncated = document.getElementById('example-truncated');

  if (accordionTruncated) {
    chi.accordion(accordionTruncated);
  }
<\/script>`};return(_,h)=>{const p=C,s=$,m=y;return v(),B(m,{title:"Truncated",id:"truncated",padding:"-p--3 -p-lg--6"},{"example-description":a(()=>[...h[0]||(h[0]=[c("p",{class:"-text"},[u("Truncate long accordion titles by adding property "),c("code",null,"truncated"),u(" to "),c("code",null,"chi-accordion"),u(".")],-1)])]),example:a(()=>[c("chi-accordion",{ref:"example-truncated",portal:n.portal,truncated:""},null,8,go)]),"code-webcomponent":a(()=>[t(p,{class:"html",lang:"html",code:e.webcomponent},null,8,["code"])]),"code-htmlblueprint":a(()=>[t(s),t(p,{lang:"html",code:e.htmlblueprint},null,8,["code"])]),_:1})}}}),vo=["portal"],Ao=`<div id="example-link" class="chi-accordion -link -md">
  <div class="chi-accordion__item">
    <button class="chi-accordion__trigger">
      <div class="chi-link -no-underline">Accordion 1</div>
      <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
    </button>
    <div class="chi-accordion__content">
      <p class="chi-accordion__text">Content goes here</p>
    </div>
  </div>
</div>

<script>
  const accordionLink = document.getElementById('example-link');

  if (accordionLink) {
    chi.accordion(accordionLink);
  }
<\/script>
`,z=f({__name:"_link",props:{portal:{type:Boolean}},setup(n){const o=n,i=g("example-link");E(()=>{i.value&&(i.value.accordions=[{title:"Accordion 1",text:"Content goes here"}])});const _={webcomponent:`<chi-accordion id="example-link" type="link" ${o.portal?"portal":""}></chi-accordion>

<script>
const accordion = document.getElementById('example-link');

accordion.accordions = [
  {
    title: 'Accordion 1',
    text: 'Content goes here',
  },
];
<\/script>`,htmlblueprint:Ao};return(h,p)=>{const s=C,m=$,A=y;return v(),B(A,{title:"Link",id:"link",padding:"-p--3 -p-lg--6"},{"example-description":a(()=>[...p[0]||(p[0]=[c("p",{class:"-text"},[u("Add a link type to your accordion by adding property "),c("code",null,'type="link"'),u(" to "),c("code",null,"chi-accordion"),u(".")],-1)])]),example:a(()=>[c("chi-accordion",{ref:"example-link",portal:n.portal,type:"link"},null,8,vo)]),"code-webcomponent":a(()=>[t(s,{class:"html",lang:"html",code:_.webcomponent},null,8,["code"])]),"code-htmlblueprint":a(()=>[t(m),t(s,{lang:"html",code:_.htmlblueprint},null,8,["code"])]),_:1})}}}),xo={class:"-text"},bo={key:0},fo={class:"-text--bold -pl--2"},Co=["size","portal"],H=f({__name:"_sizes",props:{portal:{type:Boolean}},setup(n){const o=n,i=o.portal?["sm","md"]:["sm","md","lg","xl"],e=V([]);E(()=>{e.value.forEach(d=>{d&&(d.accordions=[{title:"Accordion",text:"Content goes here"}])})});function _(d){return`<!-- ${d} -->
<chi-accordion id="example-size-${d}" size="${d}"${o.portal?" portal":""}></chi-accordion>`}function h(d){return`const accordionSize${d.charAt(0).toUpperCase()+d.slice(1)} = document.getElementById('example-size-${d}');`}function p(d){return`accordionSize${d.charAt(0).toUpperCase()+d.slice(1)}.accordions = [{ title: 'Accordion', text: 'Content goes here' }];`}function s(d){return`<!-- ${d}-->
<div class="chi-accordion -${d}" id="example-size-${d}">
  <div class="chi-accordion__item">
    <button class="chi-accordion__trigger">
      ${l("Accordion",o.portal)}
    </button>
    <div class="chi-accordion__content">
      <p class="chi-accordion__text">Content goes here</p>
    </div>
  </div>
</div>`}function m(d){return`chi.accordion(document.getElementById('example-size-${d}'));`}const A={webcomponent:`${i.map(_).join(`

`)}

<script>
  ${i.map(h).join(`
  `)}
 
  ${i.map(p).join(`
  `)}
<\/script>`,htmlblueprint:`${i.map(s).join(`

`)}

<script>
  ${i.map(m).join(`
  `)}
<\/script>`};return(d,r)=>{const x=C,b=$,w=y;return v(),B(w,{title:"Sizes",id:"sizes",padding:"-p--3 -p-lg--6"},{"example-description":a(()=>[c("p",xo,[r[1]||(r[1]=u("Accordion supports the following sizes: ",-1)),r[2]||(r[2]=c("code",null,"sm",-1)),r[3]||(r[3]=u(", ",-1)),r[4]||(r[4]=c("code",null,"md",-1)),r[5]||(r[5]=u(" (default)",-1)),n.portal?N("",!0):(v(),k("span",bo,[...r[0]||(r[0]=[u(", ",-1),c("code",null,"lg",-1),u(", and ",-1),c("code",null,"xl",-1)])])),r[6]||(r[6]=u(".",-1))])]),example:a(()=>[(v(!0),k(R,null,W(S(i),I=>(v(),k(R,{key:I},[c("p",fo,F(I),1),c("chi-accordion",{size:I,portal:n.portal,ref_for:!0,ref:T=>e.value.push(T)},null,8,Co)],64))),128))]),"code-webcomponent":a(()=>[t(x,{class:"html",lang:"html",code:A.webcomponent},null,8,["code"])]),"code-htmlblueprint":a(()=>[t(b),t(x,{lang:"html",code:A.htmlblueprint},null,8,["code"])]),_:1})}}}),$o={key:0},yo={key:1},Io=f({__name:"index",setup(n){const o=U();return(i,e)=>(v(),k("div",null,[e[0]||(e[0]=c("h2",null,"Examples",-1)),e[1]||(e[1]=c("p",{class:"-text"},[u("To render accordion, use the class "),c("code",null,"chi-accordion"),u(".")],-1)),["lumen","centurylink"].includes(S(o))?(v(),k("div",$o,[t(L),t(z),t(O),t(J),t(D),t(j),t(q),t(H)])):N("",!0),S(o)==="portal"?(v(),k("div",yo,[t(L,{portal:""}),t(G,{portal:""}),t(z,{portal:""}),t(O,{portal:""}),t(J,{portal:""}),t(D,{portal:""}),t(j,{portal:""}),t(q,{portal:""}),t(H,{portal:""})])):N("",!0)]))}});export{Io as _};
