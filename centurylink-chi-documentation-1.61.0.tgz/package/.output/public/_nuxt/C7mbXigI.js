import{_ as q}from"./DY7FbNsl.js";import{_ as x}from"./DnPF01B5.js";import{_ as $}from"./CdcsEwU-.js";import{a as F,F as O,v as N,C as U}from"./CAeTtF-c.js";import{e as w,Q as A,g as f,x as L,a8 as m,a9 as T,H as b,i as y,o as n,w as v,b as _,a as i,c as d,S as h,k as e,l as D,d as g,F as G}from"./DBXeQHmC.js";const K=r=>" ".repeat(2*r),Q=r=>r.map((c,t)=>`
${K(7)}<a class="chi-dropdown__menu-item${t===0?" -active":""}" href="${c.href}">${c.name}</a>`).join(""),Y=r=>`<footer class="chi-footer" slot="footer">
    <div class="chi-footer__content">
      <div class="chi-footer__internal">
        <div class="chi-footer__internal-content -mw--1200">
          <div class="chi-dropdown chi-footer__language">
            <a 
              class="chi-button -icon -flat -light -sm chi-dropdown__trigger" 
              id="${r}" 
              data-position="top-start" 
              aria-label="Select your preferred language"
            >
              <div class="chi-button__content">
                <i class="chi-flag-icon icon-us" aria-hidden="true"></i>
              </div>
            </a>
            <div class="chi-dropdown__menu -w--sm -text--body">${Q(O)}
            </div>
          </div>
          <div class="chi-footer__links">
            <ul>
              ${F.map(({href:c,title:t,target:a})=>`<li>
                <a href="${c}"${a?` target="${a}"`:""}>${t}</a>
              </li>`).join(`
              `)}
            </ul>
            <div class="chi-footer__copyright">&copy; 2026 Lumen Technologies. All Rights Reserved. Lumen is a registered trademark in the United States, EU and certain other countries.</div>
          </div>
        </div>
      </div>
    </div>
  </footer>`,R=(r,c)=>`<footer class="chi-footer" slot="footer">
    <div class="chi-footer__content">
      <div class="chi-footer__internal">
        <div class="chi-footer__internal-content -mw--1200">
          <div class="chi-footer__links">
            <ul>
              ${r.map(({href:t,title:a,target:o})=>`<li>
                <a href="${t}"${o?` target="${o}"`:""}>${a}</a>
              </li>`).join(`
              `)}
            </ul>
            <div class="chi-footer__copyright">${c==="colt"?"© 2024 Colt Technology Services Group Limited":"© 2024 CenturyLink. All Rights Reserved. Third party marks are the property of their respective owners."}</div>
          </div>
        </div>
      </div>
    </div>
  </footer>`,J=r=>`<footer class="chi-footer">
    <div class="chi-footer__content">
      <div class="chi-footer__internal">
        <div class="chi-footer__internal-content -mw--1200">
          <div class="chi-dropdown chi-footer__language">
            <a class="chi-button -icon -flat -light -sm chi-dropdown__trigger" id="${r}" data-position="top-start" aria-label="Select your preferred language">
              <div class="chi-button__content">
                <i class="chi-icon icon-globe-network-outline" aria-hidden="true"></i>
                <span>English</span>
              </div>
            </a>
            <div class="chi-dropdown__menu -w--sm -text--body">
              ${O.map(({href:c,name:t},a)=>`<a class="chi-dropdown__menu-item${a===0?" -active":""}" href="${c}">${t}</a>`).join(`
              `)}
            </div>
          </div>
          <div class="chi-footer__links">
            <ul>
              ${F.map(({href:c,title:t,target:a})=>`<li>
                <a href="${c}"${a?` target="${a}"`:""}>${t}</a>
              </li>`).join(`
              `)}
            </ul>
            <div class="chi-footer__copyright">&copy; 2026 Lumen Technologies. All Rights Reserved. Lumen is a registered trademark in the United States, EU and certain other countries.</div>
          </div>
        </div>
      </div>
    </div>
  </footer>`,k=(r="lumen",c="language-dropdown-button")=>{switch(r){case"brightspeed":return J(c);case"centurylink":return R(U,r);case"colt":return R(N,r);default:return Y(c)}},W=(r="language-dropdown-button")=>({lumen:k("lumen",r),centurylink:k("centurylink",r),brightspeed:k("brightspeed",r),colt:k("colt",r)}),p=r=>{const c=document.getElementById(r);c&&chi.dropdown(c)},X={title:"Page Title","help-position":"right"},Z={class:"-d--inline-flex",slot:"help-icon"},ii={slot:"footer"},ci=["innerHTML"],ei=["innerHTML"],ti=["innerHTML"],li=["innerHTML"],z="help-icon-language-dropdown-button",si=w({__name:"_help_icon",setup(r){const c=A("drawer"),t=f(),a=W(z);L(async()=>{await m(),p(z)}),T(t,async s=>{await m(),p(z)});const o=b(()=>{const s=k(t.value,z);return{webcomponent:`<chi-main title="Page Title" help-position="right">
  <chi-button id="example__help-button" alternative-text="Help" slot="help-icon">
    <chi-icon icon="circle-question-outline" size="sm"></chi-icon>
    <span>Help</span>
  </chi-button>
  <!-- Page content goes here -->
  ${s}
</chi-main>
<chi-drawer id="example__help-drawer" title="Title" position="right" backdrop>
  <chi-label size="xl">Search</chi-label>
  <chi-search-input placeholder="I need help with..."></chi-search-input>
  <div class="chi-form__item">
    <chi-label class="-mt--4 -mb--2" size="xl">Subtitle 1</chi-label>
    <chi-link class="-mb--1" href="#" size="sm">Link 1</chi-link>
    <chi-link href="#" size="sm">Link 2</chi-link>
  </div>
  <div class="chi-form__item">
    <chi-label class="-mt--4 -mb--2" size="xl">Subtitle 2</chi-label>
    <chi-link class="-mb--1" href="#" size="sm">Link 1</chi-link>
    <chi-link class="-mb--1" href="#" size="sm">Link 2</chi-link>
    <chi-link class="-mb--1" href="#" size="sm">Link 3</chi-link>
    <chi-link href="#" size="sm">Link 4</chi-link>
  </div>
  <div class="chi-divider -my--2"></div>
  <chi-link href="#" size="sm">Link</chi-link>
</chi-drawer>

<script>${t.value==="centurylink"||t.value==="colt"?"":`
  chi.dropdown(document.getElementById('${z}'));`}
  document.querySelector("#example__help-button")
    .addEventListener("click", function() {
      var drawerElem = document.querySelector("#example__help-drawer");
      drawerElem.toggle();
    });
<\/script>`,htmlblueprint:`<div class="chi-main">
  <div class="chi-main__header">
    <div class="chi-main__header-start">
      <div class="chi-main__title">
        <div class="chi-main__title-heading">
          Page Title
        </div>
      </div>
    </div>
    <div class="chi-main__header-end">
      <div class="chi-button" id="example__help-button"  data-position="right-start" data-target="#example__help-popover" aria-label="Help" slot="help-icon">
        <div class="chi-button__content">
          <i class="chi-icon icon-circle-question-outline" aria-hidden="true"></i>
          <span>Help</span>
        </div>
      </div>
      <section class="chi-popover chi-popover--right-start" id="example__help-popover" aria-modal="true" role="dialog">
        <div class="chi-popover__content">
          <p class="chi-popover__text">Popover content.</p>
        </div>
      </section>
    </div>
  </div>
  <div class="chi-main__content">
    <!-- Page content goes here -->
  </div>
  ${s}
</div>

<script>${t.value==="centurylink"||t.value==="colt"?"":`
  chi.dropdown(document.getElementById('${z}'));`}
  chi.popover(document.getElementById('example__help-button'));
<\/script>`}});return(s,l)=>{const u=x,C=$;return n(),y(C,{title:"Base with help icon",id:"base_with_help_icon",padding:"0"},{example:v(()=>[i("chi-main",X,[i("div",Z,[i("chi-button",{id:"help-icon__help-button","alternative-text":"Help",onClick:l[0]||(l[0]=H=>c.value.toggle())},[...l[1]||(l[1]=[i("chi-icon",{icon:"circle-question-outline",size:"sm"},null,-1),i("span",null,"Help",-1)])])]),l[2]||(l[2]=i("div",{class:"-d--flex -align-items--center -justify-content--center",style:{height:"10rem"}},"Page content goes here",-1)),i("div",ii,[["lumen","portal"].includes(e(t))?(n(),d("div",{key:0,innerHTML:e(a).lumen},null,8,ci)):h("",!0),e(t)==="centurylink"?(n(),d("div",{key:1,innerHTML:e(a).centurylink},null,8,ei)):h("",!0),e(t)==="brightspeed"?(n(),d("div",{key:2,innerHTML:e(a).brightspeed},null,8,ti)):h("",!0),e(t)==="colt"?(n(),d("div",{key:3,innerHTML:e(a).colt},null,8,li)):h("",!0)])]),i("chi-drawer",{id:"help-icon-drawer-example",ref_key:"drawer",ref:c,title:"Title",position:"right",backdrop:""},[i("div",{class:D(`${e(t)!=="connect"?"-p--4":""}`)},[...l[3]||(l[3]=[i("chi-label",{size:"xl"},"Search",-1),i("chi-search-input",{placeholder:"I need help with..."},null,-1),i("div",{class:"chi-form__item"},[i("chi-label",{class:"-mt--4 -mb--2",size:"xl"},"Subtitle 1"),i("chi-link",{class:"-mb--1",href:"#",size:"sm"},"Link 1"),i("chi-link",{href:"#",size:"sm"},"Link 2")],-1),i("div",{class:"chi-form__item"},[i("chi-label",{class:"-mt--4 -mb--2",size:"xl"},"Subtitle 2"),i("chi-link",{class:"-mb--1",href:"#",size:"sm"},"Link 1"),i("chi-link",{class:"-mb--1",href:"#",size:"sm"},"Link 2"),i("chi-link",{class:"-mb--1",href:"#",size:"sm"},"Link 3"),i("chi-link",{href:"#",size:"sm"},"Link 4 ")],-1),i("div",{class:"chi-divider -my--2"},null,-1),i("chi-link",{href:"#",size:"sm"},"Link",-1)])],2)],512)]),"code-webcomponent":v(()=>[_(u,{class:"html",lang:"html",code:o.value.webcomponent},null,8,["code"])]),"code-htmlblueprint":v(()=>[_(u,{class:"html",lang:"html",code:o.value.htmlblueprint},null,8,["code"])]),_:1})}}}),ni={title:"Page Title"},ai={slot:"footer"},di=["innerHTML"],oi=["innerHTML"],hi=["innerHTML"],ri=["innerHTML"],M="alert-language-dropdown-button",vi=w({__name:"_alert",setup(r){const c=f(),t=W(M);L(async()=>{await m(),p(M)}),T(c,async o=>{await m(),p(M)});const a=b(()=>{const o=k(c.value,M);return{webcomponent:`<chi-main title="Page Title">
  <chi-alert color="info" icon="circle-info" slot="page-alert" closable>This is a page level info alert</chi-alert>
  <!-- Page content goes here -->
  ${o}
</chi-main>${c.value==="centurylink"||c.value==="colt"?"":`

<script>chi.dropdown(document.getElementById(${M}));<\/script>`}`,htmlblueprint:`<div class="chi-main">
  <div class="chi-main__alert">
    <div class="chi-alert -info -close" role="alert">
      <i class="chi-alert__icon chi-icon icon-circle-info" aria-hidden="true"></i>
      <div class="chi-alert__content">
        <p class="chi-alert__text">This is a page level info alert</p>
      </div>
      <button class="chi-alert__close-button chi-button -icon -close" aria-label="Close">
        <div class="chi-button__content">
          <i class="chi-icon icon-x" aria-hidden="true"></i>
        </div>
      </button>
    </div>
  </div>
  <div class="chi-main__header">
    <div class="chi-main__header-start">
      <div class="chi-main__title">
        <div class="chi-main__title-heading">
          Page Title
        </div>
      </div>
    </div>
  </div>
  <div class="chi-main__content">
    <!-- Page content goes here -->
  </div>
  ${o}
</div>${c.value==="centurylink"||c.value==="colt"?"":`

<script>chi.dropdown(document.getElementById(${M}));<\/script>`}`}});return(o,s)=>{const l=x,u=$;return n(),y(u,{title:"Base with alert",id:"base_with_alert",padding:"0"},{example:v(()=>[i("chi-main",ni,[s[0]||(s[0]=i("div",{slot:"page-alert"},[i("chi-alert",{color:"info",icon:"circle-info",closable:""},"This is a page level info alert")],-1)),s[1]||(s[1]=i("div",{class:"-d--flex -align-items--center -justify-content--center",style:{height:"10rem"}},"Page content goes here",-1)),i("div",ai,[["lumen","portal"].includes(e(c))?(n(),d("div",{key:0,innerHTML:e(t).lumen},null,8,di)):h("",!0),e(c)==="centurylink"?(n(),d("div",{key:1,innerHTML:e(t).centurylink},null,8,oi)):h("",!0),e(c)==="brightspeed"?(n(),d("div",{key:2,innerHTML:e(t).brightspeed},null,8,hi)):h("",!0),e(c)==="colt"?(n(),d("div",{key:3,innerHTML:e(t).colt},null,8,ri)):h("",!0)])])]),"code-webcomponent":v(()=>[s[2]||(s[2]=i("div",{class:"chi-tab__description"},[g("Use the "),i("code",null,'title=""'),g(" attribute to display a title above the application layout.")],-1)),_(l,{class:"html",lang:"html",code:a.value.webcomponent},null,8,["code"])]),"code-htmlblueprint":v(()=>[_(l,{class:"html",lang:"html",code:a.value.htmlblueprint},null,8,["code"])]),_:1})}}}),_i={title:"Page Title"},ui={slot:"footer"},mi=["innerHTML"],pi=["innerHTML"],gi=["innerHTML"],ki=["innerHTML"],P="base-language-dropdown-button",bi=w({__name:"_base",setup(r){const c=f(),t=W(P),a=b(()=>{const l=k(c.value,P);return{webcomponent:o(l),htmlblueprint:s(l)}});L(async()=>{await m(),p(P)}),T(c,async l=>{await m(),p(P)});const o=l=>`<chi-main title="Page Title">
  <!-- Page content goes here -->
  ${l}
</chi-main>${c.value==="centurylink"||c.value==="colt"?"":`

<script>chi.dropdown(document.getElementById('${P}'));<\/script>`}`,s=l=>`<div class="chi-main">
  <div class="chi-main__header">
    <div class="chi-main__header-start">
      <div class="chi-main__title">
        <div class="chi-main__title-heading">Page Title</div>
      </div>
    </div>
  </div>
  <div class="chi-main__content">
    <!-- Page content goes here -->
  </div>
  ${l}
</div>${c.value==="centurylink"||c.value==="colt"?"":`

<script>chi.dropdown(document.getElementById('${P}'));<\/script>`}`;return(l,u)=>{const C=x,H=$;return n(),y(H,{title:"Base",id:"base",padding:"0"},{example:v(()=>[i("chi-main",_i,[u[0]||(u[0]=i("div",{class:"-d--flex -align-items--center -justify-content--center",style:{height:"10rem"}},"Page content goes here",-1)),i("div",ui,[["lumen","portal"].includes(e(c))?(n(),d("div",{key:0,innerHTML:e(t).lumen},null,8,mi)):h("",!0),e(c)==="centurylink"?(n(),d("div",{key:1,innerHTML:e(t).centurylink},null,8,pi)):h("",!0),e(c)==="brightspeed"?(n(),d("div",{key:2,innerHTML:e(t).brightspeed},null,8,gi)):h("",!0),e(c)==="colt"?(n(),d("div",{key:3,innerHTML:e(t).colt},null,8,ki)):h("",!0)])])]),"code-webcomponent":v(()=>[u[1]||(u[1]=i("div",{class:"chi-tab__description"},[g("Use the "),i("code",null,'title=""'),g(" attribute to display a title above the application layout.")],-1)),_(C,{lang:"html",code:a.value.webcomponent},null,8,["code"])]),"code-htmlblueprint":v(()=>[_(C,{class:"html",lang:"html",code:a.value.htmlblueprint},null,8,["code"])]),_:1})}}}),wi={backlink:"Back link",title:"Page Title"},fi={slot:"footer"},yi=["innerHTML"],xi=["innerHTML"],$i=["innerHTML"],Li=["innerHTML"],V="back-link-language-dropdown-button",Ti=w({__name:"_back_link",setup(r){const c=f(),t=W(V);L(async()=>{await m(),p(V)}),T(c,async o=>{await m(),p(V)});const a=b(()=>{const o=k(c.value,V);return{webcomponent:`<chi-main backlink="Back link" title="Page Title">
  <!-- Page content goes here -->
  ${o}
</chi-main>${c.value==="centurylink"||c.value==="colt"?"":`

<script>chi.dropdown(document.getElementById('${V}'));<\/script>`}`,htmlblueprint:`<div class="chi-main">
  <div class="chi-main__header">
    <div class="chi-main__header-start">
      <a class="chi-link" href="#">
        <div class="chi-link__content">
          <i class="chi-icon icon-chevron-left -xs"></i>
          <span class="-text--md">Back link</span>
        </div>
      </a>
      <div class="chi-main__title">
        <div class="chi-main__title-heading">Page Title</div>
      </div>
    </div>
  </div>
  <div class="chi-main__content">
    <!-- Page content goes here -->
  </div>
  ${o}
</div>${c.value==="centurylink"||c.value==="colt"?"":`

<script>chi.dropdown(document.getElementById('${V}'));<\/script>`}`}});return(o,s)=>{const l=x,u=$;return n(),y(u,{title:"Base with back link",id:"base_with_back_link",padding:"0"},{example:v(()=>[i("chi-main",wi,[s[0]||(s[0]=i("div",{class:"-d--flex -align-items--center -justify-content--center",style:{height:"10rem"}},"Page content goes here",-1)),i("div",fi,[["lumen","portal"].includes(e(c))?(n(),d("div",{key:0,innerHTML:e(t).lumen},null,8,yi)):h("",!0),e(c)==="centurylink"?(n(),d("div",{key:1,innerHTML:e(t).centurylink},null,8,xi)):h("",!0),e(c)==="brightspeed"?(n(),d("div",{key:2,innerHTML:e(t).brightspeed},null,8,$i)):h("",!0),e(c)==="colt"?(n(),d("div",{key:3,innerHTML:e(t).colt},null,8,Li)):h("",!0)])])]),"code-webcomponent":v(()=>[s[1]||(s[1]=i("div",{class:"chi-tab__description"},[g("Use the "),i("code",null,'backlink=""'),g(" attribute to display a link above the title of the application layout.")],-1)),_(l,{lang:"html",code:a.value.webcomponent},null,8,["code"])]),"code-htmlblueprint":v(()=>[_(l,{class:"html",lang:"html",code:a.value.htmlblueprint},null,8,["code"])]),_:1})}}}),Wi={backlink:"Back link",title:"Page Title",subtitle:"Page subtitle"},Ci={slot:"footer"},Hi=["innerHTML"],zi=["innerHTML"],Mi=["innerHTML"],Pi=["innerHTML"],B="back-link-subtitle-language-dropdown-button",Vi=w({__name:"_back_link_subtitle",setup(r){const c=f(),t=W(B);L(async()=>{await m(),p(B)}),T(c,async o=>{await m(),p(B)});const a=b(()=>{const o=k(c.value,B);return{webcomponent:`<chi-main backlink="Back link" title="Page Title" subtitle="Page subtitle">
  <!-- Page content goes here -->
  ${o}
</chi-main>${c.value==="centurylink"||c.value==="colt"?"":`

<script>chi.dropdown(document.getElementById('${B}'));<\/script>`}`,htmlblueprint:`<div class="chi-main">
  <div class="chi-main__header">
    <div class="chi-main__header-start">
      <a class="chi-link" href="#">
        <div class="chi-link__content">
          <i class="chi-icon icon-chevron-left -xs" aria-hidden="true"></i>
          <span class="-text--md">Back link</span>
        </div>
      </a>
      <div class="chi-main__title">
        <div class="chi-main__title-heading">Page Title</div>
        <div class="chi-main__title-subheading">Page subtitle</div>
      </div>
    </div>
  </div>
  <div class="chi-main__content">
    <!-- Page content goes here -->
  </div>
  ${o}
</div>${c.value==="centurylink"||c.value==="colt"?"":`

<script>chi.dropdown(document.getElementById('${B}'));<\/script>`}`}});return(o,s)=>{const l=x,u=$;return n(),y(u,{title:"Base with back link and subtitle",id:"base_with_back_link_subtitle",padding:"0"},{example:v(()=>[i("chi-main",Wi,[s[0]||(s[0]=i("div",{class:"-d--flex -align-items--center -justify-content--center",style:{height:"10rem"}},"Page content goes here",-1)),i("div",Ci,[["lumen","portal"].includes(e(c))?(n(),d("div",{key:0,innerHTML:e(t).lumen},null,8,Hi)):h("",!0),e(c)==="centurylink"?(n(),d("div",{key:1,innerHTML:e(t).centurylink},null,8,zi)):h("",!0),e(c)==="brightspeed"?(n(),d("div",{key:2,innerHTML:e(t).brightspeed},null,8,Mi)):h("",!0),e(c)==="colt"?(n(),d("div",{key:3,innerHTML:e(t).colt},null,8,Pi)):h("",!0)])])]),"code-webcomponent":v(()=>[s[1]||(s[1]=i("div",{class:"chi-tab__description"},[g("Use the "),i("code",null,'subtitle=""'),g(" attribute to display a subtitle next to the title of the application layout.")],-1)),_(l,{lang:"html",code:a.value.webcomponent},null,8,["code"])]),"code-htmlblueprint":v(()=>[_(l,{class:"html",lang:"html",code:a.value.htmlblueprint},null,8,["code"])]),_:1})}}}),Bi={backlink:"Back link",title:"Page Title",subtitle:"Page subtitle"},Ei={slot:"footer"},Ii=["innerHTML"],Si=["innerHTML"],ji=["innerHTML"],Ri=["innerHTML"],E="back-link-subtitle-buttons-language-dropdown-button",Fi=w({__name:"_back_link_subtitle_buttons",setup(r){const c=f(),t=W(E);L(async()=>{await m(),p(E)}),T(c,async o=>{await m(),p(E)});const a=b(()=>{const o=k(c.value,E);return{webcomponent:`<chi-main backlink="Back link" title="Page Title" subtitle="Page subtitle">
  <button class="chi-button -primary" slot="header-actions">Primary</button>
  <!-- Page content goes here -->
  ${o}
</chi-main>${c.value==="centurylink"||c.value==="colt"?"":`

<script>chi.dropdown(document.getElementById('${E}'));<\/script>`}`,htmlblueprint:`<div class="chi-main">
  <div class="chi-main__header">
    <div class="chi-main__header-start">
      <a class="chi-link" href="#">
        <div class="chi-link__content">
          <i class="chi-icon icon-chevron-left -xs" aria-hidden="true"></i>
          <span class="-text--md">Back link</span>
        </div>
      </a>
      <div class="chi-main__title">
        <div class="chi-main__title-heading">Page Title</div>
        <div class="chi-main__title-subheading">Page subtitle</div>
      </div>
    </div>
    <div class="chi-main__header-end">
      <button class="chi-button -primary">Primary</button>
    </div>
  </div>
  <div class="chi-main__content">
    <!-- Page content goes here -->
  </div>
  ${o}
</div>${c.value==="centurylink"||c.value==="colt"?"":`

<script>chi.dropdown(document.getElementById('${E}'));<\/script>`}`}});return(o,s)=>{const l=x,u=$;return n(),y(u,{title:"Base with back link, subtitle and buttons",id:"base_with_back_link_subtitle_buttons",padding:"0"},{example:v(()=>[i("chi-main",Bi,[s[0]||(s[0]=i("div",{class:"-d--flex -align-items--center -justify-content--center",style:{height:"10rem"}},"Page content goes here",-1)),s[1]||(s[1]=i("div",{slot:"header-actions"},[i("button",{class:"chi-button -primary"},"Primary")],-1)),i("div",Ei,[["lumen","portal"].includes(e(c))?(n(),d("div",{key:0,innerHTML:e(t).lumen},null,8,Ii)):h("",!0),e(c)==="centurylink"?(n(),d("div",{key:1,innerHTML:e(t).centurylink},null,8,Si)):h("",!0),e(c)==="brightspeed"?(n(),d("div",{key:2,innerHTML:e(t).brightspeed},null,8,ji)):h("",!0),e(c)==="colt"?(n(),d("div",{key:3,innerHTML:e(t).colt},null,8,Ri)):h("",!0)])])]),"code-webcomponent":v(()=>[s[2]||(s[2]=i("div",{class:"chi-tab__description"},[g("Add buttons in the header of the application layout by defining "),i("code",null,'slot="header-actions"'),g(" on each "),i("code",null,"chi-button"),g(".")],-1)),_(l,{lang:"html",code:a.value.webcomponent},null,8,["code"])]),"code-htmlblueprint":v(()=>[_(l,{class:"html",lang:"html",code:a.value.htmlblueprint},null,8,["code"])]),_:1})}}}),Oi={backlink:"Back link",title:"Page Title",subtitle:"Page subtitle"},qi={slot:"footer"},Ni=["innerHTML"],Ui=["innerHTML"],Ai=["innerHTML"],Di=["innerHTML"],I="back-link-subtitle-buttons-page-level-actions-language-dropdown-button",Gi=w({__name:"_back_link_subtitle_buttons_page_level_actions",setup(r){const c=f(),t=W(I);L(async()=>{await m(),p(I)}),T(c,async o=>{await m(),p(I)});const a=b(()=>{const o=k(c.value,I);return{webcomponent:`<chi-main backlink="Back link" title="Page Title" subtitle="Page subtitle">
  <!-- Page content goes here -->
  <button class="chi-button -primary -outline -bg--white" slot="page-level__actions">Cancel</button>
  <button class="chi-button -primary -ml--1" slot="page-level__actions">Submit</button>
  ${o}
</chi-main>${c.value==="centurylink"||c.value==="colt"?"":`

<script>chi.dropdown(document.getElementById('${I}'));<\/script>`}`,htmlblueprint:`<div class="chi-main">
  <div class="chi-main__header">
    <div class="chi-main__header-start">
      <a class="chi-link" href="#">
        <div class="chi-link__content">
          <i class="chi-icon icon-chevron-left -xs" aria-hidden="true"></i>
          <span class="-text--md">Back link</span>
        </div>
      </a>
      <div class="chi-main__title">
        <div class="chi-main__title-heading">Page Title</div>
        <div class="chi-main__title-subheading">Page subtitle</div>
      </div>
    </div>
  </div>
  <div class="chi-main__content">
    <!-- Page content goes here -->
    <div class="-d--flex -align-items--center -justify-content--end -py--3 -my--2 -bt--1">
      <button class="chi-button -primary -outline -bg--white">Cancel</button>
      <button class="chi-button -primary -ml--1">Submit</button>
    </div>
  </div>
  ${o}
</div>${c.value==="centurylink"||c.value==="colt"?"":`

<script>chi.dropdown(document.getElementById('${I}'));<\/script>`}`}});return(o,s)=>{const l=x,u=$;return n(),y(u,{title:"Base with back link, subtitle, buttons and page-level actions",id:"base_with_back_link_subtitle_buttons_page_level_actions",padding:"0"},{example:v(()=>[i("chi-main",Oi,[s[0]||(s[0]=i("div",{class:"-d--flex -align-items--center -justify-content--center",style:{height:"10rem"}},"Page content goes here",-1)),s[1]||(s[1]=i("div",{slot:"page-level__actions"},[i("button",{class:"chi-button -primary -outline"},"Cancel"),i("button",{class:"chi-button -primary -ml--1"},"Submit")],-1)),i("div",qi,[["lumen","portal"].includes(e(c))?(n(),d("div",{key:0,innerHTML:e(t).lumen},null,8,Ni)):h("",!0),e(c)==="centurylink"?(n(),d("div",{key:1,innerHTML:e(t).centurylink},null,8,Ui)):h("",!0),e(c)==="brightspeed"?(n(),d("div",{key:2,innerHTML:e(t).brightspeed},null,8,Ai)):h("",!0),e(c)==="colt"?(n(),d("div",{key:3,innerHTML:e(t).colt},null,8,Di)):h("",!0)])])]),"code-webcomponent":v(()=>[s[2]||(s[2]=i("div",{class:"chi-tab__description"},[g("Add page-level actions at the bottom of the application layout by defining "),i("code",null,'slot="page-level__actions"'),g(" on each "),i("code",null,"chi-button"),g(".")],-1)),_(l,{lang:"html",code:a.value.webcomponent},null,8,["code"])]),"code-htmlblueprint":v(()=>[_(l,{class:"html",lang:"html",code:a.value.htmlblueprint},null,8,["code"])]),_:1})}}}),Ki={title:"Page Title",format:"fixed-width","header-background":"","help-position":"right"},Qi={class:"-d--inline-flex",slot:"help-icon"},Yi={slot:"header-actions"},Ji={key:0,slot:"header-actions"},Xi={key:1,color:"primary"},Zi={slot:"footer"},ic=["innerHTML"],cc=["innerHTML"],ec=["innerHTML"],tc=["innerHTML"],S="dashboard-language-dropdown-button",lc=w({__name:"_dashboard",setup(r){const c=f(),t=W(S),a=b(()=>c.value==="lumen"||c.value==="centurylink"?"Dashboard with header background":"Home page with header background");L(async()=>{await m(),p(S)}),T(c,async s=>{await m(),p(S)});const o=b(()=>{const s=k(c.value,S);return{webcomponent:`<chi-main title="Page Title" format="fixed-width" header-background help-position="right">
  <chi-button id="example__help-button" alternative-text="Help" slot="help-icon">
    <chi-icon icon="circle-question-outline" size="sm"></chi-icon>
    <span>Help</span>
  </chi-button>
  ${c.value==="portal"||c.value==="colt"||c.value==="brightspeed"?`<chi-button slot="header-actions">
    <chi-icon icon="settings"></chi-icon>
    <span>Customize</span>
  </chi-button>`:'<chi-button color="primary" slot="header-actions">Button</chi-button>'}
  <div class="chi-css-grid -grid-rows--176">
    <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
      <div class="chi-card -highlight -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">Content here</div>
      </div>
    </div>
    <div class="chi-css-col -col-lg--6 -col-xl--4">
      <div class="chi-card -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">Content here</div>
      </div>
    </div>
    <div class="chi-css-col -col-lg--6 -col-xl--4">
      <div class="chi-card -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">
          <ul class="chi-css-grid -gap--05 -no-style -m--0">
            <li class="chi-css-col -col-sm--6">
              <chi-link href="#">Widget Link</chi-link>
            </li>
            <li class="chi-css-col -col-sm--6">
              <chi-link href="#">Widget Link</chi-link>
            </li>
            <li class="chi-css-col -col-sm--6">
              <chi-link href="#">Widget Link</chi-link>
            </li>
            <li class="chi-css-col -col-sm--6">
              <chi-link href="#">Widget Link</chi-link>
            </li>
            <li class="chi-css-col -col-sm--6">
              <chi-link href="#">Widget Link</chi-link>
            </li>
            <li class="chi-css-col -col-sm--6">
              <chi-link href="#">Widget Link</chi-link>
            </li>
            <li class="chi-css-col -col-sm--6">
              <chi-link href="#">Widget Link</chi-link>
            </li>
            <li class="chi-css-col -col-sm--6">
              <chi-link href="#">Widget Link</chi-link>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="chi-css-col -col-lg--6 -col-xl--4">
      <div class="chi-card -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">Content here</div>
      </div>
    </div>
    <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
      <div class="chi-card -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">Content here</div>
      </div>
    </div>
    <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
      <div class="chi-card -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">Content here</div>
      </div>
    </div>
    <div class="chi-css-col -col-lg--6 -col-xl--4">
      <div class="chi-card -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">Content here</div>
      </div>
    </div>
    <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
      <div class="chi-card -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">Content here</div>
      </div>
    </div>
    <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
      <div class="chi-card -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">Content here</div>
      </div>
    </div>
    <div class="chi-css-col -col-lg--6 -col-xl--4">
      <div class="chi-card -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">Content here</div>
      </div>
    </div>
  </div>
  ${s}
</chi-main>

<script>${["centurylink","colt","brightspeed"].includes(c)?"":`
  chi.dropdown(document.getElementById('${S}'));`}
<\/script>`,htmlblueprint:`<div class="chi-main -fixed-width -header-background">
  <div class="chi-main__background">
    <div class="chi-main__background-image">
    </div>
  </div>
  <div class="chi-main__header">
    <div class="chi-main__header-start">
      <div class="chi-main__title">
        <div class="chi-main__title-heading">
          Page Title
          <div class="chi-button -icon -flat -sm" id="example__help-button" data-position="right-start" data-target="#example__help-popover" aria-label="Help" slot="help-icon">
            <div class="chi-button__content">
              <i class="chi-icon icon-circle-question-outline" aria-hidden="true"></i>
            </div>
          </div>
          <section class="chi-popover chi-popover--right-start" id="example__help-popover" aria-modal="true" role="dialog">
            <div class="chi-popover__content">
              <p class="chi-popover__text">Popover content.</p>
            </div>
          </section>
        </div>
      </div>
    </div>
    <div class="chi-main__header-end">
      ${c.value==="portal"||c.value==="colt"||c.value==="brightspeed"?`<button class="chi-button -xs">
        <div class="chi-button__content">
          <i class="chi-icon icon-settings"></i>
          <span>Customize</span>
        </div>
      </button>`:'<button class="chi-button -primary -sm">Button</button>'}
    </div>
  </div>
  <div class="chi-main__content">
    <div class="chi-css-grid -grid-rows--176">
      <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
        <div class="chi-card -highlight -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">Content here</div>
        </div>
      </div>
      <div class="chi-css-col -col-lg--6 -col-xl--4">
        <div class="chi-card -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">Content here</div>
        </div>
      </div>
      <div class="chi-css-col -col-lg--6 -col-xl--4">
        <div class="chi-card -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">
            <ul class="chi-css-grid -gap--05 -no-style -m--0">
              <li class="chi-css-col -col-sm--6">
                <a class="chi-link" href="#">Widget Link</a>
              </li>
              <li class="chi-css-col -col-sm--6">
                <a class="chi-link" href="#">Widget Link</a>
              </li>
              <li class="chi-css-col -col-sm--6">
                <a class="chi-link" href="#">Widget Link</a>
              </li>
              <li class="chi-css-col -col-sm--6">
                <a class="chi-link" href="#">Widget Link</a>
              </li>
              <li class="chi-css-col -col-sm--6">
                <a class="chi-link" href="#">Widget Link</a>
              </li>
              <li class="chi-css-col -col-sm--6">
                <a class="chi-link" href="#">Widget Link</a>
              </li>
              <li class="chi-css-col -col-sm--6">
                <a class="chi-link" href="#">Widget Link</a>
              </li>
              <li class="chi-css-col -col-sm--6">
                <a class="chi-link" href="#">Widget Link</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="chi-css-col -col-lg--6 -col-xl--4">
        <div class="chi-card -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">Content here</div>
        </div>
      </div>
      <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
        <div class="chi-card -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">Content here</div>
        </div>
      </div>
      <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
        <div class="chi-card -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">Content here</div>
        </div>
      </div>
      <div class="chi-css-col -col-lg--6 -col-xl--4">
        <div class="chi-card -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">Content here</div>
        </div>
      </div>
      <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
        <div class="chi-card -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">Content here</div>
        </div>
      </div>
      <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
        <div class="chi-card -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">Content here</div>
        </div>
      </div>
      <div class="chi-css-col -col-lg--6 -col-xl--4">
        <div class="chi-card -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">Content here</div>
        </div>
      </div>
    </div>
  </div>
  ${s}
</div>

<script>${["centurylink","colt","brightspeed"].includes(c)?"":`
  chi.dropdown(document.getElementById('${S}'));`}
  chi.popover(document.getElementById('example__help-button'));
<\/script>`}});return(s,l)=>{const u=x,C=$;return n(),y(C,{title:a.value,id:"dashboard",padding:"0"},{example:v(()=>[i("chi-main",Ki,[i("div",Qi,[i("chi-button",{id:"dashboard__help-button","alternative-text":"Help",onClick:l[0]||(l[0]=(...H)=>s.togglePopover&&s.togglePopover(...H))},[...l[1]||(l[1]=[i("chi-icon",{icon:"circle-question-outline",size:"sm"},null,-1),i("span",null,"Help",-1)])])]),i("div",Yi,[["portal","colt","brightspeed"].includes(e(c))?(n(),d("chi-button",Ji,[...l[2]||(l[2]=[i("chi-icon",{icon:"settings"},null,-1),i("span",null,"Customize",-1)])])):(n(),d("chi-button",Xi,"Button"))]),l[3]||(l[3]=i("div",{class:"chi-css-grid -grid-rows--176"},[i("div",{class:"chi-css-col -col-lg--6 -col-xl--4 -row--2"},[i("div",{class:"chi-card -highlight -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},"Content here")])]),i("div",{class:"chi-css-col -col-lg--6 -col-xl--4"},[i("div",{class:"chi-card -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},"Content here")])]),i("div",{class:"chi-css-col -col-lg--6 -col-xl--4"},[i("div",{class:"chi-card -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},[i("ul",{class:"chi-css-grid -gap--05 -no-style -m--0"},[i("li",{class:"chi-css-col -col-sm--6"},[i("chi-link",{href:"#"},"Widget Link")]),i("li",{class:"chi-css-col -col-sm--6"},[i("chi-link",{href:"#"},"Widget Link")]),i("li",{class:"chi-css-col -col-sm--6"},[i("chi-link",{href:"#"},"Widget Link")]),i("li",{class:"chi-css-col -col-sm--6"},[i("chi-link",{href:"#"},"Widget Link")]),i("li",{class:"chi-css-col -col-sm--6"},[i("chi-link",{href:"#"},"Widget Link")]),i("li",{class:"chi-css-col -col-sm--6"},[i("chi-link",{href:"#"},"Widget Link")]),i("li",{class:"chi-css-col -col-sm--6"},[i("chi-link",{href:"#"},"Widget Link")]),i("li",{class:"chi-css-col -col-sm--6"},[i("chi-link",{href:"#"},"Widget Link")])])])])]),i("div",{class:"chi-css-col -col-lg--6 -col-xl--4"},[i("div",{class:"chi-card -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},"Content here")])]),i("div",{class:"chi-css-col -col-lg--6 -col-xl--4 -row--2"},[i("div",{class:"chi-card -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},"Content here")])]),i("div",{class:"chi-css-col -col-lg--6 -col-xl--4 -row--2"},[i("div",{class:"chi-card -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},"Content here")])]),i("div",{class:"chi-css-col -col-lg--6 -col-xl--4"},[i("div",{class:"chi-card -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},"Content here")])]),i("div",{class:"chi-css-col -col-lg--6 -col-xl--4 -row--2"},[i("div",{class:"chi-card -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},"Content here")])]),i("div",{class:"chi-css-col -col-lg--6 -col-xl--4 -row--2"},[i("div",{class:"chi-card -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},"Content here")])]),i("div",{class:"chi-css-col -col-lg--6 -col-xl--4"},[i("div",{class:"chi-card -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},"Content here")])])],-1)),i("div",Zi,[["lumen","portal"].includes(e(c))?(n(),d("div",{key:0,innerHTML:e(t).lumen},null,8,ic)):h("",!0),e(c)==="centurylink"?(n(),d("div",{key:1,innerHTML:e(t).centurylink},null,8,cc)):h("",!0),e(c)==="brightspeed"?(n(),d("div",{key:2,innerHTML:e(t).brightspeed},null,8,ec)):h("",!0),e(c)==="colt"?(n(),d("div",{key:3,innerHTML:e(t).colt},null,8,tc)):h("",!0)])])]),"code-webcomponent":v(()=>[_(u,{class:"html",lang:"html",code:o.value.webcomponent},null,8,["code"])]),"code-htmlblueprint":v(()=>[_(u,{class:"html",lang:"html",code:o.value.htmlblueprint},null,8,["code"])]),_:1},8,["title"])}}}),sc={title:"Page Title",format:"fixed-width","header-background":"","help-position":"right"},nc=["size"],ac={class:"-d--inline-flex",slot:"help-icon"},dc={slot:"header-actions"},oc={key:0,slot:"header-actions"},hc={key:1,color:"primary"},rc={slot:"footer"},vc=["innerHTML"],_c=["innerHTML"],uc=["innerHTML"],mc=["innerHTML"],j="dashboard-alert-language-dropdown-button",pc=w({__name:"_dashboard_alert",setup(r){const c=f(),t=W(j),a=b(()=>c.value==="lumen"||c.value==="centurylink"?"Dashboard with page-level alert":"Home page with page-level alert");L(async()=>{await m(),p(j)}),T(c,async s=>{await m(),p(j)});const o=b(()=>{const s=k(c.value,j);return{webcomponent:`<chi-main title="Page Title" format="fixed-width" header-background help-position="right">
  <chi-alert 
    color="info" 
    icon="circle-info"${c.value==="portal"||c.value==="colt"||c.value==="brightspeed"?' size="sm"':""} 
    slot="page-alert" 
    closable
  >
    This is a page level info alert
  </chi-alert>
  <chi-button id="example__help-button" alternative-text="Help" slot="help-icon">
    <chi-icon icon="circle-question-outline" size="sm"></chi-icon>
    <span>Help</span>
  </chi-button>
  ${c.value==="portal"||c.value==="colt"||c.value==="brightspeed"?`<chi-button slot="header-actions">
    <chi-icon icon="settings"></chi-icon>
    <span>Customize</span>
  </chi-button>`:'<chi-button color="primary" slot="header-actions">Button</chi-button>'}
  <div class="chi-css-grid -grid-rows--176">
    <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
      <div class="chi-card -highlight -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">Content here</div>
      </div>
    </div>
    <div class="chi-css-col -col-lg--6 -col-xl--4">
      <div class="chi-card -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">Content here</div>
      </div>
    </div>
    <div class="chi-css-col -col-lg--6 -col-xl--4">
      <div class="chi-card -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">
          <ul class="chi-css-grid -gap--05 -no-style -m--0">
            <li class="chi-css-col -col-sm--6">
              <chi-link href="#">Widget Link</chi-link>
            </li>
            <li class="chi-css-col -col-sm--6">
              <chi-link href="#">Widget Link</chi-link>
            </li>
            <li class="chi-css-col -col-sm--6">
              <chi-link href="#">Widget Link</chi-link>
            </li>
            <li class="chi-css-col -col-sm--6">
              <chi-link href="#">Widget Link</chi-link>
            </li>
            <li class="chi-css-col -col-sm--6">
              <chi-link href="#">Widget Link</chi-link>
            </li>
            <li class="chi-css-col -col-sm--6">
              <chi-link href="#">Widget Link</chi-link>
            </li>
            <li class="chi-css-col -col-sm--6">
              <chi-link href="#">Widget Link</chi-link>
            </li>
            <li class="chi-css-col -col-sm--6">
              <chi-link href="#">Widget Link</chi-link>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="chi-css-col -col-lg--6 -col-xl--4">
      <div class="chi-card -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">Content here</div>
      </div>
    </div>
    <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
      <div class="chi-card -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">Content here</div>
      </div>
    </div>
    <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
      <div class="chi-card -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">Content here</div>
      </div>
    </div>
    <div class="chi-css-col -col-lg--6 -col-xl--4">
      <div class="chi-card -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">Content here</div>
      </div>
    </div>
    <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
      <div class="chi-card -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">Content here</div>
      </div>
    </div>
    <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
      <div class="chi-card -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">Content here</div>
      </div>
    </div>
    <div class="chi-css-col -col-lg--6 -col-xl--4">
      <div class="chi-card -widget -h--100">
        <div class="chi-card__header">
          <div class="chi-card__title">Widget</div>
          <chi-link size="md" href="#" cta="cta">View</chi-link>
        </div>
        <div class="chi-card__content">Content here</div>
      </div>
    </div>
  </div>
  ${s}
</chi-main>

<script>${["portal","colt","brightspeed"].includes(c)?"":`
  chi.dropdown(document.getElementById('${j}'));`}
<\/script>`,htmlblueprint:`<div class="chi-main -fixed-width -header-background">
  <div class="chi-main__background">
    <div class="chi-main__background-image">
    </div>
  </div>
  <div class="chi-main__alert">
    <div class="chi-alert -info${c.value==="portal"||c.value==="colt"||c.value==="brightspeed"?" -sm":""} -close" role="alert">
      <i class="chi-alert__icon chi-icon icon-circle-info" aria-hidden="true"></i>
      <div class="chi-alert__content">
        <p class="chi-alert__text">This is a page level info alert</p>
      </div>
      <button class="chi-alert__close-button chi-button -icon -close" aria-label="Close">
        <div class="chi-button__content">
          <i class="chi-icon icon-x" aria-hidden="true"></i>
        </div>
      </button>
    </div>
  </div>
  <div class="chi-main__header">
    <div class="chi-main__header-start">
      <div class="chi-main__title">
        <div class="chi-main__title-heading">
          Page Title
          <div class="chi-button -icon -flat -sm" id="example__help-button" data-position="right-start" data-target="#example__help-popover" aria-label="Help" slot="help-icon">
            <div class="chi-button__content">
              <i class="chi-icon icon-circle-question-outline" aria-hidden="true"></i>
            </div>
          </div>
          <section class="chi-popover chi-popover--right-start" id="example__help-popover" aria-modal="true" role="dialog">
            <div class="chi-popover__content">
              <p class="chi-popover__text">Popover content.</p>
            </div>
          </section>
        </div>
      </div>
    </div>
    <div class="chi-main__header-end">
      ${c.value==="portal"||c.value==="colt"||c.value==="brightspeed"?`<button class="chi-button -xs">
        <div class="chi-button__content">
          <i class="chi-icon icon-settings"></i>
          <span>Customize</span>
        </div>
      </button>`:'<button class="chi-button -primary -sm">Button</button>'}
    </div>
  </div>
  <div class="chi-main__content">
    <div class="chi-css-grid -grid-rows--176">
      <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
        <div class="chi-card -highlight -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">Content here</div>
        </div>
      </div>
      <div class="chi-css-col -col-lg--6 -col-xl--4">
        <div class="chi-card -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">Content here</div>
        </div>
      </div>
      <div class="chi-css-col -col-lg--6 -col-xl--4">
        <div class="chi-card -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">
            <ul class="chi-css-grid -gap--05 -no-style -m--0">
              <li class="chi-css-col -col-sm--6">
                <a class="chi-link" href="#">Widget Link</a>
              </li>
              <li class="chi-css-col -col-sm--6">
                <a class="chi-link" href="#">Widget Link</a>
              </li>
              <li class="chi-css-col -col-sm--6">
                <a class="chi-link" href="#">Widget Link</a>
              </li>
              <li class="chi-css-col -col-sm--6">
                <a class="chi-link" href="#">Widget Link</a>
              </li>
              <li class="chi-css-col -col-sm--6">
                <a class="chi-link" href="#">Widget Link</a>
              </li>
              <li class="chi-css-col -col-sm--6">
                <a class="chi-link" href="#">Widget Link</a>
              </li>
              <li class="chi-css-col -col-sm--6">
                <a class="chi-link" href="#">Widget Link</a>
              </li>
              <li class="chi-css-col -col-sm--6">
                <a class="chi-link" href="#">Widget Link</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="chi-css-col -col-lg--6 -col-xl--4">
        <div class="chi-card -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">Content here</div>
        </div>
      </div>
      <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
        <div class="chi-card -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">Content here</div>
        </div>
      </div>
      <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
        <div class="chi-card -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">Content here</div>
        </div>
      </div>
      <div class="chi-css-col -col-lg--6 -col-xl--4">
        <div class="chi-card -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">Content here</div>
        </div>
      </div>
      <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
        <div class="chi-card -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">Content here</div>
        </div>
      </div>
      <div class="chi-css-col -col-lg--6 -col-xl--4 -row--2">
        <div class="chi-card -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">Content here</div>
        </div>
      </div>
      <div class="chi-css-col -col-lg--6 -col-xl--4">
        <div class="chi-card -widget -h--100">
          <div class="chi-card__header">
            <div class="chi-card__title">Widget</div>
            <a class="chi-link -md -cta" href="#">View</a>
          </div>
          <div class="chi-card__content">Content here</div>
        </div>
      </div>
    </div>
  </div>
  ${s}
</div>

<script>${["portal","colt","brightspeed"].includes(c)?"":`
  chi.dropdown(document.getElementById('${j}'));`}
  chi.popover(document.getElementById('example__help-button'));
<\/script>`}});return(s,l)=>{const u=x,C=$;return n(),y(C,{title:a.value,id:"dashboard_with_alert",padding:"0"},{example:v(()=>[i("chi-main",sc,[i("chi-alert",{color:"info",icon:"circle-info",size:["portal","colt","brightspeed"].includes(e(c))?"sm":"md",slot:"page-alert",closable:""},[...l[1]||(l[1]=[i("span",null,"This is a page level info alert",-1)])],8,nc),l[4]||(l[4]=i("div",{class:"chi-css-grid -grid-rows--176"},[i("div",{class:"chi-css-col -col-lg--6 -col-xl--4 -row--2"},[i("div",{class:"chi-card -highlight -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},"Content here")])]),i("div",{class:"chi-css-col -col-lg--6 -col-xl--4"},[i("div",{class:"chi-card -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},"Content here")])]),i("div",{class:"chi-css-col -col-lg--6 -col-xl--4"},[i("div",{class:"chi-card -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},[i("ul",{class:"chi-css-grid -gap--05 -no-style -m--0"},[i("li",{class:"chi-css-col -col-sm--6"},[i("chi-link",{href:"#"},"Widget Link")]),i("li",{class:"chi-css-col -col-sm--6"},[i("chi-link",{href:"#"},"Widget Link")]),i("li",{class:"chi-css-col -col-sm--6"},[i("chi-link",{href:"#"},"Widget Link")]),i("li",{class:"chi-css-col -col-sm--6"},[i("chi-link",{href:"#"},"Widget Link")]),i("li",{class:"chi-css-col -col-sm--6"},[i("chi-link",{href:"#"},"Widget Link")]),i("li",{class:"chi-css-col -col-sm--6"},[i("chi-link",{href:"#"},"Widget Link")]),i("li",{class:"chi-css-col -col-sm--6"},[i("chi-link",{href:"#"},"Widget Link")]),i("li",{class:"chi-css-col -col-sm--6"},[i("chi-link",{href:"#"},"Widget Link")])])])])]),i("div",{class:"chi-css-col -col-lg--6 -col-xl--4"},[i("div",{class:"chi-card -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},"Content here")])]),i("div",{class:"chi-css-col -col-lg--6 -col-xl--4 -row--2"},[i("div",{class:"chi-card -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},"Content here")])]),i("div",{class:"chi-css-col -col-lg--6 -col-xl--4 -row--2"},[i("div",{class:"chi-card -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},"Content here")])]),i("div",{class:"chi-css-col -col-lg--6 -col-xl--4"},[i("div",{class:"chi-card -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},"Content here")])]),i("div",{class:"chi-css-col -col-lg--6 -col-xl--4 -row--2"},[i("div",{class:"chi-card -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},"Content here")])]),i("div",{class:"chi-css-col -col-lg--6 -col-xl--4 -row--2"},[i("div",{class:"chi-card -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},"Content here")])]),i("div",{class:"chi-css-col -col-lg--6 -col-xl--4"},[i("div",{class:"chi-card -widget -h--100"},[i("div",{class:"chi-card__header"},[i("div",{class:"chi-card__title"},"Widget"),i("chi-link",{size:"md",href:"#",cta:"cta"},"View")]),i("div",{class:"chi-card__content"},"Content here")])])],-1)),i("div",ac,[i("chi-button",{id:"dashboard-alert__help-button","alternative-text":"Help",onClick:l[0]||(l[0]=(...H)=>s.togglePopover&&s.togglePopover(...H))},[...l[2]||(l[2]=[i("chi-icon",{icon:"circle-question-outline",size:"sm"},null,-1),i("span",null,"Help",-1)])])]),i("div",dc,[["portal","colt","brightspeed"].includes(e(c))?(n(),d("chi-button",oc,[...l[3]||(l[3]=[i("chi-icon",{icon:"settings"},null,-1),i("span",null,"Customize",-1)])])):(n(),d("chi-button",hc,"Button"))]),i("div",rc,[["lumen","portal"].includes(e(c))?(n(),d("div",{key:0,innerHTML:e(t).lumen},null,8,vc)):h("",!0),e(c)==="centurylink"?(n(),d("div",{key:1,innerHTML:e(t).centurylink},null,8,_c)):h("",!0),e(c)==="brightspeed"?(n(),d("div",{key:2,innerHTML:e(t).brightspeed},null,8,uc)):h("",!0),e(c)==="colt"?(n(),d("div",{key:3,innerHTML:e(t).colt},null,8,mc)):h("",!0)])])]),"code-webcomponent":v(()=>[_(u,{class:"html",lang:"html",code:o.value.webcomponent},null,8,["code"])]),"code-htmlblueprint":v(()=>[_(u,{class:"html",lang:"html",code:o.value.htmlblueprint},null,8,["code"])]),_:1},8,["title"])}}}),yc=w({__name:"index",setup(r){const c=f();return(t,a)=>{const o=q;return n(),d(G,null,[a[0]||(a[0]=i("h2",null,"Examples",-1)),a[1]||(a[1]=i("p",{class:"-text"},[g("To render application layout, use the tag "),i("code",null,"chi-main"),g(".")],-1)),_(o,null,{default:v(()=>[_(bi),["lumen","centurylink","colt"].includes(e(c))?(n(),y(vi,{key:0})):h("",!0),_(si),_(Ti),_(Vi),_(Fi),_(Gi),_(lc),_(pc)]),_:1})],64)}}});export{yc as _};
