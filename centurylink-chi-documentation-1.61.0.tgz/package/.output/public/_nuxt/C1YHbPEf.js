import{_ as ma}from"./DY7FbNsl.js";import{_ as $}from"./DnPF01B5.js";import{_ as L}from"./CdcsEwU-.js";import{e as C,i as k,o as g,w as l,b as e,a,d as p,B as f,k as P,c as I,F as E,r as U,S as q,q as S,t as la,ad as K,ae as da,af as Q,g as ga}from"./DBXeQHmC.js";import{_ as ca}from"./DDFyDyTO.js";import{_ as sa}from"./Bjy4eZkV.js";import{a as ea,_ as na,b as oa,h as ra,d as wa}from"./5jRS-OJG.js";const G=c=>s=>" ".repeat(s*c),M=(c,s,o)=>({id:`name-${s}`,data:[c,`name-${s}`,o]}),x=(c,s,o)=>({name:c,id:s,date:o}),W=(c,s,o,h,v)=>{const n=G(h);return`[
${n(v+1)}'${s}',
${n(v+1)}'${c}',
${n(v+1)}'${o}',
${n(v)}]`},va=(c,s,o,h,v)=>{const n=G(h);return`{
${n(v)}id: '${c}-${o}',
${n(v)}data: ${W(s.id,s.name,s.date,h,v)},
${n(v-1)}},`},T=(c,s,o,h=[],v=!1,n=!1,r=!1,i=!1,d="Accordion content")=>{const t=G(2),_=[v?`${t(4)}active: true,`:"",n?`${t(4)}state: 'danger',`:"",r?`${t(4)}expandable: true,`:""].filter(Boolean).join(`
`),b=i?`${t(4)}nestedContent: {
${t(5)}${d}
${t(4)}}`:"";return`{
${_?_+`
`:""}${t(4)}id: '${c}',${b?`
`+b:""}
${t(4)}data: ${W(c,s,o,2,4)},
${t(3)}},`},V=(c,s,o,h,v=!1,n=2)=>{const r=G(n),i=h.map((d,t)=>va(c,d,t,n,8)).join(`
${r(7)}`);return`{
${v?`${r(4)}expanded: true,
`:""}${r(4)}id: '${c}',
${r(4)}nestedContent: {
${r(5)}table: {
${r(6)}data: [
${r(7)}${i}
${r(6)}],
${r(5)}},
${r(4)}},
${r(4)}data: ${W(c,s,o,n,4)},
${r(3)}},`},fa=(c,s,o,h)=>va(c,s,o,h,12),j=(c,s,o,h,v=!1,n=!1,r=2)=>{const i=G(r),d=(_,b)=>{const m=h.map((u,y)=>fa(c,u,y,r)).join(`
${i(11)}`);return`{
${n&&b===0?`${i(8)}expanded: true,
`:""}${i(8)}id: '${c}-${b}',
${i(8)}data: ${W(_.id,_.name,_.date,r,8)},
${i(8)}nestedContent: {
${i(9)}table: {
${i(10)}data: [
${i(11)}${m}
${i(10)}],
${i(9)}},
${i(8)}},
${i(7)}},`},t=h.map((_,b)=>d(_,b)).join(`
${i(7)}`);return`{
${v?`${i(4)}expanded: true,
`:""}${i(4)}id: '${c}',
${i(4)}nestedContent: {
${i(5)}table: {
${i(6)}data: [
${i(7)}${t}
${i(6)}],
${i(5)}},
${i(4)}},
${i(4)}data: ${W(c,s,o,r,4)},
${i(3)}},`},w={columnResize:!0,style:{portal:!1,noBorder:!1,bordered:!1,hover:!1,size:"md",striped:!1},pagination:{activePage:1,compact:!1,firstLast:!1,pageJumper:!0},resultsPerPage:3},N={name:{label:"Name"},id:{label:"ID"},lastLogin:{label:"Last Login"}},R=[M("Name 1","1","18 Dec 2020 3:26 p.m."),M("Name 2","2","18 Dec 2020 2:38 a.m."),M("Name 3","3","5 Nov 2020 10:15 a.m."),M("Name 4","4","18 Dec 2020 3:26 p.m."),M("Name 5","5","18 Dec 2020 2:38 a.m."),M("Name 6","6","5 Nov 2020 10:15 a.m.")],X=(c=!1)=>`config: {
    columnResize: true,
    style: {
      portal: ${c?"true":"false"},
      noBorder: false,
      bordered: false,
      hover: false,
      size: 'md',
      striped: ${c?"true":"false"},
    },
    pagination: {
      activePage: 1,
      compact: ${c?"true":"false"},
      firstLast: ${c?"true":"false"},
      pageJumper: ${c?"false":"true"},
    },
    resultsPerPage: 3,
  },`,B=`head: {
      name: { label: 'Name' },
      id: { label: 'ID' },
      lastLogin: { label: 'Last Login' },
    },`,ia=`head: {
      name: { label: 'Name', key: true, bold: true },
      id: { label: 'ID', key: true },
      lastLogin: { label: 'Last Login' },
    },`,xa=`head: {
      name: { label: 'Name', sortable: true, sortDataType: 'string' },
      id: { label: 'ID', sortable: true, sortDataType: 'string' },
      lastLogin: { label: 'Last Login', sortable: true, sortDatatype: 'date' },
    },`,A=(c=!1,s=!1)=>`body: [
      ${T("name-1","Name 1","18 Dec 2020 3:26 p.m.")}
      ${T("name-2","Name 2","18 Dec 2020 2:38 a.m.",[],c,s)}
      ${T("name-3","Name 3","5 Nov 2020 10:15 a.m.")}
      ${T("name-4","Name 4","18 Dec 2020 3:26 p.m.")}
      ${T("name-5","Name 5","18 Dec 2020 2:38 a.m.")}
      ${T("name-6","Name 6","5 Nov 2020 10:15 a.m.")}
    ]`,ba=c=>`<div class="chi-data-table">
  <div class="chi-data-table__head">
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell">
        <div>Name</div>
      </div>
      <div class="chi-data-table__cell">
        <div>ID</div>
      </div>
      <div class="chi-data-table__cell">
        <div>Last Login</div>
      </div>
    </div>
  </div>
  <div class="chi-data-table__body">
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell" data-label="Name">
        <div>Name 1</div>
      </div>
      <div class="chi-data-table__cell" data-label="ID">
        <div>name-1</div>
      </div>
      <div class="chi-data-table__cell" data-label="Last Login">
        <div>18 Dec 2020 3:26 p.m.</div>
      </div>
    </div>
    <div class="chi-data-table__row${c?" -active":""}">
      <div class="chi-data-table__cell" data-label="Name">
        <div>Name 2</div>
      </div>
      <div class="chi-data-table__cell" data-label="ID">
        <div>name-2</div>
      </div>
      <div class="chi-data-table__cell" data-label="Last Login">
        <div>18 Dec 2020 2:38 a.m.</div>
      </div>
    </div>
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell" data-label="Name">
        <div>Name 3</div>
      </div>
      <div class="chi-data-table__cell" data-label="ID">
        <div>name-3</div>
      </div>
      <div class="chi-data-table__cell" data-label="Last Login">
        <div>5 Nov 2020 10:15 a.m.</div>
      </div>
    </div>
  </div>
  <div class="chi-data-table__footer">
    <nav class="chi-pagination" role="navigation" aria-label="Pagination">
      <div class="chi-pagination__content">
        <div class="chi-pagination__start">
          <div class="chi-pagination__results">
            <span class="chi-pagination__label">6 results</span>
          </div>
          <div class="chi-pagination__page-size">
            <div class="chi-dropdown">
              <button class="chi-button -flat -px--1 chi-dropdown__trigger" id="pagesize-1">20</button>
              <div class="chi-dropdown__menu -w--xs">
                <a class="chi-dropdown__menu-item -active" href="#">20</a>
                <a class="chi-dropdown__menu-item" href="#">40</a>
                <a class="chi-dropdown__menu-item" href="#">60</a>
                <a class="chi-dropdown__menu-item" href="#">80</a>
                <a class="chi-dropdown__menu-item" href="#">All</a>
              </div>
            </div>
            <span class="chi-pagination__label">per page</span>
          </div>
        </div>
        <div class="chi-pagination__center">
          <div class="chi-pagination__button-group chi-button-group">
            <button class="chi-button -icon -flat" aria-label="Previous page">
              <div class="chi-button__content">
                <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
              </div>
            </button>
            <button class="chi-button -flat -active" aria-label="Page 1">1</button>
            <button class="chi-button -flat" aria-label="Page 2">2</button>
            <button class="chi-button -icon -flat" aria-label="Next page">
              <div class="chi-button__content">
                <i class="chi-icon icon-chevron-right" aria-hidden="true"></i>
              </div>
            </button>
          </div>
        </div>
        <div class="chi-pagination__end">
          <div class="chi-pagination__jumper">
            <label class="chi-pagination__label" for="jumper-input-1">Go to page:</label>
            <input class="chi-input" type="text" id="jumper-input-1" />
          </div>
        </div>
      </div>
    </nav>
  </div>
</div>`,Da=`<div class="chi-card -portal -bg--white -bg-md--grey-15">
  <div class="chi-card__header -sm">
    <div class="chi-card__title">Title</div>
  </div>
  <div class="chi-card__content -p--0">
    <div class="chi-data-table -portal -compact">
      <div class="chi-data-table__head">
        <div class="chi-data-table__row">
          <div class="chi-data-table__cell">
            <div>Name</div>
          </div>
          <div class="chi-data-table__cell">
            <div>ID</div>
          </div>
          <div class="chi-data-table__cell">
            <div>Last Login</div>
          </div>
        </div>
      </div>
      <div class="chi-data-table__body">
        <div class="chi-data-table__row -md">
          <div class="chi-data-table__cell -key -bold">
            <div>Name 1</div>
          </div>
          <div class="chi-data-table__cell -key">
            <div>name-1</div>
          </div>
          <div class="chi-data-table__cell">
            <div>18 Dec 2020 3:26 p.m.</div>
          </div>
        </div>
        <div class="chi-data-table__row -striped -md">
          <div class="chi-data-table__cell -key -bold">
            <div>Name 2</div>
          </div>
          <div class="chi-data-table__cell -key">
            <div>name-2</div>
          </div>
          <div class="chi-data-table__cell">
            <div>18 Dec 2020 2:38 a.m.</div>
          </div>
        </div>
        <div class="chi-data-table__row -md">
          <div class="chi-data-table__cell -key -bold">
            <div>Name 3</div>
          </div>
          <div class="chi-data-table__cell -key">
            <div>name-3</div>
          </div>
          <div class="chi-data-table__cell">
            <div>5 Nov 2020 10:15 a.m.</div>
          </div>
        </div>
      </div>
      <div class="chi-data-table__footer">
        <nav class="chi-pagination -compact" role="navigation" aria-label="Pagination">
          <div class="chi-pagination__content">
            <div class="chi-pagination__start">
              <div class="chi-pagination__results">
                <span class="chi-pagination__label">6 Results</span>
              </div>
            </div>
            <div class="chi-pagination__center">
              <div class="chi-pagination__button-group chi-button-group">
                <button class="chi-button -icon -flat -xs" aria-label="First page" disabled>
                  <div class="chi-button__content">
                    <i class="chi-icon icon-page-first" aria-hidden="true"></i>
                  </div>
                </button>
                <button class="chi-button -icon -flat -xs" aria-label="Previous page" disabled>
                  <div class="chi-button__content">
                    <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
                  </div>
                </button>
              </div>
              <div class="chi-pagination__label">
                <strong>1</strong>
                <span>of</span>
                <strong>2</strong>
              </div>
              <div class="chi-pagination__button-group chi-button-group">
                <button class="chi-button -icon -flat -xs" aria-label="Next page">
                  <div class="chi-button__content">
                    <i class="chi-icon icon-chevron-right" aria-hidden="true"></i>
                  </div>
                </button>
                <button class="chi-button -icon -flat -xs" aria-label="Last page">
                  <div class="chi-button__content">
                    <i class="chi-icon icon-page-last" aria-hidden="true"></i>
                  </div>
                </button>
              </div>
            </div>
            <div class="chi-pagination__end"></div>
          </div>
        </nav>
      </div>
    </div>
  </div>
</div>`,Ca=`config: {
    columnResize: true,
    style: {
      portal: true,
      noBorder: false,
      bordered: false,
      hover: false,
      size: 'md',
      striped: true,
    },
    pagination: {
      activePage: 1,
      compact: true,
      firstLast: true,
      pageJumper: false,
    },
    selectable: 'radio',
    resultsPerPage: 3,
  },`,ya=`<div class="chi-card -portal -bg--white -bg-md--grey-15">
  <div class="chi-card__header -sm">
    <div class="chi-card__title">Title</div>
  </div>
  <div class="chi-card__content -p--0">
    <div class="chi-data-table -portal -compact">
      <div class="chi-data-table__head">
        <div class="chi-data-table__row">
          <div class="chi-data-table__cell -selectable"></div>
          <div class="chi-data-table__cell">
            <div>Name</div>
          </div>
          <div class="chi-data-table__cell">
            <div>ID</div>
          </div>
          <div class="chi-data-table__cell">
            <div>Last Login</div>
          </div>
        </div>
      </div>
      <div class="chi-data-table__body">
        <fieldset>
          <div class="chi-data-table__row -md">
            <div class="chi-data-table__cell -selectable">
              <div class="chi-radio">
                <input type="radio" class="chi-radio__input" id="radio-ba2" name="radios">
                <label class="chi-radio__label" for="radio-ba2"></label>
              </div>
            </div>
            <div class=" chi-data-table__cell" data-label="Name">
              <div>Name 1</div>
            </div>
            <div class="chi-data-table__cell" data-label="ID">
              <div>name-1</div>
            </div>
            <div class="chi-data-table__cell" data-label="Last Login">
              <div>18 Dec 2020 3:26 p.m.</div>
            </div>
          </div>
          <div class="chi-data-table__row -striped -md">
            <div class="chi-data-table__cell -lh--1 -selectable">
              <div class="chi-radio">
                <input type="radio" class="chi-radio__input" id="radio-ba3" name="radios">
                <label class="chi-radio__label" for="radio-ba3"></label>
              </div>
            </div>
            <div class=" chi-data-table__cell" data-label="Name">
              <div>Name 2</div>
            </div>
            <div class="chi-data-table__cell" data-label="ID">
              <div>name-2</div>
            </div>
            <div class="chi-data-table__cell" data-label="Last Login">
              <div>18 Dec 2020 2:38 a.m.</div>
            </div>
          </div>
          <div class="chi-data-table__row -md">
            <div class="chi-data-table__cell -lh--1 -selectable">
              <div class="chi-radio">
                <input type="radio" class="chi-radio__input" id="radio-ba4" name="radios">
                <label class="chi-radio__label" for="radio-ba4"></label>
              </div>
            </div>
            <div class=" chi-data-table__cell" data-label="Name">
              <div>Name 3</div>
            </div>
            <div class="chi-data-table__cell" data-label="ID">
              <div>name-3</div>
            </div>
            <div class="chi-data-table__cell" data-label="Last Login">
              <div>5 Nov 2020 10:15 a.m.</div>
            </div>
          </div>
        </fieldset>
      </div>
      <div class="chi-data-table__footer">
        <nav class="chi-pagination -compact" role="navigation" aria-label="Pagination">
          <div class="chi-pagination__content">
            <div class="chi-pagination__start">
              <div class="chi-pagination__results">
                <span class="chi-pagination__label">6 Results</span>
              </div>
            </div>
            <div class="chi-pagination__center">
              <div class="chi-pagination__button-group chi-button-group">
                <button class="chi-button -icon -flat -xs" aria-label="First page" disabled>
                  <div class="chi-button__content">
                    <i class="chi-icon icon-page-first" aria-hidden="true"></i>
                  </div>
                </button>
                <button class="chi-button -icon -flat -xs" aria-label="Previous page" disabled>
                  <div class="chi-button__content">
                    <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
                  </div>
                </button>
              </div>
              <div class="chi-pagination__label">
                <strong>1</strong>
                <span>of</span>
                <strong>2</strong>
              </div>
              <div class="chi-pagination__button-group chi-button-group">
                <button class="chi-button -icon -flat -xs" aria-label="Next page">
                  <div class="chi-button__content">
                    <i class="chi-icon icon-chevron-right" aria-hidden="true"></i>
                  </div>
                </button>
                <button class="chi-button -icon -flat -xs" aria-label="Last page">
                  <div class="chi-button__content">
                    <i class="chi-icon icon-page-last" aria-hidden="true"></i>
                  </div>
                </button>
              </div>
            </div>
            <div class="chi-pagination__end"></div>
          </div>
        </nav>
      </div>
    </div>
  </div>
</div>`,Na=R.map(c=>c.id==="name-1"?{...c,data:["This is a long content with a second line wrapping without tooltip: Cell wrapped on two lines",...c.data.slice(1)]}:c.id==="name-2"?{...c,data:["This is a long content with a second line wrapping with tooltip: This is a long content for the tooltip in the wrapped cell",...c.data.slice(1)]}:c),La=`<!-- Vue component -->
<ChiDataTable :config="config" :dataTableData="table"></ChiDataTable>

<!-- Config and Data -->
data: {
  config: {
    columnResize: true,
    style: {
      portal: true,
      noBorder: false,
      bordered: false,
      hover: false,
      size: 'md',
      striped: true,
    },
    pagination: {
      activePage: 1,
      compact: true,
      firstLast: true,
      pageJumper: false,
    },
    resultsPerPage: 3,
    cellWrap: true,
  },
  table: {
    head: {
      name: { label: 'This is a long header content with a second line wrapping without tooltip: This is a long content for the tooltip in the wrapped cell', key: true, bold: true },
      id: { label: 'ID', key: true },
      lastLogin: { label: 'Last Login' },
    },
    body: [
      ${T("name-1","This is a long content with a second line wrapping without tooltip: Cell wrapped on two lines","18 Dec 2020 3:26 p.m.")}
      ${T("name-2","This is a long content with a second line wrapping with tooltip: This is a long content for the tooltip in the wrapped cell","18 Dec 2020 2:38 a.m.")}
      ${T("name-3","Name 3","5 Nov 2020 10:15 a.m.")}
      ${T("name-4","Name 4","18 Dec 2020 3:26 p.m.")}
      ${T("name-5","Name 5","18 Dec 2020 2:38 a.m.")}
      ${T("name-6","Name 6","5 Nov 2020 10:15 a.m.")}
    ]
  }
}`,Ta=`<div class="chi-card -portal -bg--white -bg-md--grey-15">
  <div class="chi-card__header -sm">
    <div class="chi-card__title">Title</div>
  </div>
  <div class="chi-card__content -p--0">
    <div class="chi-data-table -portal -compact">
      <div class="chi-data-table__head">
        <div class="chi-data-table__row">
          <div class="chi-data-table__cell" data-label="This is a long header content with a second line wrapping without tooltip: This is a long content for the tooltip in the wrapped cell">
            <div class="-cell-wrap">This is a long header content with a second line wrapping without tooltip: This is a long content for the tooltip in the wrapped cell</div>
          </div>
          <div class="chi-data-table__cell" data-label="ID">
            <div class="-cell-wrap">ID</div>
          </div>
          <div class="chi-data-table__cell" data-label="Last Login">
            <div class="-cell-wrap">Last Login</div>
          </div>
        </div>
      </div>
      <div class="chi-data-table__body">
        <div class="chi-data-table__row -md">
          <div class="chi-data-table__cell -key -bold">
            <div class="-cell-wrap">This is a long content with a second line wrapping without tooltip: Cell wrapped on two lines</div>
          </div>
          <div class="chi-data-table__cell -key">
            <div class="-cell-wrap">name-1</div>
          </div>
          <div class="chi-data-table__cell">
            <div class="-cell-wrap">18 Dec 2020 3:26 p.m.</div>
          </div>
        </div>
        <div class="chi-data-table__row -striped -md">
          <div class="chi-data-table__cell -key -bold">
            <div class="-cell-wrap">This is a long content with a second line wrapping with tooltip: This is a long content for the tooltip in the wrapped cell</div>
          </div>
          <div class="chi-data-table__cell -key">
            <div class="-cell-wrap">name-2</div>
          </div>
          <div class="chi-data-table__cell">
            <div class="-cell-wrap">18 Dec 2020 2:38 a.m.</div>
          </div>
        </div>
        <div class="chi-data-table__row -md">
          <div class="chi-data-table__cell -key -bold">
            <div class="-cell-wrap">Name 3</div>
          </div>
          <div class="chi-data-table__cell -key">
            <div class="-cell-wrap">name-3</div>
          </div>
          <div class="chi-data-table__cell">
            <div class="-cell-wrap">5 Nov 2020 10:15 a.m.</div>
          </div>
        </div>
      </div>
      <div class="chi-data-table__footer">
        <nav class="chi-pagination -compact" role="navigation" aria-label="Pagination">
          <div class="chi-pagination__content">
            <div class="chi-pagination__start">
              <div class="chi-pagination__results">
                <span class="chi-pagination__label">240 Results</span>
              </div>
            </div>
            <div class="chi-pagination__center">
              <div class="chi-pagination__button-group chi-button-group">
                <button class="chi-button -icon -flat -xs" aria-label="First page" disabled>
                  <div class="chi-button__content">
                    <i class="chi-icon icon-page-first" aria-hidden="true"></i>
                  </div>
                </button>
                <button class="chi-button -icon -flat -xs" aria-label="Previous page" disabled>
                  <div class="chi-button__content">
                    <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
                  </div>
                </button>
              </div>
              <div class="chi-pagination__label">
                <strong>1</strong>
                <span>of</span>
                <strong>2</strong>
              </div>
              <div class="chi-pagination__button-group chi-button-group">
                <button class="chi-button -icon -flat -xs" aria-label="Next page" >
                  <div class="chi-button__content">
                    <i class="chi-icon icon-chevron-right" aria-hidden="true"></i>
                  </div>
                </button>
                <button class="chi-button -icon -flat -xs" aria-label="Last page">
                  <div class="chi-button__content">
                    <i class="chi-icon icon-page-last" aria-hidden="true"></i>
                  </div>
                </button>
              </div>
            </div>
            <div class="chi-pagination__end"></div>
          </div>
        </nav>
      </div>
    </div>
  </div>
</div>`,$a=`<div class="chi-card -portal -bg--white -bg-md--grey-15">
  <div class="chi-card__header -sm">
    <div class="chi-card__title">Title</div>
  </div>
  <div class="chi-card__content -p--0">
    <div class="chi-data-table -portal -compact">
      <div class="chi-data-table__head">
        <div class="chi-data-table__row">
          <div class="chi-data-table__cell">
            <div>Name</div>
          </div>
          <div class="chi-data-table__cell">
            <div>ID</div>
          </div>
          <div class="chi-data-table__cell">
            <div>Last Login</div>
          </div>
        </div>
      </div>
      <div class="chi-data-table__body">
        <div class="chi-data-table__row -md">
          <div class="chi-data-table__cell -key -bold">
            <div>Name 1</div>
          </div>
          <div class="chi-data-table__cell -key">
            <div>name-1</div>
          </div>
          <div class="chi-data-table__cell">
            <div>18 Dec 2020 3:26 p.m.</div>
          </div>
        </div>
        <div class="chi-data-table__row -row--danger -striped -md">
          <div class="chi-data-table__cell -key -bold">
            <div>Name 2</div>
          </div>
          <div class="chi-data-table__cell -key">
            <div>name-2</div>
          </div>
          <div class="chi-data-table__cell">
            <div>18 Dec 2020 2:38 a.m.</div>
          </div>
        </div>
        <div class="chi-data-table__row -md">
          <div class="chi-data-table__cell -key -bold">
            <div>Name 3</div>
          </div>
          <div class="chi-data-table__cell -key">
            <div>name-3</div>
          </div>
          <div class="chi-data-table__cell">
            <div>5 Nov 2020 10:15 a.m.</div>
          </div>
        </div>
      </div>
      <div class="chi-data-table__footer">
        <nav class="chi-pagination -compact" role="navigation" aria-label="Pagination">
          <div class="chi-pagination__content">
            <div class="chi-pagination__start">
              <div class="chi-pagination__results">
                <span class="chi-pagination__label">6 Results</span>
              </div>
            </div>
            <div class="chi-pagination__center">
              <div class="chi-pagination__button-group chi-button-group">
                <button class="chi-button -icon -flat -xs" aria-label="First page" disabled>
                  <div class="chi-button__content">
                    <i class="chi-icon icon-page-first" aria-hidden="true"></i>
                  </div>
                </button>
                <button class="chi-button -icon -flat -xs" aria-label="Previous page" disabled>
                  <div class="chi-button__content">
                    <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
                  </div>
                </button>
              </div>
              <div class="chi-pagination__label">
                <strong>1</strong>
                <span>of</span>
                <strong>2</strong>
              </div>
              <div class="chi-pagination__button-group chi-button-group">
                <button class="chi-button -icon -flat -xs" aria-label="Next page">
                  <div class="chi-button__content">
                    <i class="chi-icon icon-chevron-right" aria-hidden="true"></i>
                  </div>
                </button>
                <button class="chi-button -icon -flat -xs" aria-label="Last page">
                  <div class="chi-button__content">
                    <i class="chi-icon icon-page-last" aria-hidden="true"></i>
                  </div>
                </button>
              </div>
            </div>
            <div class="chi-pagination__end"></div>
          </div>
        </nav>
      </div>
    </div>
  </div>
</div>`,ka=`<div class="chi-data-table">
  <div class="chi-data-table__head">
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell -selectable">
        <div class="chi-checkbox">
          <input type="checkbox" class="chi-checkbox__input" id="checkbox-ba1">
          <label class="chi-checkbox__label" for="checkbox-ba1">
            <div class="-sr--only">Label</div>
          </label>
        </div>
        <div class="chi-dropdown">
          <button aria-label="Select All Dropdown" data-position="bottom-start" class="chi-button -icon -flat -has-active">
            <div class="chi-button__content">
              <i aria-hidden="true" class="chi-icon icon-chevron-down -xs"></i>
            </div>
          </button>
          <div class="chi-dropdown__menu" x-placement="bottom-start">
            <a class="chi-dropdown__menu-item">Select all items, this page</a>
            <a class="chi-dropdown__menu-item">Select all items, all pages</a>
            <a class="chi-dropdown__menu-item">Deselect all</a>
          </div>
        </div>
      </div>
      <div class="chi-data-table__cell">
        <div>Name</div>
      </div>
      <div class="chi-data-table__cell">
        <div>ID</div>
      </div>
      <div class="chi-data-table__cell">
        <div>Last Login</div>
      </div>
    </div>
  </div>
  <div class="chi-data-table__body">
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell -selectable">
        <div class="chi-checkbox">
          <input type="checkbox" class="chi-checkbox__input" id="checkbox-ba2">
          <label class="chi-checkbox__label" for="checkbox-ba2">
            <div class="-sr--only">Label</div>
          </label>
        </div>
      </div>
      <div class="chi-data-table__cell" data-label="Name">
        <div>Name 1</div>
      </div>
      <div class="chi-data-table__cell" data-label="ID">
        <div>name-1</div>
      </div>
      <div class="chi-data-table__cell" data-label="Last Login">
        <div>18 Dec 2020 3:26 p.m.</div>
      </div>
    </div>
    <div class="chi-data-table__row -selected">
      <div class="chi-data-table__cell -lh--1 -selectable">
        <div class="chi-checkbox">
          <input type="checkbox" class="chi-checkbox__input" id="checkbox-ba3">
          <label class="chi-checkbox__label" for="checkbox-ba3">
            <div class="-sr--only">Label</div>
          </label>
        </div>
      </div>
      <div class="chi-data-table__cell" data-label="Name">
        <div>Name 2</div>
      </div>
      <div class="chi-data-table__cell" data-label="ID">
        <div>name-2</div>
      </div>
      <div class="chi-data-table__cell" data-label="Last Login">
        <div>18 Dec 2020 2:38 a.m.</div>
      </div>
    </div>
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell -lh--1 -selectable">
        <div class="chi-checkbox">
          <input type="checkbox" class="chi-checkbox__input" id="checkbox-ba4">
          <label class="chi-checkbox__label" for="checkbox-ba4">
            <div class="-sr--only">Label</div>
          </label>
        </div>
      </div>
      <div class="chi-data-table__cell" data-label="Name">
        <div>Name 3</div>
      </div>
      <div class="chi-data-table__cell" data-label="ID">
        <div>name-3</div>
      </div>
      <div class="chi-data-table__cell" data-label="Last Login">
        <div>5 Nov 2020 10:15 a.m.</div>
      </div>
    </div>
  </div>
  <div class="chi-data-table__footer">
    <nav class="chi-pagination" role="navigation" aria-label="Pagination">
      <div class="chi-pagination__content">
        <div class="chi-pagination__start">
          <div class="chi-pagination__results">
            <span class="chi-pagination__label">6 results</span>
          </div>
          <div class="chi-pagination__page-size">
            <div class="chi-dropdown">
              <button class="chi-button -flat -px--1 chi-dropdown__trigger" id="pagesize-7">20</button>
              <div class="chi-dropdown__menu -w--xs">
                <a class="chi-dropdown__menu-item -active" href="#">20</a>
                <a class="chi-dropdown__menu-item" href="#">40</a>
                <a class="chi-dropdown__menu-item" href="#">60</a>
                <a class="chi-dropdown__menu-item" href="#">80</a>
                <a class="chi-dropdown__menu-item" href="#">All</a>
              </div>
            </div>
            <span class="chi-pagination__label">per page</span>
          </div>
        </div>
        <div class="chi-pagination__center">
          <div class="chi-pagination__button-group chi-button-group">
            <button class="chi-button -icon -flat" aria-label="Previous page">
              <div class="chi-button__content">
                <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
              </div>
            </button>
            <button class="chi-button -flat -active" aria-label="Page 1">1</button>
            <button class="chi-button -flat" aria-label="Page 2">2</button>
            <button class="chi-button -icon -flat" aria-label="Next page">
              <div class="chi-button__content">
                <i class="chi-icon icon-chevron-right" aria-hidden="true"></i>
              </div>
            </button>
          </div>
        </div>
        <div class="chi-pagination__end">
          <div class="chi-pagination__jumper">
            <label class="chi-pagination__label" for="jumper-input-7">Go to page:</label>
            <input class="chi-input" type="text" id="jumper-input-7" />
          </div>
        </div>
      </div>
    </nav>
  </div>
</div>`,O=(c,s,o)=>`<!-- Vue component -->
<ChiDataTable :config="config" :dataTableData="table"></ChiDataTable>

<!-- Config and Data -->
data: {
  ${c}
  table: {
    ${s}
    ${o}
  }
}`,Ia=`head: {
      name: { label: 'Name', key: true, bold: true },
      id: { label: 'ID' },
      lastLogin: { label: 'Last Login' },
    },`,ha=`body: [
      ${T("name-1","Name 1","18 Dec 2020 3:26 p.m.",[],!1,!1,!0,!0)}
      ${T("name-2","Name 2","18 Dec 2020 2:38 a.m.",[],!1,!1,!1,!0)}
      ${T("name-3","Name 3","5 Nov 2020 10:15 a.m.",[],!1,!1,!1,!0)}
      ${T("name-4","Name 4","18 Dec 2020 3:26 p.m.",[],!1,!1,!1,!0)}
      ${T("name-5","Name 5","18 Dec 2020 2:38 a.m.",[],!1,!1,!1,!0)}
      ${T("name-6","Name 6","5 Nov 2020 10:15 a.m.",[],!1,!1,!1,!0)}
    ]`,Sa=`body: [
      ${V("name-1","Name 1","18 Dec 2020 3:26 p.m.",[x("Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."),x("Child Name 2","child-name-2","18 Dec 2020 2:38 a.m.")],!0)}
      ${V("name-2","Name 2","18 Dec 2020 2:38 a.m.",[x("Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."),x("Child Name 2","child-name-2","18 Dec 2020 2:38 a.m.")])}
      ${V("name-3","Name 3","5 Nov 2020 10:15 a.m.",[x("Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."),x("Child Name 2","child-name-2","18 Dec 2020 2:38 a.m.")])}
      ${V("name-4","Name 4","18 Dec 2020 3:26 p.m.",[x("Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."),x("Child Name 2","child-name-2","18 Dec 2020 2:38 a.m.")])}
      ${V("name-5","Name 5","18 Dec 2020 2:38 a.m.",[x("Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."),x("Child Name 2","child-name-2","18 Dec 2020 2:38 a.m.")])}
      ${V("name-6","Name 6","5 Nov 2020 10:15 a.m.",[x("Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."),x("Child Name 2","child-name-2","18 Dec 2020 2:38 a.m.")])}
    ]`,za=`body: [
      ${j("name-1","Name 1","18 Dec 2020 3:26 p.m.",[x("Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."),x("Child Name 2","child-name-2","18 Dec 2020 2:38 a.m.")],!0,!0)}
      ${j("name-2","Name 2","18 Dec 2020 2:38 a.m.",[x("Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."),x("Child Name 2","child-name-2","18 Dec 2020 2:38 a.m.")])}
      ${j("name-3","Name 3","5 Nov 2020 10:15 a.m.",[x("Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."),x("Child Name 2","child-name-2","18 Dec 2020 2:38 a.m.")])}
      ${j("name-4","Name 4","18 Dec 2020 3:26 p.m.",[x("Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."),x("Child Name 2","child-name-2","18 Dec 2020 2:38 a.m.")])}
      ${j("name-5","Name 5","18 Dec 2020 3:26 p.m.",[x("Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."),x("Child Name 2","child-name-2","18 Dec 2020 2:38 a.m.")])}
      ${j("name-6","Name 6","5 Nov 2020 10:15 a.m.",[x("Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."),x("Child Name 2","child-name-2","18 Dec 2020 2:38 a.m.")])}
    ]`,_a=[{expanded:!0,id:"name-1",nestedContent:{value:"Accordion content"},data:["Name 1","name-1","18 Dec 2020 3:26 p.m."]},{id:"name-2",nestedContent:{value:"Accordion content"},data:["Name 2","name-2","18 Dec 2020 2:38 a.m."]},{id:"name-3",nestedContent:{value:"Accordion content"},data:["Name 3","name-3","5 Nov 2020 10:15 a.m."]},{id:"name-4",nestedContent:{value:"Accordion content"},data:["Name 4","name-4","18 Dec 2020 3:26 p.m."]},{id:"name-5",nestedContent:{value:"Accordion content"},data:["Name 5","name-5","18 Dec 2020 2:38 a.m."]},{id:"name-6",nestedContent:{value:"Accordion content"},data:["Name 6","name-6","5 Nov 2020 10:15 a.m."]}],Pa=[{expanded:!0,id:"name-1",nestedContent:{table:{data:[{id:"name-1-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."]},{id:"name-1-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."]}]}},data:["Name 1","name-1","18 Dec 2020 3:26 p.m."]},{id:"name-2",nestedContent:{table:{data:[{id:"name-2-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."]},{id:"name-2-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."]}]}},data:["Name 2","name-2","18 Dec 2020 2:38 a.m."]},{id:"name-3",nestedContent:{table:{data:[{id:"name-3-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."]},{id:"name-3-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."]}]}},data:["Name 3","name-3","5 Nov 2020 10:15 a.m."]},{id:"name-4",nestedContent:{table:{data:[{id:"name-4-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."]},{id:"name-4-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."]}]}},data:["Name 4","name-4","18 Dec 2020 3:26 p.m."]},{id:"name-5",nestedContent:{table:{data:[{id:"name-5-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."]},{id:"name-5-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."]}]}},data:["Name 5","name-5","18 Dec 2020 2:38 a.m."]},{id:"name-6",nestedContent:{table:{data:[{id:"name-6-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."]},{id:"name-6-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."]}]}},data:["Name 6","name-6","5 Nov 2020 10:15 a.m."]}],Ea=[{expanded:!0,id:"name-1",nestedContent:{table:{data:[{expanded:!0,id:"name-1-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"name-1-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."]},{id:"name-1-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."]}]}}},{id:"name-1-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"name-1-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."]},{id:"name-1-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."]}]}}}]}},data:["Name 1","name-1","18 Dec 2020 3:26 p.m."]},{id:"name-2",nestedContent:{table:{data:[{id:"name-2-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"name-1-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."]},{id:"name-1-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."]}]}}},{id:"name-2-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"name-1-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."]},{id:"name-1-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."]}]}}}]}},data:["Name 2","name-2","18 Dec 2020 2:38 a.m."]},{id:"name-3",nestedContent:{table:{data:[{id:"name-3-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"name-1-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."]},{id:"name-1-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."]}]}}},{id:"name-3-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"name-1-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."]},{id:"name-1-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."]}]}}}]}},data:["Name 3","name-3","5 Nov 2020 10:15 a.m."]},{id:"name-4",nestedContent:{table:{data:[{id:"name-4-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"name-1-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."]},{id:"name-1-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."]}]}}},{id:"name-4-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"name-1-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."]},{id:"name-1-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."]}]}}}]}},data:["Name 4","name-4","18 Dec 2020 3:26 p.m."]},{id:"name-5",nestedContent:{table:{data:[{id:"name-5-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"name-1-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."]},{id:"name-1-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."]}]}}},{id:"name-5-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"name-1-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."]},{id:"name-1-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."]}]}}}]}},data:["Name 5","name-5","18 Dec 2020 2:38 a.m."]},{id:"name-6",nestedContent:{table:{data:[{id:"name-6-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"name-1-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."]},{id:"name-1-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."]}]}}},{id:"name-6-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."],nestedContent:{table:{data:[{id:"name-1-0",data:["Child Name 1","child-name-1","18 Dec 2020 2:38 a.m."]},{id:"name-1-1",data:["Child Name 2","child-name-2","18 Dec 2020 2:38 a.m."]}]}}}]}},data:["Name 6","name-6","5 Nov 2020 10:15 a.m."]}],Ra=`config: {
    columnResize: true,
    style: {
      portal: false,
      noBorder: false,
      bordered: false,
      hover: false,
      size: 'md',
      striped: false,
    },
    pagination: {
      activePage: 1,
      compact: false,
      firstLast: false,
      pageJumper: true,
    },
    showExpandAll: true,
    resultsPerPage: 3,
  },`,ta=`config: {
    columnResize: true,
    style: {
      portal: true,
      noBorder: false,
      bordered: false,
      hover: false,
      size: 'md',
      striped: true,
    },
    pagination: {
      activePage: 1,
      compact: true,
      firstLast: true,
      pageJumper: false,
    },
    showExpandAll: true,
    resultsPerPage: 3,
  },`,Ba=`<div class="chi-data-table">
  <div class="chi-data-table__head">
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell -expandable -position--relative">
        <button class="chi-button -icon -flat -expand -sm">
          <div class="chi-button__content">
            <i class="chi-icon icon-squares-plus-outline"></i>
          </div>
        </button>
      </div>
      <div class="chi-data-table__cell">
        <div>Name</div>
      </div>
      <div class="chi-data-table__cell">
        <div>ID</div>
      </div>
      <div class="chi-data-table__cell">
        <div>Last Login</div>
      </div>
    </div>
  </div>
  <div class="chi-data-table__body">
    <div class="chi-data-table__row -expanded">
      <div class="chi-data-table__cell -expandable">
        <button class="chi-button -icon -flat -sm" aria-label="Expand row">
          <div class="chi-button__content">
            <i class="chi-icon icon-minus" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-data-table__cell" data-label="Name">
        <div>Name 1</div>
      </div>
      <div class="chi-data-table__cell" data-label="ID">
        <div>name-1</div>
      </div>
      <div class="chi-data-table__cell" data-label="Last Login">
        <div>18 Dec 2020 3:26 p.m. </div>
      </div>
    </div>
    <div class="chi-data-table__row-child -p--2">
      <div>Accordion content</div>
    </div>
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell -expandable">
        <button class="chi-button -icon -flat -sm" aria-label="Expand row">
          <div class="chi-button__content">
            <i class="chi-icon icon-plus" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-data-table__cell" data-label="Name">
        <div>Name 2</div>
      </div>
      <div class="chi-data-table__cell" data-label="ID">
        <div>name-2</div>
      </div>
      <div class="chi-data-table__cell" data-label="Last Login">
        <div>18 Dec 2020 2:38 a.m. </div>
      </div>
    </div>
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell -expandable">
        <button class="chi-button -icon -flat -sm" aria-label="Expand row">
          <div class="chi-button__content">
            <i class="chi-icon icon-plus" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-data-table__cell" data-label="Name">
        <div>Name 3</div>
      </div>
      <div class="chi-data-table__cell" data-label="ID">
        <div>name-3</div>
      </div>
      <div class="chi-data-table__cell" data-label="Last Login">
        <div>5 Nov 2020 10:15 a.m.</div>
      </div>
    </div>
  </div>
  <div class="chi-data-table__footer">
    <nav class="chi-pagination" role="navigation" aria-label="Pagination">
      <div class="chi-pagination__content">
        <div class="chi-pagination__start">
          <div class="chi-pagination__results">
            <span class="chi-pagination__label">240 results</span>
          </div>
          <div class="chi-pagination__page-size">
            <div class="chi-dropdown">
              <button class="chi-button -flat -px--1 chi-dropdown__trigger" id="pagesize-9">20</button>
              <div class="chi-dropdown__menu -w--xs">
                <a class="chi-dropdown__menu-item -active" href="#">20</a>
                <a class="chi-dropdown__menu-item" href="#">40</a>
                <a class="chi-dropdown__menu-item" href="#">60</a>
                <a class="chi-dropdown__menu-item" href="#">80</a>
                <a class="chi-dropdown__menu-item" href="#">All</a>
              </div>
            </div>
            <span class="chi-pagination__label">per page</span>
          </div>
        </div>
        <div class="chi-pagination__center">
          <div class="chi-pagination__button-group chi-button-group">
            <button class="chi-button -icon -flat" aria-label="Previous page">
              <div class="chi-button__content">
                <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
              </div>
            </button>
            <button class="chi-button -flat -active" aria-label="Page 1">1</button>
            <button class="chi-button -flat" aria-label="Page 2">2</button>
            <button class="chi-button -icon -flat" aria-label="Next page">
              <div class="chi-button__content">
                <i class="chi-icon icon-chevron-right" aria-hidden="true"></i>
              </div>
            </button>
          </div>
        </div>
        <div class="chi-pagination__end">
          <div class="chi-pagination__jumper">
            <label class="chi-pagination__label" for="jumper-input-9">Go to page:</label>
            <input class="chi-input" type="text" id="jumper-input-9" />
          </div>
        </div>
      </div>
    </nav>
  </div>
</div>`,Aa=`<div class="chi-card -portal -bg--white -bg-md--grey-15">
  <div class="chi-card__header -sm">
    <div class="chi-card__title">Title</div>
  </div>
  <div class="chi-card__content -p--0">
    <div class="chi-data-table -portal -compact">
      <div role="row" class="chi-data-table__head">
        <div class="chi-data-table__row">
          <div class="chi-data-table__cell -expandable -position--relative">
            <div>
              <button aria-label="Expand All Rows" class="chi-button -icon -flat -expand -sm">
                <div class="chi-button__content">
                  <i class="chi-icon icon-squares-minus-outline"></i>
                </div>
                <span class="-sr--only">Expand All Rows</span>
              </button>
              <div class="chi-tooltip " data-popper-placement="top">
                <span>Collapse All</span>
              </div>
            </div>
            <div class="-position--absolute resize-handle">&nbsp;</div>
          </div>
          <div data-label="Name" class="chi-data-table__cell -justify-content-md--start -position--relative">
              Name <div class="-position--absolute resize-handle">&nbsp;</div>
          </div>
          <div data-label="ID" class="chi-data-table__cell -justify-content-md--start -position--relative">
              ID <div class="-position--absolute resize-handle">&nbsp;</div>
          </div>
          <div data-label="Last Login" class="chi-data-table__cell -justify-content-md--start -position--relative">
              Last Login <div class="-position--absolute resize-handle">&nbsp;</div>
          </div>
        </div>
      </div>
      <div class="chi-data-table__body">
        <div id="row-dt-1-name-1" data-rownumber="0" data-rowlevel="0" role="row" class="chi-data-table__row -md -expanded">
          <div role="cell" class="chi-data-table__cell -expandable">
            <button aria-label="Expand row" data-target="#row-dt-1-name-1-content" class="chi-button -icon -flat -expand -xs">
              <div class="chi-button__content">
                <i class="chi-icon icon-minus"></i>
              </div>
              <span class="-sr--only">Expand Row</span>
            </button>
          </div>
          <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
            <div class="-w--100">
              <div class="-text--truncate">Name 1</div>
            </div>
          </div>
          <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
            <div class="-w--100">
              <div class="-text--truncate">name-1</div>
            </div>
          </div>
          <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
            <div class="-w--100">
              <div class="-text--truncate">18 Dec 2020 3:26 p.m.</div>
            </div>
          </div>
        </div>
        <div id="row-dt-1-name-1-content">
          <div role="row" class="chi-data-table__row-child -p--2">Accordion content</div>
        </div>
        <div id="row-dt-1-name-2" data-rownumber="1" data-rowlevel="0" role="row" class="chi-data-table__row -striped -md -collapsed">
          <div role="cell" class="chi-data-table__cell -expandable">
            <button aria-label="Expand row" data-target="#row-dt-1-name-2-content" class="chi-button -icon -flat -expand -xs">
              <div class="chi-button__content">
                <i class="chi-icon icon-plus"></i>
              </div>
              <span class="-sr--only">Expand Row</span>
            </button>
          </div>
          <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
            <div class="-w--100">
              <div class="-text--truncate">Name 2</div>
            </div>
          </div>
          <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
            <div class="-w--100">
              <div class="-text--truncate">name-2</div>
            </div>
          </div>
          <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
            <div class="-w--100">
              <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
            </div>
          </div>
        </div>
        <div id="row-dt-1-name-2-content" style="display: none;">
          <div role="row" class="chi-data-table__row-child -p--2">Accordion content</div>
        </div>
        <div id="row-dt-1-name-3" data-rownumber="2" data-rowlevel="0" role="row" class="chi-data-table__row -md -collapsed">
          <div role="cell" class="chi-data-table__cell -expandable">
            <button aria-label="Expand row" data-target="#row-dt-1-name-3-content" class="chi-button -icon -flat -expand -xs">
              <div class="chi-button__content">
                <i class="chi-icon icon-plus"></i>
              </div>
              <span class="-sr--only">Expand Row</span>
            </button>
          </div>
          <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
            <div class="-w--100">
              <div class="-text--truncate">Name 3</div>
            </div>
          </div>
          <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
            <div class="-w--100">
              <div class="-text--truncate">name-3</div>
            </div>
          </div>
          <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
            <div class="-w--100">
              <div class="-text--truncate">5 Nov 2020 10:15 a.m.</div>
            </div>
          </div>
        </div>
        <div id="row-dt-1-name-3-content" style="display: none;">
          <div role="row" class="chi-data-table__row-child -p--2">Accordion content</div>
        </div>
      </div>
      <div class="chi-data-table__footer">
        <nav class="chi-pagination -compact" role="navigation" aria-label="Pagination">
          <div class="chi-pagination__content">
            <div class="chi-pagination__start">
              <div class="chi-pagination__results">
                <span class="chi-pagination__label">6 Results</span>
              </div>
            </div>
            <div class="chi-pagination__center">
              <div class="chi-pagination__button-group chi-button-group">
                <button class="chi-button -icon -flat -xs" aria-label="First page" disabled>
                  <div class="chi-button__content">
                    <i class="chi-icon icon-page-first" aria-hidden="true"></i>
                  </div>
                </button>
                <button class="chi-button -icon -flat -xs" aria-label="Previous page" disabled>
                  <div class="chi-button__content">
                    <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
                  </div>
                </button>
              </div>
              <div class="chi-pagination__label">
                <strong>1</strong>
                <span>of</span>
                <strong>2</strong>
              </div>
              <div class="chi-pagination__button-group chi-button-group">
                <button class="chi-button -icon -flat -xs" aria-label="Next page">
                  <div class="chi-button__content">
                    <i class="chi-icon icon-chevron-right" aria-hidden="true"></i>
                  </div>
                </button>
                <button class="chi-button -icon -flat -xs" aria-label="Last page">
                  <div class="chi-button__content">
                    <i class="chi-icon icon-page-last" aria-hidden="true"></i>
                  </div>
                </button>
              </div>
            </div>
            <div class="chi-pagination__end"></div>
          </div>
        </nav>
      </div>
    </div>
  </div>
</div>`,Ha=`<div class="chi-card -portal -bg--white -bg-md--grey-15">
  <div class="chi-card__header -sm">
    <div class="chi-card__title">Title</div>
  </div>
  <div class="chi-card__content -p--0">
    <div class="chi-data-table -portal -compact">
      <div class="chi-data-table__head">
        <div class="chi-data-table__row">
          <div class="chi-data-table__cell -expandable -position--relative">
            <button class="chi-button -icon -flat -expand -sm">
              <div class="chi-button__content">
                <i class="chi-icon icon-squares-minus-outline"></i>
              </div>
            </button>
          </div>
          <div class="chi-data-table__cell">
            <div>Name</div>
          </div>
          <div class="chi-data-table__cell">
            <div>ID</div>
          </div>
          <div class="chi-data-table__cell">
            <div>Last Login</div>
          </div>
        </div>
      </div>
      <div class="chi-data-table__body">
        <div id="row-dt-1-name-1" data-rownumber="0" data-rowlevel="0" role="row" class="chi-data-table__row -md -expanded">
          <div role="cell" class="chi-data-table__cell -expandable">
            <button aria-label="Expand row" data-target="#row-dt-1-name-1-content" class="chi-button -icon -flat -expand -xs">
              <div class="chi-button__content">
                <i class="chi-icon icon-minus"></i>
              </div>
              <span class="-sr--only">Expand Row</span>
            </button>
          </div>
          <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
            <div class="-w--100">
              <div class="-text--truncate">Name 1</div>
            </div>
          </div>
          <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
            <div class="-w--100">
              <div class="-text--truncate">name-1</div>
            </div>
          </div>
          <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
            <div class="-w--100">
              <div class="-text--truncate">18 Dec 2020 3:26 p.m.</div>
            </div>
          </div>
        </div>
        <div id="row-dt-1-name-1-content">
          <div id="row-dt-1-name-1-0" data-rownumber="0-1" data-rowlevel="1" role="row" class="chi-data-table__row-child -md">
            <div class="chi-data-table__cell -expandable"></div>
            <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
              <div class="-w--100">
                <div class="-text--truncate">Child Name 1</div>
              </div>
            </div>
            <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
              <div class="-w--100">
                <div class="-text--truncate">child-name-1</div>
              </div>
            </div>
            <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
              <div class="-w--100">
                <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
              </div>
            </div>
          </div>
          <div id="row-dt-1-name-1-1" data-rownumber="0-2" data-rowlevel="1" role="row" class="chi-data-table__row-child -md">
            <div role="cell" class="chi-data-table__cell -expandable"></div>
            <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
              <div class="-w--100">
                <div class="-text--truncate">Child Name 2</div>
              </div>
            </div>
            <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
              <div class="-w--100">
                <div class="-text--truncate">child-name-2</div>
              </div>
            </div>
            <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
              <div class="-w--100">
                <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
              </div>
            </div>
          </div>
        </div>
      <div id="row-dt-1-name-2" data-rownumber="1" data-rowlevel="0" role="row" class="chi-data-table__row -striped -md -collapsed">
          <div role="cell" class="chi-data-table__cell -expandable">
            <button aria-label="Expand row" data-target="#row-dt-1-name-2-content" class="chi-button -icon -flat -expand -xs">
              <div class="chi-button__content">
                <i class="chi-icon icon-plus"></i>
              </div>
              <span class="-sr--only">Expand Row</span>
            </button>
          </div>
          <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
            <div class="-w--100">
              <div class="-text--truncate">Name 2</div>
            </div>
          </div>
          <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
            <div class="-w--100">
              <div class="-text--truncate">name-2</div>
            </div>
          </div>
          <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
            <div class="-w--100">
              <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
            </div>
          </div>
        </div>
        <div id="row-dt-1-name-2-content" style="display: none;">
          <div id="row-dt-1-name-2-0" data-rownumber="2-1" data-rowlevel="1" role="row" class="chi-data-table__row-child -md -collapsed">
            <div class="chi-data-table__cell -expandable"></div>
            <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
              <button aria-label="Expand row" data-target="#row-dt-1-name-2-0-content" class="chi-button -icon -flat -expand -xs">
                <div class="chi-button__content">
                  <i class="chi-icon icon-plus"></i>
                </div>
                <span class="-sr--only">Expand Row</span>
              </button>
              <div class="-w--100">
                <div class="-text--truncate">Child Name 1</div>
              </div>
            </div>
            <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
              <div class="-w--100">
                <div class="-text--truncate">child-name-1</div>
              </div>
            </div>
            <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
              <div class="-w--100">
                <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
              </div>
            </div>
          </div>
          <div id="row-dt-1-name-2-1" data-rownumber="2-0-1" data-rowlevel="2" role="row" class="chi-data-table__row-grand-child -md">
            <div role="cell" class="chi-data-table__cell -expandable"></div>
            <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
              <div class="-w--100">
                <div class="-text--truncate">Child Name 2</div>
              </div>
            </div>
            <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
              <div class="-w--100">
                <div class="-text--truncate">child-name-2</div>
              </div>
            </div>
            <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
              <div class="-w--100">
                <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
              </div>
            </div>
          </div>
        </div>
      <div id="row-dt-1-name-3" data-rownumber="2-0" data-rowlevel="1" role="row" class="chi-data-table__row -md -collapsed">
          <div role="cell" class="chi-data-table__cell -expandable">
            <button aria-label="Expand row" data-target="#row-dt-1-name-3-content" class="chi-button -icon -flat -expand -xs">
              <div class="chi-button__content">
                <i class="chi-icon icon-plus"></i>
              </div>
              <span class="-sr--only">Expand Row</span>
            </button>
          </div>
          <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
            <div class="-w--100">
              <div class="-text--truncate">Name 3</div>
            </div>
          </div>
          <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
            <div class="-w--100">
              <div class="-text--truncate">name-3</div>
            </div>
          </div>
          <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
            <div class="-w--100">
              <div class="-text--truncate">5 Nov 2020 10:15 a.m.</div>
            </div>
          </div>
        </div>
        <div id="row-dt-1-name-3-content" style="display: none;">
          <div id="row-dt-1-name-3-0" data-rownumber="2-1" data-rowlevel="1" role="row" class="chi-data-table__row-child -md -collapsed">
            <div class="chi-data-table__cell"></div>
            <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
              <button aria-label="Expand row" data-target="#row-dt-1-name-3-0-content" class="chi-button -icon -flat -expand -xs">
                <div class="chi-button__content">
                  <i class="chi-icon icon-plus"></i>
                </div>
                <span class="-sr--only">Expand Row</span>
              </button>
              <div class="-w--100">
                <div class="-text--truncate">Child Name 1</div>
              </div>
            </div>
            <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
              <div class="-w--100">
                <div class="-text--truncate">child-name-1</div>
              </div>
            </div>
            <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
              <div class="-w--100">
                <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
              </div>
            </div>
          </div>
          <div id="row-dt-1-name-3-1" data-rownumber="2-0-1" data-rowlevel="2" role="row" class="chi-data-table__row-grand-child -md">
            <div role="cell" class="chi-data-table__cell -expandable"></div>
            <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
              <div class="-w--100">
                <div class="-text--truncate">Child Name 2</div>
              </div>
            </div>
            <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
              <div class="-w--100">
                <div class="-text--truncate">child-name-2</div>
              </div>
            </div>
            <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
              <div class="-w--100">
                <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="chi-data-table__footer">
        <nav class="chi-pagination -compact" role="navigation" aria-label="Pagination">
          <div class="chi-pagination__content">
            <div class="chi-pagination__start">
              <div class="chi-pagination__results">
                <span class="chi-pagination__label">6 Results</span>
              </div>
            </div>
            <div class="chi-pagination__center">
              <div class="chi-pagination__button-group chi-button-group">
                <button class="chi-button -icon -flat -xs" aria-label="First page" disabled>
                  <div class="chi-button__content">
                    <i class="chi-icon icon-page-first" aria-hidden="true"></i>
                  </div>
                </button>
                <button class="chi-button -icon -flat -xs" aria-label="Previous page" disabled>
                  <div class="chi-button__content">
                    <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
                  </div>
                </button>
              </div>
              <div class="chi-pagination__label">
                <strong>1</strong>
                <span>of</span>
                <strong>2</strong>
              </div>
              <div class="chi-pagination__button-group chi-button-group">
                <button class="chi-button -icon -flat -xs" aria-label="Next page">
                  <div class="chi-button__content">
                    <i class="chi-icon icon-chevron-right" aria-hidden="true"></i>
                  </div>
                </button>
                <button class="chi-button -icon -flat -xs" aria-label="Last page">
                  <div class="chi-button__content">
                    <i class="chi-icon icon-page-last" aria-hidden="true"></i>
                  </div>
                </button>
              </div>
            </div>
            <div class="chi-pagination__end"></div>
          </div>
        </nav>
      </div>
    </div>
  </div>
</div>`,Ma=`<div class="chi-card -portal -bg--white -bg-md--grey-15">
  <div class="chi-card__header -sm">
    <div class="chi-card__title">Title</div>
  </div>
  <div class="chi-card__content -p--0">
    <div class="chi-data-table -portal -compact">
      <div role="row" class="chi-data-table__head">
        <div class="chi-data-table__row">
          <div class="chi-data-table__cell -expandable -position--relative">
            <div>
              <button aria-label="Expand All Rows" class="chi-button -icon -flat -expand -sm">
                <div class="chi-button__content">
                  <i class="chi-icon icon-squares-minus-outline"></i>
                </div>
                <span class="-sr--only">Expand All Rows</span>
              </button>
              <div class="chi-tooltip " data-popper-placement="top">
                <span>Collapse All</span>
              </div>
            </div>
            <div class="-position--absolute resize-handle">&nbsp;</div>
          </div>
          <div data-label="Name" class="chi-data-table__cell -justify-content-md--start -position--relative">
            Name <div class="-position--absolute resize-handle">&nbsp;</div>
          </div>
          <div data-label="ID" class="chi-data-table__cell -justify-content-md--start -position--relative">
            ID <div class="-position--absolute resize-handle">&nbsp;</div>
          </div>
          <div data-label="Last Login" class="chi-data-table__cell -justify-content-md--start -position--relative">
            Last Login <div class="-position--absolute resize-handle">&nbsp;</div>
          </div>
        </div>
      </div>

      <div class="chi-data-table__body">
        <div id="row-dt-1-name-1" data-rownumber="0" data-rowlevel="0" role="row" class="chi-data-table__row -md -expanded">
          <div role="cell" class="chi-data-table__cell -expandable">
            <button aria-label="Expand row" data-target="#row-dt-1-name-1-content" class="chi-button -icon -flat -expand -xs">
              <div class="chi-button__content">
                <i class="chi-icon icon-minus"></i>
              </div>
              <span class="-sr--only">Expand Row</span>
            </button>
          </div>
          <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
            <div class="-w--100">
              <div class="-text--truncate">Name 1</div>
            </div>
          </div>
          <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
            <div class="-w--100">
              <div class="-text--truncate">name-1</div>
            </div>
          </div>
          <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
            <div class="-w--100">
              <div class="-text--truncate">18 Dec 2020 3:26 p.m.</div>
            </div>
          </div>
        </div>
        <div id="row-dt-1-name-1-content">
          <div id="row-dt-1-name-1-0" data-rownumber="0-0" data-rowlevel="1" role="row" class="chi-data-table__row-child -md -expanded">
            <div class="chi-data-table__cell -expandable"></div>
            <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
              <button aria-label="Expand row" data-target="#row-dt-1-name-1-0-content" class="chi-button -icon -flat -expand -xs">
                <div class="chi-button__content">
                  <i class="chi-icon icon-minus"></i>
                </div>
                <span class="-sr--only">Expand Row</span>
              </button>
              <div class="-w--100">
                <div class="-text--truncate">Child Name 1</div>
              </div>
            </div>
            <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
              <div class="-w--100">
                <div class="-text--truncate">child-name-1</div>
              </div>
            </div>
            <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
              <div class="-w--100">
                <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
              </div>
            </div>
          </div>
          <div id="row-dt-1-name-1-0-content">
            <div id="row-dt-1-name-1-0" data-rownumber="0-0-0" data-rowlevel="2" role="row" class="chi-data-table__row-grand-child -md">
              <div role="cell" class="chi-data-table__cell -expandable"></div>
              <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
                <div class="-w--100">
                  <div class="-text--truncate">Child Name 1</div>
                </div>
              </div>
              <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
                <div class="-w--100">
                  <div class="-text--truncate">child-name-1</div>
                </div>
              </div>
              <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
                <div class="-w--100">
                  <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
                </div>
              </div>
            </div>
            <div id="row-dt-1-name-1-1" data-rownumber="0-0-1" data-rowlevel="2" role="row" class="chi-data-table__row-grand-child -md">
              <div role="cell" class="chi-data-table__cell -expandable"></div>
              <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
                <div class="-w--100">
                  <div class="-text--truncate">Child Name 2</div>
                </div>
              </div>
              <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
                <div class="-w--100">
                  <div class="-text--truncate">child-name-2</div>
                </div>
              </div>
              <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
                <div class="-w--100">
                  <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
                </div>
              </div>
            </div>
          </div>
          <div id="row-dt-1-name-1-1" data-rownumber="0-1" data-rowlevel="1" role="row" class="chi-data-table__row-child -md -collapsed">
            <div class="chi-data-table__cell -expandable"></div>
            <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
              <button aria-label="Expand row" data-target="#row-dt-1-name-1-1-content" class="chi-button -icon -flat -expand -xs">
                <div class="chi-button__content">
                  <i class="chi-icon icon-plus"></i>
                </div>
                <span class="-sr--only">Expand Row</span>
              </button>
              <div class="-w--100">
                <div class="-text--truncate">Child Name 2</div>
              </div>
            </div>
            <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
              <div class="-w--100">
                <div class="-text--truncate">child-name-2</div>
              </div>
            </div>
            <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
              <div class="-w--100">
                <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
              </div>
            </div>
          </div>
          <div id="row-dt-1-name-1-1-content" style="display: none;">
            <div id="row-dt-1-name-1-0" data-rownumber="0-1-0" data-rowlevel="2" role="row" class="chi-data-table__row-grand-child -md">
              <div role="cell" class="chi-data-table__cell -expandable"></div>
              <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
                <div class="-w--100">
                  <div class="-text--truncate">Child Name 1</div>
                </div>
              </div>
              <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
                <div class="-w--100">
                  <div class="-text--truncate">child-name-1</div>
                </div>
              </div>
              <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
                <div class="-w--100">
                  <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
                </div>
              </div>
            </div>
            <div id="row-dt-1-name-1-1" data-rownumber="0-1-1" data-rowlevel="2" role="row" class="chi-data-table__row-grand-child -md">
              <div role="cell" class="chi-data-table__cell -expandable"></div>
              <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
                <div class="-w--100">
                  <div class="-text--truncate">Child Name 2</div>
                </div>
              </div>
              <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
                <div class="-w--100">
                  <div class="-text--truncate">child-name-2</div>
                </div>
              </div>
              <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
                <div class="-w--100">
                  <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
                </div>
              </div>
            </div>
          </div>
        </div>


        <div id="row-dt-1-name-2" data-rownumber="1" data-rowlevel="0" role="row" class="chi-data-table__row -striped -md -collapsed">
          <div role="cell" class="chi-data-table__cell -expandable">
            <button aria-label="Expand row" data-target="#row-dt-1-name-2-content" class="chi-button -icon -flat -expand -xs">
              <div class="chi-button__content">
                <i class="chi-icon icon-plus"></i>
              </div>
              <span class="-sr--only">Expand Row</span>
            </button>
          </div>
          <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
            <div class="-w--100">
              <div class="-text--truncate">Name 2</div>
            </div>
          </div>
          <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
            <div class="-w--100">
              <div class="-text--truncate">name-2</div>
            </div>
          </div>
          <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
            <div class="-w--100">
              <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
            </div>
          </div>
        </div>
        <div id="row-dt-1-name-2-content" style="display: none;">
          <div id="row-dt-1-name-2-0" data-rownumber="1-0" data-rowlevel="1" role="row" class="chi-data-table__row-child -md -collapsed">
            <div class="chi-data-table__cell -expandable"></div>
            <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
              <button aria-label="Expand row" data-target="#row-dt-1-name-2-0-content" class="chi-button -icon -flat -expand -xs">
                <div class="chi-button__content">
                  <i class="chi-icon icon-plus"></i>
                </div>
                <span class="-sr--only">Expand Row</span>
              </button>
              <div class="-w--100">
                <div class="-text--truncate">Child Name 1</div>
              </div>
            </div>
            <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
              <div class="-w--100">
                <div class="-text--truncate">child-name-1</div>
              </div>
            </div>
            <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
              <div class="-w--100">
                <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
              </div>
            </div>
          </div>
          <div id="row-dt-1-name-2-0-content" style="display: none;">
            <div id="row-dt-1-name-1-0" data-rownumber="1-0-0" data-rowlevel="2" role="row" class="chi-data-table__row-grand-child -md">
              <div role="cell" class="chi-data-table__cell -expandable"></div>
              <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
                <div class="-w--100">
                  <div class="-text--truncate">Child Name 1</div>
                </div>
              </div>
              <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
                <div class="-w--100">
                  <div class="-text--truncate">child-name-1</div>
                </div>
              </div>
              <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
                <div class="-w--100">
                  <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
                </div>
              </div>
            </div>
            <div id="row-dt-1-name-1-1" data-rownumber="1-0-1" data-rowlevel="2" role="row" class="chi-data-table__row-grand-child -md">
              <div role="cell" class="chi-data-table__cell -expandable"></div>
              <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
                <div class="-w--100">
                  <div class="-text--truncate">Child Name 2</div>
                </div>
              </div>
              <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
                <div class="-w--100">
                  <div class="-text--truncate">child-name-2</div>
                </div>
              </div>
              <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
                <div class="-w--100">
                  <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
                </div>
              </div>
            </div>
          </div>
          <div id="row-dt-1-name-2-1" data-rownumber="1-1" data-rowlevel="1" role="row" class="chi-data-table__row-child -md -collapsed">
            <div class="chi-data-table__cell -expandable"></div>
            <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
              <button aria-label="Expand row" data-target="#row-dt-1-name-2-1-content" class="chi-button -icon -flat -expand -xs">
                <div class="chi-button__content">
                  <i class="chi-icon icon-plus"></i>
                </div>
                <span class="-sr--only">Expand Row</span>
              </button>
              <div class="-w--100">
                <div class="-text--truncate">Child Name 2</div>
              </div>
            </div>
            <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
              <div class="-w--100">
                <div class="-text--truncate">child-name-2</div>
              </div>
            </div>
            <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
              <div class="-w--100">
                <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
              </div>
            </div>
          </div>
          <div id="row-dt-1-name-2-1-content" style="display: none;">
            <div id="row-dt-1-name-1-0" data-rownumber="1-1-0" data-rowlevel="2" role="row" class="chi-data-table__row-grand-child -md">
              <div role="cell" class="chi-data-table__cell -expandable"></div>
              <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
                <div class="-w--100">
                  <div class="-text--truncate">Child Name 1</div>
                </div>
              </div>
              <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
                <div class="-w--100">
                  <div class="-text--truncate">child-name-1</div>
                </div>
              </div>
              <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
                <div class="-w--100">
                  <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
                </div>
              </div>
            </div>
            <div id="row-dt-1-name-1-1" data-rownumber="1-1-1" data-rowlevel="2" role="row" class="chi-data-table__row-grand-child -md">
              <div role="cell" class="chi-data-table__cell -expandable"></div>
              <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
                <div class="-w--100">
                  <div class="-text--truncate">Child Name 2</div>
                </div>
              </div>
              <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
                <div class="-w--100">
                  <div class="-text--truncate">child-name-2</div>
                </div>
              </div>
              <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
                <div class="-w--100">
                  <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div id="row-dt-1-name-3" data-rownumber="2" data-rowlevel="0" role="row" class="chi-data-table__row -md -collapsed">
          <div role="cell" class="chi-data-table__cell -expandable">
            <button aria-label="Expand row" data-target="#row-dt-1-name-3-content" class="chi-button -icon -flat -expand -xs">
              <div class="chi-button__content">
                <i class="chi-icon icon-plus"></i>
              </div>
              <span class="-sr--only">Expand Row</span>
            </button>
          </div>
          <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
            <div class="-w--100">
              <div class="-text--truncate">Name 3</div>
            </div>
          </div>
          <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
            <div class="-w--100">
              <div class="-text--truncate">name-3</div>
            </div>
          </div>
          <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
            <div class="-w--100">
              <div class="-text--truncate">5 Nov 2020 10:15 a.m.</div>
            </div>
          </div>
        </div>
        <div id="row-dt-1-name-3-content" style="display: none;">
          <div id="row-dt-1-name-3-0" data-rownumber="2-0" data-rowlevel="1" role="row" class="chi-data-table__row-child -md -collapsed">
            <div class="chi-data-table__cell -expandable"></div>
            <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
              <button aria-label="Expand row" data-target="#row-dt-1-name-3-0-content" class="chi-button -icon -flat -expand -xs">
                <div class="chi-button__content">
                  <i class="chi-icon icon-plus"></i>
                </div>
                <span class="-sr--only">Expand Row</span>
              </button>
              <div class="-w--100">
                <div class="-text--truncate">Child Name 1</div>
              </div>
            </div>
            <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
              <div class="-w--100">
                <div class="-text--truncate">child-name-1</div>
              </div>
            </div>
            <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
              <div class="-w--100">
                <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
              </div>
            </div>
          </div>
          <div id="row-dt-1-name-3-0-content" style="display: none;">
            <div id="row-dt-1-name-1-0" data-rownumber="2-0-0" data-rowlevel="2" role="row" class="chi-data-table__row-grand-child -md">
              <div role="cell" class="chi-data-table__cell -expandable"></div>
              <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
                <div class="-w--100">
                  <div class="-text--truncate">Child Name 1</div>
                </div>
              </div>
              <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
                <div class="-w--100">
                  <div class="-text--truncate">child-name-1</div>
                </div>
              </div>
              <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
                <div class="-w--100">
                  <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
                </div>
              </div>
            </div>
            <div id="row-dt-1-name-1-1" data-rownumber="2-0-1" data-rowlevel="2" role="row" class="chi-data-table__row-grand-child -md">
              <div role="cell" class="chi-data-table__cell -expandable"></div>
              <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
                <div class="-w--100">
                  <div class="-text--truncate">Child Name 2</div>
                </div>
              </div>
              <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
                <div class="-w--100">
                  <div class="-text--truncate">child-name-2</div>
                </div>
              </div>
              <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
                <div class="-w--100">
                  <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
                </div>
              </div>
            </div>
          </div>
          <div id="row-dt-1-name-3-1" data-rownumber="2-1" data-rowlevel="1" role="row" class="chi-data-table__row-child -md -collapsed">
            <div class="chi-data-table__cell -expandable"></div>
            <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
              <button aria-label="Expand row" data-target="#row-dt-1-name-3-1-content" class="chi-button -icon -flat -expand -xs">
                <div class="chi-button__content">
                  <i class="chi-icon icon-plus"></i>
                </div>
                <span class="-sr--only">Expand Row</span>
              </button>
              <div class="-w--100">
                <div class="-text--truncate">Child Name 2</div>
              </div>
            </div>
            <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
              <div class="-w--100">
                <div class="-text--truncate">child-name-2</div>
              </div>
            </div>
            <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
              <div class="-w--100">
                <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
              </div>
            </div>
          </div>
          <div id="row-dt-1-name-3-1-content" style="display: none;">
            <div id="row-dt-1-name-1-0" data-rownumber="2-1-0" data-rowlevel="2" role="row" class="chi-data-table__row-grand-child -md">
              <div role="cell" class="chi-data-table__cell -expandable"></div>
              <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
                <div class="-w--100">
                  <div class="-text--truncate">Child Name 1</div>
                </div>
              </div>
              <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
                <div class="-w--100">
                  <div class="-text--truncate">child-name-1</div>
                </div>
              </div>
              <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
                <div class="-w--100">
                  <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
                </div>
              </div>
            </div>
            <div id="row-dt-1-name-1-1" data-rownumber="2-1-1" data-rowlevel="2" role="row" class="chi-data-table__row-grand-child -md">
              <div role="cell" class="chi-data-table__cell -expandable"></div>
              <div aria-label="Name" data-label="Name" role="cell" class="chi-data-table__cell -key -bold">
                <div class="-w--100">
                  <div class="-text--truncate">Child Name 2</div>
                </div>
              </div>
              <div aria-label="ID" data-label="ID" role="cell" class="chi-data-table__cell -key">
                <div class="-w--100">
                  <div class="-text--truncate">child-name-2</div>
                </div>
              </div>
              <div aria-label="Last Login" data-label="Last Login" role="cell" class="chi-data-table__cell">
                <div class="-w--100">
                  <div class="-text--truncate">18 Dec 2020 2:38 a.m.</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="chi-data-table__footer">
        <nav class="chi-pagination -compact" role="navigation" aria-label="Pagination">
          <div class="chi-pagination__content">
            <div class="chi-pagination__start">
              <div class="chi-pagination__results">
                <span class="chi-pagination__label">6 Results</span>
              </div>
            </div>
            <div class="chi-pagination__center">
              <div class="chi-pagination__button-group chi-button-group">
                <button class="chi-button -icon -flat -xs" aria-label="First page" disabled>
                  <div class="chi-button__content">
                    <i class="chi-icon icon-page-first" aria-hidden="true"></i>
                  </div>
                </button>
                <button class="chi-button -icon -flat -xs" aria-label="Previous page" disabled>
                  <div class="chi-button__content">
                    <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
                  </div>
                </button>
              </div>
              <div class="chi-pagination__label">
                <strong>1</strong>
                <span>of</span>
                <strong>2</strong>
              </div>
              <div class="chi-pagination__button-group chi-button-group">
                <button class="chi-button -icon -flat -xs" aria-label="Next page">
                  <div class="chi-button__content">
                    <i class="chi-icon icon-chevron-right" aria-hidden="true"></i>
                  </div>
                </button>
                <button class="chi-button -icon -flat -xs" aria-label="Last page">
                  <div class="chi-button__content">
                    <i class="chi-icon icon-page-last" aria-hidden="true"></i>
                  </div>
                </button>
              </div>
            </div>
            <div class="chi-pagination__end"></div>
          </div>
        </nav>
      </div>
    </div>
  </div>
</div>`,Y=(c,s,o)=>`<!-- Vue component -->
<ChiDataTable :config="config" :dataTableData="table"></ChiDataTable>

<!-- Config and Data -->
data: {
  ${c}
  table: {
    ${s}
    ${o}
  }
}`,Va=Y(Ra,B,ha),ja=Y(ta,B,ha),Ua=Y(ta,Ia,Sa),Fa=Y(ta,ia,za),Wa=C({__name:"_accordion",setup(c){const s=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint"}],o={...w,showExpandAll:!0},h={head:N,body:_a},v={vue:Va,htmlblueprint:Ba};return(n,r)=>{const i=f("ChiDataTable"),d=$,t=L;return g(),k(t,{title:"Accordion",id:"accordion-data-table",tabs:s},{example:l(()=>[e(i,{config:o,dataTableData:h})]),"code-vue":l(()=>[r[0]||(r[0]=a("div",{class:"chi-tab__description"},[p("Use "),a("code",null,"nestedContent"),p(" property to provide data for the accordion content.")],-1)),e(d,{lang:"html",code:v.vue},null,8,["code"])]),"code-htmlblueprint":l(()=>[e(d,{lang:"html",code:v.htmlblueprint},null,8,["code"])]),_:1})}}}),Ja=C({__name:"_active",setup(c){const s=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint"}],o=w,h=R.map(i=>i.id==="name-2"?{...i,active:!0}:i),v={head:N,body:h},r={vue:O(X(),B,A(!0)),htmlblueprint:ba(!0)};return(i,d)=>{const t=f("ChiDataTable"),_=$,b=L;return g(),k(b,{title:"Active",id:"active-data-table",tabs:s},{example:l(()=>[e(t,{config:P(o),dataTableData:v},null,8,["config"])]),"code-vue":l(()=>[d[0]||(d[0]=a("div",{class:"chi-tab__description"},[p("Use "),a("code",null,"active"),p(" property to achieve active state of rows")],-1)),e(_,{lang:"html",code:r.vue},null,8,["code"])]),"code-htmlblueprint":l(()=>[e(_,{lang:"html",code:r.htmlblueprint},null,8,["code"])]),_:1})}}}),Ga=C({__name:"_base",setup(c){const s=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint"}],o=w,h={head:N,body:R},n={vue:O(X(),B,A()),htmlblueprint:ba(!1)};return(r,i)=>{const d=f("ChiDataTable"),t=$,_=L;return g(),k(_,{title:"Base",id:"base-data-table",tabs:s},{example:l(()=>[e(d,{config:P(o),dataTableData:h},null,8,["config"])]),"code-vue":l(()=>[e(t,{code:n.vue,lang:"html"},null,8,["code"])]),"code-htmlblueprint":l(()=>[e(t,{lang:"html",code:n.htmlblueprint},null,8,["code"])]),_:1})}}}),Oa=["innerHTML"],qa=C({__name:"_empty",setup(c){const s=[{title:"No Results",id:"no-results-data-table",description:"Use <code>noResultsMessage</code> config to customize the no results data message",config:{noResultsMessage:"No matching results"}},{title:"No Filters",id:"no-filters-data-table",description:"Use <code>noFiltersMessage</code> config to customize the no filters data message.",config:{noFiltersMessage:"Search for or select at least one filter to get results"}},{title:"Empty Actionable",id:"empty-actionable-data-table",description:null,config:{emptyActionable:{isActionable:!0}}}],o=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint"}],h=w,v={head:N,body:[]},n=t=>({...h,...t.noFiltersMessage?{noResultsMessage:t.noFiltersMessage}:t}),r=t=>t.emptyActionable?`<div>
        <i class="chi-icon icon-circle-plus-outline -icon--grey -lg" aria-hidden="true"></i>
        <span>
          <a>Add a new or existing service</a>, then manage here.
        </span>
      </div>`:`<i class="-mr--1 chi-icon icon-search"></i>
      <div>${t.noFiltersMessage||t.noResultsMessage}</div>`,i=t=>`<!-- Vue component -->
<ChiDataTable :config="config" :dataTableData="table"></ChiDataTable>

<!-- Config and Data -->
data: {
  config: {
    columnResize: true,${t.noFiltersMessage?`
    noFiltersMessage: '${t.noFiltersMessage}',`:""}${t.noResultsMessage?`
    noResultsMessage: '${t.noResultsMessage}',`:""}
    style: {
      portal: false,
      noBorder: false,
      bordered: false,
      hover: false,
      size: 'md',
      striped: false,
    },
    pagination: {
      activePage: 1,
      compact: false,
      firstLast: false,
      pageJumper: true,
    },${t.emptyActionable?`
    emptyActionable: {
      isActionable: true,
    },`:""}
    resultsPerPage: 3,
  },
  table: {
    ${B}
    body: []
  }
}`,d=t=>`<div class="chi-data-table">
  <div class="chi-data-table__head">
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell">
        <div>Name</div>
      </div>
      <div class="chi-data-table__cell">
        <div>ID</div>
      </div>
      <div class="chi-data-table__cell">
        <div>Last Login</div>
      </div>
    </div>
  </div>
  <div class="chi-data-table__body">
    <div class="chi-data-table__row-empty${t.emptyActionable?" -actionable":""}">
      ${r(t)}
    </div>
  </div>
</div>`;return(t,_)=>{const b=ca,m=f("ChiDataTable"),u=$,y=L;return g(),I(E,null,[e(b,{title:"Empty",id:"empty-data-table"}),(g(),I(E,null,U(s,D=>e(y,{title:D.title,titleSize:"h4",id:D.id,key:D.id,tabs:o},{example:l(()=>[e(m,{config:n(D.config),dataTableData:v},null,8,["config"])]),"code-htmlblueprint":l(()=>[e(u,{lang:"html",code:d(D.config)},null,8,["code"])]),"code-vue":l(()=>[D.description?(g(),I("div",{key:0,class:"chi-tab__description",innerHTML:D.description},null,8,Oa)):q("",!0),e(u,{lang:"html",code:i(D.config)},null,8,["code"])]),_:2},1032,["title","id"])),64))],64)}}}),Ka=["innerHTML"],Qa=C({__name:"_config-styled",setup(c){const s=[{title:"No Border",id:"no-border-data-table",description:"Use <code>noBorder</code> config to remove the borders",style:{noBorder:!0}},{title:"Striped",id:"striped-data-table",description:"Use <code>striped</code> config to achieve striped styles",style:{striped:!0}},{title:"Hover",id:"hover-data-table",description:"Use <code>hover</code> config to achieve hover styles",style:{hover:!0}},{title:"Bordered",id:"bordered-data-table",description:"Use <code>bordered</code> config to achieve bordered styles",style:{bordered:!0}}],o=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint"}],h=w,v={head:N,body:R},n=d=>({...h,style:{...h.style,...d}}),r=d=>`<!-- Vue component -->
<ChiDataTable :config="config" :dataTableData="table"></ChiDataTable>

<!-- Config and Data -->
data: {
  config: {
    columnResize: true,
    style: {
      portal: false,
      noBorder: ${!!d.noBorder},
      bordered: ${!!d.bordered},
      hover: ${!!d.hover},
      size: 'md',
      striped: ${!!d.striped},
    },
    pagination: {
      activePage: 1,
      compact: false,
      firstLast: false,
      pageJumper: true,
    },
    resultsPerPage: 3,
  },
  table: {
    ${B}
    ${A()}
  }
}`,i=d=>`<div class="chi-data-table${d.noBorder?" -no-border":""}${d.bordered?" -bordered":""}${d.hover?" -hover":""}">
  <div class="chi-data-table__head">
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell">
        <div>Name</div>
      </div>
      <div class="chi-data-table__cell">
        <div>ID</div>
      </div>
      <div class="chi-data-table__cell">
        <div>Last Login</div>
      </div>
    </div>
  </div>
  <div class="chi-data-table__body">
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell" data-label="Name">
        <div>Name 1</div>
      </div>
      <div class="chi-data-table__cell" data-label="ID">
        <div>name-1</div>
      </div>
      <div class="chi-data-table__cell" data-label="Last Login">
        <div>18 Dec 2020 3:26 p.m.</div>
      </div>
    </div>
    <div class="chi-data-table__row${d.striped?" -striped":""}">
      <div class="chi-data-table__cell" data-label="Name">
        <div>Name 2</div>
      </div>
      <div class="chi-data-table__cell" data-label="ID">
        <div>name-2</div>
      </div>
      <div class="chi-data-table__cell" data-label="Last Login">
        <div>18 Dec 2020 2:38 a.m.</div>
      </div>
    </div>
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell" data-label="Name">
        <div>Name 3</div>
      </div>
      <div class="chi-data-table__cell" data-label="ID">
        <div>name-3</div>
      </div>
      <div class="chi-data-table__cell" data-label="Last Login">
        <div>5 Nov 2020 10:15 a.m.</div>
      </div>
    </div>
  </div>
  <div class="chi-data-table__footer">
    <nav class="chi-pagination" role="navigation" aria-label="Pagination">
      <div class="chi-pagination__content">
        <div class="chi-pagination__start">
          <div class="chi-pagination__results">
            <span class="chi-pagination__label">6 results</span>
          </div>
          <div class="chi-pagination__page-size">
            <div class="chi-dropdown">
              <button class="chi-button -flat -px--1 chi-dropdown__trigger" id="pagesize-2">20</button>
              <div class="chi-dropdown__menu -w--xs">
                <a class="chi-dropdown__menu-item -active" href="#">20</a>
                <a class="chi-dropdown__menu-item" href="#">40</a>
                <a class="chi-dropdown__menu-item" href="#">60</a>
                <a class="chi-dropdown__menu-item" href="#">80</a>
                <a class="chi-dropdown__menu-item" href="#">All</a>
              </div>
            </div>
            <span class="chi-pagination__label">per page</span>
          </div>
        </div>
        <div class="chi-pagination__center">
          <div class="chi-pagination__button-group chi-button-group">
            <button class="chi-button -icon -flat" aria-label="Previous page">
              <div class="chi-button__content">
                <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
              </div>
            </button>
            <button class="chi-button -flat -active" aria-label="Page 1">1</button>
            <button class="chi-button -flat" aria-label="Page 2">2</button>
            <button class="chi-button -icon -flat" aria-label="Next page">
              <div class="chi-button__content">
                <i class="chi-icon icon-chevron-right" aria-hidden="true"></i>
              </div>
            </button>
          </div>
        </div>
        <div class="chi-pagination__end">
          <div class="chi-pagination__jumper">
            <label class="chi-pagination__label" for="jumper-input-2">Go to page:</label>
            <input class="chi-input" type="text" id="jumper-input-2" />
          </div>
        </div>
      </div>
    </nav>
  </div>
</div>`;return(d,t)=>{const _=f("ChiDataTable"),b=$,m=L;return g(),I(E,null,U(s,u=>e(m,{title:u.title,key:u.id,id:u.id,tabs:o},{example:l(()=>[(g(),k(_,{config:n(u.style),key:u.id,dataTableData:v},null,8,["config"]))]),"code-vue":l(()=>[a("div",{class:"chi-tab__description",innerHTML:u.description},null,8,Ka),e(b,{lang:"html",code:r(u.style)},null,8,["code"])]),"code-htmlblueprint":l(()=>[e(b,{lang:"html",code:i(u.style)},null,8,["code"])]),_:2},1032,["title","id"])),64)}}}),Xa=C({__name:"_selectable",setup(c){const s=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint"}],o={...w,selectable:!0,showSelectAllDropdown:!0},h={head:N,body:R},v={htmlblueprintRadio:`<div class="chi-data-table">
  <div class="chi-data-table__head">
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell -selectable"></div>
      <div class="chi-data-table__cell">
        <div>Name</div>
      </div>
      <div class="chi-data-table__cell">
        <div>ID</div>
      </div>
      <div class="chi-data-table__cell">
        <div>Last Login</div>
      </div>
    </div>
  </div>
  <div class="chi-data-table__body">
    <fieldset>
      <div class="chi-data-table__row">
        <div class="chi-data-table__cell -selectable">
          <div class="chi-radio">
            <input type="radio" class="chi-radio__input" id="radio-ba2" name="radios">
            <label class="chi-radio__label" for="radio-ba2"></label>
          </div>
        </div>
        <div class=" chi-data-table__cell" data-label="Name">
          <div>Name 1</div>
        </div>
        <div class="chi-data-table__cell" data-label="ID">
          <div>name-1</div>
        </div>
        <div class="chi-data-table__cell" data-label="Last Login">
          <div>18 Dec 2020 3:26 p.m.</div>
        </div>
      </div>
      <div class="chi-data-table__row -selected">
        <div class="chi-data-table__cell -lh--1 -selectable">
          <div class="chi-radio">
            <input type="radio" class="chi-radio__input" id="radio-ba3" name="radios">
            <label class="chi-radio__label" for="radio-ba3"></label>
          </div>
        </div>
        <div class=" chi-data-table__cell" data-label="Name">
          <div>Name 2</div>
        </div>
        <div class="chi-data-table__cell" data-label="ID">
          <div>name-2</div>
        </div>
        <div class="chi-data-table__cell" data-label="Last Login">
          <div>18 Dec 2020 2:38 a.m.</div>
        </div>
      </div>
      <div class="chi-data-table__row">
        <legend class="-sr--only">Select a Row</legend>
        <div class="chi-data-table__cell -lh--1 -selectable">
          <div class="chi-radio">
            <input type="radio" class="chi-radio__input" id="radio-ba4" name="radios">
            <label class="chi-radio__label" for="radio-ba4"></label>
          </div>
        </div>
        <div class=" chi-data-table__cell" data-label="Name">
          <div>Name 3</div>
        </div>
        <div class="chi-data-table__cell" data-label="ID">
          <div>name-3</div>
        </div>
        <div class="chi-data-table__cell" data-label="Last Login">
          <div>5 Nov 2020 10:15 a.m.</div>
        </div>
      </div>
    </fieldset>
  </div>
  <div class="chi-data-table__footer">
    <nav class="chi-pagination" role="navigation" aria-label="Pagination">
      <div class="chi-pagination__content">
        <div class="chi-pagination__start">
          <div class="chi-pagination__results">
            <span class="chi-pagination__label">6 results</span>
          </div>
          <div class="chi-pagination__page-size">
            <div class="chi-dropdown">
              <button class="chi-button -flat -px--1 chi-dropdown__trigger" id="pagesize-7">20</button>
              <div class="chi-dropdown__menu -w--xs">
                <a class="chi-dropdown__menu-item -active" href="#">20</a>
                <a class="chi-dropdown__menu-item" href="#">40</a>
                <a class="chi-dropdown__menu-item" href="#">60</a>
                <a class="chi-dropdown__menu-item" href="#">80</a>
                <a class="chi-dropdown__menu-item" href="#">All</a>
              </div>
            </div>
            <span class="chi-pagination__label">per page</span>
          </div>
        </div>
        <div class="chi-pagination__center">
          <div class="chi-pagination__button-group chi-button-group">
            <button class="chi-button -icon -flat" aria-label="Previous page">
              <div class="chi-button__content">
                <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
              </div>
            </button>
            <button class="chi-button -flat -active" aria-label="Page 1">1</button>
            <button class="chi-button -flat" aria-label="Page 2">2</button>
            <button class="chi-button -icon -flat" aria-label="Next page">
              <div class="chi-button__content">
                <i class="chi-icon icon-chevron-right" aria-hidden="true"></i>
              </div>
            </button>
          </div>
        </div>
        <div class="chi-pagination__end">
          <div class="chi-pagination__jumper">
            <label class="chi-pagination__label" for="jumper-input-7">Go to page:</label>
            <input class="chi-input" type="text" id="jumper-input-7" />
          </div>
        </div>
      </div>
    </nav>
  </div>
</div>`,htmlblueprintCheckbox:ka},n=()=>({...o,selectable:"radio"}),r=i=>`<!-- Vue component -->
<ChiDataTable :config="config" :dataTableData="table"></ChiDataTable>

<!-- Config and Data -->
data: {
  config: {
    columnResize: true,
    style: {
      portal: false,
      noBorder: false,
      bordered: false,
      hover: false,
      size: 'md',
      striped: false,
    },
    pagination: {
      activePage: 1,
      compact: false,
      firstLast: false,
      pageJumper: true,
    },
    selectable: ${i==="radio"?"'radio'":`${i},
    showSelectAllDropdown: true`},
    resultsPerPage: 3,
  },
  table: {
    ${B}
    ${A()}
  }
}`;return(i,d)=>{const t=f("ChiDataTable"),_=$,b=L;return g(),I(E,null,[e(b,{title:"Selectable",id:"selectable-data-table",tabs:s},{example:l(()=>[e(t,{config:o,dataTableData:h})]),"code-vue":l(()=>[d[0]||(d[0]=a("div",{class:"chi-tab__description"},[p("Use "),a("code",null,"selectable"),p(" config to render rows with selectable checkboxes")],-1)),e(_,{lang:"html",code:r(!0)},null,8,["code"])]),"code-htmlblueprint":l(()=>[e(_,{lang:"html",code:v.htmlblueprintCheckbox},null,8,["code"])]),_:1}),e(b,{title:"Radio Selection",id:"radio-selection-data-table",tabs:s},{example:l(()=>[e(t,{config:n(),dataTableData:h},null,8,["config"])]),"code-vue":l(()=>[d[1]||(d[1]=a("div",{class:"chi-tab__description"},[p("Use "),a("code",null,"selectable"),p(" config to render rows with radio buttons")],-1)),e(_,{lang:"html",code:r("radio")},null,8,["code"])]),"code-htmlblueprint":l(()=>[e(_,{lang:"html",code:v.htmlblueprintRadio},null,8,["code"])]),_:1})],64)}}}),Ya=C({__name:"_sizes",setup(c){const s=["xs","sm","md","lg","xl"],o=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint"}],h={...w,style:{...w.style,size:"lg"}},v={head:N,body:R},n=d=>({...h,style:{...h.style,size:d}}),r=d=>`<!-- Vue component -->
<ChiDataTable :config="config" :dataTableData="table"></ChiDataTable>

<!-- Config and Data -->
data: {
  config: {
    columnResize: true,
    style: {
      portal: false,
      noBorder: false,
      bordered: false,
      hover: false,
      size: '${d}',
      striped: false,
    },
    pagination: {
      activePage: 1,
      compact: false,
      firstLast: false,
      pageJumper: true,
    },
    resultsPerPage: 3,
  },
  table: {
    ${B}
    ${A()}
  }
}`,i=d=>`<div class="chi-data-table -${d}">
  <div class="chi-data-table__head">
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell">
        <div>Name</div>
      </div>
      <div class="chi-data-table__cell">
        <div>ID</div>
      </div>
      <div class="chi-data-table__cell">
        <div>Last Login</div>
      </div>
    </div>
  </div>
  <div class="chi-data-table__body">
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell" data-label="Name">
        <div>Name 1</div>
      </div>
      <div class="chi-data-table__cell" data-label="ID">
        <div>name-1</div>
      </div>
      <div class="chi-data-table__cell" data-label="Last Login">
        <div>18 Dec 2020 3:26 p.m.</div>
      </div>
    </div>
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell" data-label="Name">
        <div>Name 2</div>
      </div>
      <div class="chi-data-table__cell" data-label="ID">
        <div>name-2</div>
      </div>
      <div class="chi-data-table__cell" data-label="Last Login">
        <div>18 Dec 2020 2:38 a.m.</div>
      </div>
    </div>
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell" data-label="Name">
        <div>Name 3</div>
      </div>
      <div class="chi-data-table__cell" data-label="ID">
        <div>name-3</div>
      </div>
      <div class="chi-data-table__cell" data-label="Last Login">
        <div>5 Nov 2020 10:15 a.m.</div>
      </div>
    </div>
  </div>
  <div class="chi-data-table__footer">
    <nav class="chi-pagination" role="navigation" aria-label="Pagination">
      <div class="chi-pagination__content">
        <div class="chi-pagination__start">
          <div class="chi-pagination__results">
            <span class="chi-pagination__label">6 results</span>
          </div>
          <div class="chi-pagination__page-size">
            <div class="chi-dropdown">
              <button class="chi-button -flat -px--1 chi-dropdown__trigger" id="pagesize-16">20</button>
              <div class="chi-dropdown__menu -w--xs">
                <a class="chi-dropdown__menu-item -active" href="#">20</a>
                <a class="chi-dropdown__menu-item" href="#">40</a>
                <a class="chi-dropdown__menu-item" href="#">60</a>
                <a class="chi-dropdown__menu-item" href="#">80</a>
                <a class="chi-dropdown__menu-item" href="#">All</a>
              </div>
            </div>
            <span class="chi-pagination__label">per page</span>
          </div>
        </div>
        <div class="chi-pagination__center">
          <div class="chi-pagination__button-group chi-button-group">
            <button class="chi-button -icon -flat" aria-label="Previous page">
              <div class="chi-button__content">
                <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
              </div>
            </button>
            <button class="chi-button -flat -active" aria-label="Page 1">1</button>
            <button class="chi-button -flat" aria-label="Page 2">2</button>
            <button class="chi-button -icon -flat" aria-label="Next page">
              <div class="chi-button__content">
                <i class="chi-icon icon-chevron-right" aria-hidden="true"></i>
              </div>
            </button>
          </div>
        </div>
        <div class="chi-pagination__end">
          <div class="chi-pagination__jumper">
            <label class="chi-pagination__label" for="jumper-input-16">Go to page:</label>
            <input class="chi-input" type="text" id="jumper-input-16" />
          </div>
        </div>
      </div>
    </nav>
  </div>
</div>`;return(d,t)=>{const _=f("ChiDataTable"),b=$,m=L;return g(),I(E,null,U(s,u=>e(m,{key:u,title:`Size -${u}`,id:`size-${u}-data-table`,tabs:o},{example:l(()=>[e(_,{config:n(u),dataTableData:v},null,8,["config"])]),"code-vue":l(()=>[e(b,{lang:"html",code:r(u)},null,8,["code"])]),"code-htmlblueprint":l(()=>[e(b,{code:i(u),lang:"html"},null,8,["code"])]),_:2},1032,["title","id"])),64)}}}),Za=C({__name:"_sorting",setup(c){const s=[{title:"Sorting",id:"sorting-data-table",defaultSort:null},{title:"Default Sorting -- Ascending",id:"sorting-ascending-data-table",defaultSort:{key:"name",direction:"ascending"}},{title:"Default Sorting -- Descending",id:"sorting-descending-data-table",defaultSort:{key:"name",direction:"descending"}}],o=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint"}],h=w,v={head:{name:{label:"Name",sortable:!0,sortDataType:"string"},id:{label:"ID",sortable:!0,sortDataType:"string"},lastLogin:{label:"Last Login",sortable:!0,sortDatatype:"date"}},body:R},n=d=>({...h,...d?{defaultSort:d}:{}}),r=d=>`<div class="chi-data-table">
  <div class="chi-data-table__head">
    <div class="chi-data-table__row">
      <button class="chi-data-table__cell -sorting${d?" -active":""}${d?.direction==="descending"?" -descending":""}">
        <div class="-mr--1">Name</div>
        <i class="chi-icon -xs ${d?"icon-arrow-up":"icon-arrow-sort"}" aria-hidden="true"></i>
      </button>
      <button class="chi-data-table__cell -sorting">
        <div class="-mr--1">ID</div>
        <i class="chi-icon -xs icon-arrow-sort" aria-hidden="true"></i>
      </button>
      <button class="chi-data-table__cell -sorting">
        <div class="-mr--1">Last Login</div>
        <i class="chi-icon -xs icon-arrow-sort" aria-hidden="true"></i>
      </button>
    </div>
  </div>
  <div class="chi-data-table__body">
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell" data-label="Name">
        <div>Name 1</div>
      </div>
      <div class="chi-data-table__cell" data-label="ID">
        <div>name-1</div>
      </div>
      <div class="chi-data-table__cell" data-label="Last Login">
        <div>18 Dec 2020 3:26 p.m.</div>
      </div>
    </div>
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell" data-label="Name">
        <div>Name 2</div>
      </div>
      <div class="chi-data-table__cell" data-label="ID">
        <div>name-2</div>
      </div>
      <div class="chi-data-table__cell" data-label="Last Login">
        <div>18 Dec 2020 2:38 a.m.</div>
      </div>
    </div>
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell" data-label="Name">
        <div>Name 3</div>
      </div>
      <div class="chi-data-table__cell" data-label="ID">
        <div>name-3</div>
      </div>
      <div class="chi-data-table__cell" data-label="Last Login">
        <div>5 Nov 2020 10:15 a.m.</div>
      </div>
    </div>
  </div>
  <div class="chi-data-table__footer">
    <nav class="chi-pagination" role="navigation" aria-label="Pagination">
      <div class="chi-pagination__content">
        <div class="chi-pagination__start">
          <div class="chi-pagination__results">
            <span class="chi-pagination__label">6 results</span>
          </div>
          <div class="chi-pagination__page-size">
            <div class="chi-dropdown">
              <button class="chi-button -flat -px--1 chi-dropdown__trigger" id="pagesize-10">20</button>
              <div class="chi-dropdown__menu -w--xs">
                <a class="chi-dropdown__menu-item -active" href="#">20</a>
                <a class="chi-dropdown__menu-item" href="#">40</a>
                <a class="chi-dropdown__menu-item" href="#">60</a>
                <a class="chi-dropdown__menu-item" href="#">80</a>
                <a class="chi-dropdown__menu-item" href="#">All</a>
              </div>
            </div>
            <span class="chi-pagination__label">per page</span>
          </div>
        </div>
        <div class="chi-pagination__center">
          <div class="chi-pagination__button-group chi-button-group">
            <button class="chi-button -icon -flat" aria-label="Previous page">
              <div class="chi-button__content">
                <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
              </div>
            </button>
            <button class="chi-button -flat -active" aria-label="Page 1">1</button>
            <button class="chi-button -flat" aria-label="Page 2">2</button>
            <button class="chi-button -icon -flat" aria-label="Next page">
              <div class="chi-button__content">
                <i class="chi-icon icon-chevron-right" aria-hidden="true"></i>
              </div>
            </button>
          </div>
        </div>
        <div class="chi-pagination__end">
          <div class="chi-pagination__jumper">
            <label class="chi-pagination__label" for="jumper-input-10">Go to page:</label>
            <input class="chi-input" type="text" id="jumper-input-10" />
          </div>
        </div>
      </div>
    </nav>
  </div>
</div>`,i=d=>`<!-- Vue component -->
<ChiDataTable :config="config" :dataTableData="table"></ChiDataTable>

<!-- Config and Data -->
data: {
  config: {
    columnResize: true,
    style: {
      portal: false,
      noBorder: false,
      bordered: false,
      hover: false,
      size: 'md',
      striped: false,
    },${d?`
    defaultSort: {
      key: 'name',
      direction: '${d.direction}',
    },`:""}
    pagination: {
      activePage: 1,
      compact: false,
      firstLast: false,
      pageJumper: true,
    },
    resultsPerPage: 3,
  },
  table: {
    ${xa}
    ${A()}
  }
}`;return(d,t)=>{const _=f("ChiDataTable"),b=$,m=L;return g(),I(E,null,U(s,u=>e(m,{key:u.id,title:u.title,id:u.id,tabs:o},{example:l(()=>[e(_,{config:n(u.defaultSort),dataTableData:v},null,8,["config"])]),"code-vue":l(()=>[t[0]||(t[0]=a("div",{class:"chi-tab__description"},[p("Use "),a("code",null,"sortBy"),p(" and "),a("code",null,"sortDataType"),p(" properties to make the column sortable")],-1)),e(b,{code:i(u.defaultSort),lang:"html"},null,8,["code"])]),"code-htmlblueprint":l(()=>[e(b,{code:r(u.defaultSort),lang:"html"},null,8,["code"])]),_:2},1032,["title","id"])),64)}}}),ae=["icon","color"],ee={class:"-text--truncate -pl--1"},ie=C({__name:"_complex",setup(c){const s=S(null),o=()=>{s.value?.print("Data table - Complex")},h=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint",disabled:!0}],v={...ea,style:{...ea.style,portal:!1},pagination:{...ea.pagination,pageJumper:!0}},n={head:ra,body:oa};return(r,i)=>{const d=f("ChiDataTableToolbar"),t=f("ChiDataTable"),_=L;return g(),k(_,{title:"Complex",id:"complex-data-table",tabs:h},{example:l(()=>[e(t,{config:v,dataTableData:n,ref_key:"dataTableComplex",ref:s},{status:l(b=>[a("chi-icon",{icon:b.icon,color:b.color,"aria-hidden":"true"},null,8,ae),a("span",ee,la(b.status),1)]),name:l(b=>[(g(),k(sa,{name:b.name,id:b.id,key:b.id},null,8,["name","id"]))]),toolbar:l(()=>[e(d,null,{end:l(()=>[a("chi-button",{onClick:o,variant:"flat",type:"icon","aria-label":"Print data table complex example"},[...i[0]||(i[0]=[a("chi-icon",{icon:"print"},null,-1)])])]),_:1})]),"bulk-actions":l(()=>[...i[1]||(i[1]=[a("div",{class:"chi-bulk-actions__buttons"},[a("div",{class:"chi-bulk-actions__buttons-mobile -z--40"},[a("chi-button",{variant:"flat",type:"icon","aria-label":"Edit"},[a("chi-icon",{icon:"edit"})]),a("chi-button",{variant:"flat",type:"icon","aria-label":"Compose"},[a("chi-icon",{icon:"compose"})]),a("chi-button",{variant:"flat",type:"icon","aria-label":"Delete"},[a("chi-icon",{icon:"delete"})]),a("chi-button",{variant:"flat",type:"icon","aria-label":"Print"},[a("chi-icon",{icon:"print"})])]),a("div",{class:"chi-bulk-actions__buttons-desktop"},[a("chi-button",{size:"xs","aria-label":"Download"},[a("chi-icon",{icon:"arrow-to-bottom"}),a("span",null,"Download")]),a("chi-button",{size:"xs","aria-label":"Compose"},[a("chi-icon",{icon:"arrow-to-bottom"}),a("span",null,"Compose")]),a("chi-button",{size:"xs","aria-label":"Delete"},[a("chi-icon",{icon:"arrow-to-bottom"}),a("span",null,"Delete")]),a("chi-button",{size:"xs","aria-label":"Print"},[a("chi-icon",{icon:"arrow-to-bottom"}),a("span",null,"Print")])])],-1)])]),_:1},512)]),"code-vue":l(()=>[e(na)]),_:1})}}}),H=[{id:"name-1",data:[{template:"productName",payload:{productName:"Name 1"}},"name-1",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"22/05/2023","30/6/2025"]},{id:"name-2",data:[{template:"productName",payload:{productName:"Name 2"}},"name-2",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"22/05/2023","30/6/2025"]},{id:"custom-column",data:[{template:"productName",payload:{productName:"Custom column"}},"special-id",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"22/05/2023","30/6/2025"]},{id:"name-4",data:[{template:"productName",payload:{productName:"Name 4"}},"name-4",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"22/05/2023","30/6/2025"]},{id:"name-5",data:[{template:"productName",payload:{productName:"Name 5"}},"name-5",{template:"status",payload:{status:"Due",icon:"warning",color:"warning"}},"22/05/2023","30/6/2025"]},{id:"name-6",data:[{template:"productName",payload:{productName:"Name 6"}},"name-6",{template:"status",payload:{status:"Overdue",icon:"circle-alert",color:"danger"}},"22/05/2023","30/6/2025"]}],J=[{name:"productName",label:"Product name",sortable:!0,sortBy:"productName",sortDataType:"string",searchBy:"productName",selected:!0},{name:"id",label:"ID",sortable:!0,sortBy:"id",sortDataType:"string",selected:!0},{name:"status",label:"Status",sortable:!0,sortBy:"status",searchBy:"status",selected:!0,sortDataType:"string"},{name:"startDate",label:"Start date",selected:!0},{name:"endDate",label:"End date",selected:!1}],ua={...w,columnResize:!1,cellWrap:!1,hideNonSelectedColumns:!0},te={...ua,style:{portal:!0,striped:!0},pagination:{compact:!0,firstLast:!0,pageJumper:!1}},le=JSON.stringify(H,null,2),de=JSON.stringify(J,null,2),pa=(c=!1)=>`<!-- Vue component -->
<ChiDataTable ref="dataTable" :config="config" :data-table-data="table">
  <template #toolbar>
    <ChiDataTableToolbar>
      <template #start>
        <ChiSearchInput ref="searchInput" @chi-input="handlerSearchInput" @chi-clean="handlerClean"></SearchInput>
      </template>
      <template #end>
        <ChiColumnCustomization :columns-data="tableColumns" @chi-columns-change="handlerColumnsChange" />
      </template>
    </DataTableToolbar>
  </template>
  <template #productName="payload">
    <chi-link>
      <span v-html="useHighlightText(payload.productName, searchValue)" />
    </chi-link>
  </template>
  <template #status="payload">
    <div class="-d--flex">
      <chi-icon class="-mr--1" :icon="payload.icon" :color="payload.color"/>
      <span v-html="useHighlightText(payload.status, searchValue)" />
    </div>
  </template>
</ChiDataTable>

<!-- imports -->
import { useDataTableHighlight, useDataTableSearch, useHighlightText } from '@centurylink/chi-vue'
import { DataTableColumn } from '@centurylink/chi-vue/dist/src/components/data-table/DataTable';

<!-- Config and Data -->
const body = ${le};

const head = ${de};

const table = ref({
  head,
  body,
});

const config = ref({
  columnResize: false,
  style: {
    portal: ${c?"true":"false"},
    noBorder: false,
    bordered: false,
    hover: false,
    size: 'md',
    striped: ${c?"true":"false"},
  },
  pagination: {
    activePage: 1,
    compact: ${c?"true":"false"},
    firstLast: ${c?"true":"false"},
    pageJumper: ${c?"false":"true"},
  },
  cellWrap: false,
  resultsPerPage: 3,
  hideNonSelectedColumns: true,
});

const tableColumns = ref({
  columns: head,
});

const searchValue = ref<string>('');
const dataTable = ref(null);
const searchInput = ref(null);

const handlerSearchInput = (search: string) => {
  searchValue.value = search;

  const filteredResults = useDataTableSearch(body, search, dataTable.value);
  const searchResults = useDataTableHighlight(filteredResults, search, dataTable.value);

  table.value = {
    ...table.value,
    body: searchResults,
  };
};

const handlerClean = () => {
  const searchResults = useDataTableHighlight(body, '', dataTable.value);

  table.value = {
    ...table.value,
    body: searchResults,
  };

  searchValue.value = '';
};

const handlerColumnsChange = (columns: DataTableColumn[]) => {
  const search = searchInput.value as any;
  const eventColumnNames = new Set(columns.map((column) => column.name));

  tableColumns.value.columns.forEach((column) => (column.selected = eventColumnNames.has(column.name)));

  table.value = {
    ...table.value,
    head: tableColumns.value.columns,
  };

  search._cleanInput();
};`,ce=["innerHTML"],se={class:"-d--flex"},ne=["icon","color"],oe=["innerHTML"],re=C({__name:"_highlight",setup(c){const s=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint",disabled:!0}],o=S(null),h=S(null),v=S(""),n=S({head:J,body:H}),r=S({columns:J}),i={vue:pa(),htmlblueprint:""},d=b=>{v.value=b;const m=da(H,b,o.value),u=Q(m,b,o.value);n.value={...n.value,body:u}},t=()=>{const b=Q(H,"",o.value);n.value={...n.value,body:b},v.value=""},_=b=>{const m=h.value,u=new Set(b.map(y=>y.name));r.value.columns.forEach(y=>y.selected=u.has(y.name)),n.value={...n.value,head:r.value.columns},m._cleanInput()};return(b,m)=>{const u=f("ChiSearchInput"),y=f("ChiColumnCustomization"),D=f("ChiDataTableToolbar"),Z=f("ChiDataTable"),F=$,aa=L;return g(),k(aa,{title:"Highlight",id:"highlight-data-table",tabs:s},{"example-description":l(()=>[...m[0]||(m[0]=[a("p",{class:"-text"},[p(" In order to see the highlight effect in hidden columns, please search for "),a("code",null,"30"),p(" in the search input. Use "),a("code",null,"Column Customization vue component"),p(" feature to manipulate the columns visibility to show/hide them.")],-1)])]),example:l(()=>[e(Z,{config:P(ua),dataTableData:n.value,ref_key:"dataTableHighlight",ref:o},{toolbar:l(()=>[e(D,null,{start:l(()=>[e(u,{ref_key:"searchInput",ref:h,onChiInput:d,onChiClean:t},null,512)]),end:l(()=>[e(y,{"columns-data":r.value,onChiColumnsChange:_},null,8,["columns-data"])]),_:1})]),productName:l(z=>[a("chi-link",null,[a("span",{innerHTML:P(K)(z.productName,v.value)},null,8,ce)])]),status:l(z=>[a("div",se,[a("chi-icon",{class:"-mr--1",icon:z.icon,color:z.color},null,8,ne),a("span",{innerHTML:P(K)(z.status,v.value)},null,8,oe)])]),_:1},8,["config","dataTableData"])]),"code-vue":l(()=>[m[1]||(m[1]=a("div",{class:"chi-tab__description"},[p("Use "),a("code",null,"hideNonSelectedColumns"),p(" in config to hide non-selected columns")],-1)),e(F,{lang:"html",code:i.vue},null,8,["code"])]),"code-htmlblueprint":l(()=>[e(F,{lang:"html",code:i.htmlblueprint},null,8,["code"])]),_:1})}}}),ve={class:"chi-card -portal -bg--white"},be={class:"chi-card__content -p--0"},he=C({__name:"_accordion",setup(c){const s=[{title:"Accordion",id:"accordion-portal-data-table",table:{head:N,body:_a},codeSnippetVue:ja,codeSnippetHtml:Aa},{title:"Accordion Child",id:"accordion-child-data-table",table:{head:{...N,name:{...N.name,key:!0,bold:!0}},body:Pa},codeSnippetVue:Ua,codeSnippetHtml:Ha},{title:"Accordion Grand Child",id:"accordion-grand-child-data-table",table:{head:{...N,name:{...N.name,key:!0,bold:!0}},body:Ea},codeSnippetVue:Fa,codeSnippetHtml:Ma}],o=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint"}],h={...w,style:{...w.style,portal:!0,striped:!0},pagination:{...w.pagination,compact:!0,firstLast:!0,pageJumper:!1},showExpandAll:!0};return(v,n)=>{const r=f("ChiDataTable"),i=$,d=L;return g(),I(E,null,U(s,t=>e(d,{title:t.title,id:t.id,tabs:o},{example:l(()=>[a("div",ve,[n[0]||(n[0]=a("div",{class:"chi-card__header -sm"},[a("div",{class:"chi-card__title"},"Title")],-1)),a("div",be,[e(r,{config:h,dataTableData:t.table},null,8,["dataTableData"])])])]),"code-vue":l(()=>[n[1]||(n[1]=a("div",{class:"chi-tab__description"},[p("Use "),a("code",null,"nestedContent"),p(" property to provide data of row accordion content")],-1)),e(i,{lang:"html",code:t.codeSnippetVue},null,8,["code"])]),"code-htmlblueprint":l(()=>[e(i,{lang:"html",code:t.codeSnippetHtml},null,8,["code"])]),_:2},1032,["title","id"])),64)}}}),_e={class:"chi-card -portal -bg--white"},ue={class:"chi-card__content -p--0"},pe=C({__name:"_base",setup(c){const s=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint"}],o={...w,style:{...w.style,portal:!0,striped:!0},pagination:{...w.pagination,compact:!0,firstLast:!0,pageJumper:!1}},h={head:{...N,name:{...N.name,key:!0,bold:!0}},body:R},n={vue:O(X(!0),ia,A()),htmlblueprint:Da};return(r,i)=>{const d=f("ChiDataTable"),t=$,_=L;return g(),k(_,{title:"Base",id:"base-portal-data-table",tabs:s},{example:l(()=>[a("div",_e,[i[0]||(i[0]=a("div",{class:"chi-card__header -sm"},[a("div",{class:"chi-card__title"},"Title")],-1)),a("div",ue,[e(d,{config:o,dataTableData:h})])])]),"code-vue":l(()=>[i[1]||(i[1]=a("div",{class:"chi-tab__description"},[p("Use "),a("code",null,"portal"),p(" config to achieve portal styling")],-1)),e(t,{lang:"html",code:n.vue},null,8,["code"])]),"code-htmlblueprint":l(()=>[e(t,{lang:"html",code:n.htmlblueprint},null,8,["code"])]),_:1})}}}),me={class:"chi-card -portal -bg--white"},ge={class:"chi-card__content -p--0"},we=["innerHTML"],fe=C({__name:"_empty",setup(c){const s=[{title:"No Results",id:"no-results-data-table",description:"Use <code>noResultsMessage</code> config to customize the no results data message",config:{noResultsMessage:"No matching results"}},{title:"No Filters",id:"no-filters-data-table",description:"Use <code>noFiltersMessage</code> config to customize the no filters data message",config:{noFiltersMessage:"Search for or select at least one filter to get results"}},{title:"Empty Actionable",id:"empty-actionable-data-table",description:null,config:{emptyActionable:{isActionable:!0}}}],o=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint"}],h={...w,style:{...w.style,portal:!0,striped:!0},pagination:{...w.pagination,compact:!0,firstLast:!0,pageJumper:!1}},v={head:N,body:[]},n=t=>({...h,...t.noFiltersMessage?{noResultsMessage:t.noFiltersMessage}:t}),r=t=>t.emptyActionable?`<div>
        <i class="chi-icon icon-circle-plus-outline -icon--grey -lg" aria-hidden="true"></i>
        <span>
          <a>Add a new or existing service</a>, then manage here.
        </span>
      </div>`:`<i class="-mr--1 chi-icon icon-search -icon--dark"></i>
      <div>${t.noFiltersMessage||t.noResultsMessage}</div>`,i=t=>`<!-- Vue component -->
<ChiDataTable :config="config" :dataTableData="table"></ChiDataTable>

<!-- Config and Data -->
data: {
  config: {
    columnResize: true,${t.noFiltersMessage?`
    noFiltersMessage: '${t.noFiltersMessage}',`:""}${t.noResultsMessage?`
    noResultsMessage: '${t.noResultsMessage}',`:""}
    style: {
      portal: true,
      noBorder: false,
      bordered: false,
      hover: false,
      size: 'md',
      striped: true,
    },
    pagination: {
      activePage: 1,
      compact: true,
      firstLast: true,
      pageJumper: false,
    },${t.emptyActionable?`
    emptyActionable: {
      isActionable: true,
    },`:""}
    resultsPerPage: 3,
  },
  table: {
    ${B}
    body: []
  }
}`,d=t=>`<div class="chi-data-table -portal -compact">
  <div class="chi-data-table__head">
    <div class="chi-data-table__row">
      <div class="chi-data-table__cell">
        <div>Name</div>
      </div>
      <div class="chi-data-table__cell">
        <div>ID</div>
      </div>
      <div class="chi-data-table__cell">
        <div>Last Login</div>
      </div>
    </div>
  </div>
  <div class="chi-data-table__body">
    <div class="chi-data-table__row-empty${t.emptyActionable?" -actionable":""}">
      ${r(t)}
    </div>
  </div>
  <div class="chi-data-table__footer">
    <nav class="chi-pagination -compact" role="navigation" aria-label="Pagination">
        <div class="chi-pagination__content">
          <div class="chi-pagination__start">
          </div>
          <div class="chi-pagination__center">
            <div class="chi-pagination__button-group chi-button-group">
              <button class="chi-button -icon -flat -xs" aria-label="First page" disabled>
                <div class="chi-button__content">
                  <i class="chi-icon icon-page-first" aria-hidden="true"></i>
                </div>
              </button>
              <button class="chi-button -icon -flat -xs" aria-label="Previous page" disabled>
                <div class="chi-button__content">
                  <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
                </div>
              </button>
            </div>
            <div class="chi-pagination__label">
              <strong>1</strong>
              <span>of</span>
              <strong>1</strong>
            </div>
            <div class="chi-pagination__button-group chi-button-group">
              <button class="chi-button -icon -flat -xs" aria-label="Next page" disabled>
                <div class="chi-button__content">
                  <i class="chi-icon icon-chevron-right" aria-hidden="true"></i>
                </div>
              </button>
              <button class="chi-button -icon -flat -xs" aria-label="Last page" disabled>
                <div class="chi-button__content">
                  <i class="chi-icon icon-page-last" aria-hidden="true"></i>
                </div>
              </button>
            </div>
          </div>
          <div class="chi-pagination__end"></div>
        </div>
      </nav>
  </div>
</div>`;return(t,_)=>{const b=ca,m=f("ChiDataTable"),u=$,y=L;return g(),I(E,null,[e(b,{title:"Empty",id:"empty-data-table-portal"}),(g(),I(E,null,U(s,D=>e(y,{title:D.title,titleSize:"h4",id:D.id,key:D.id,tabs:o},{example:l(()=>[a("div",me,[_[0]||(_[0]=a("div",{class:"chi-card__header -sm"},[a("div",{class:"chi-card__title"},"Title")],-1)),a("div",ge,[e(m,{config:n(D.config),dataTableData:v},null,8,["config"])])])]),"code-vue":l(()=>[D.description?(g(),I("div",{key:0,class:"chi-tab__description",innerHTML:D.description},null,8,we)):q("",!0),e(u,{lang:"html",code:i(D.config)},null,8,["code"])]),"code-htmlblueprint":l(()=>[e(u,{lang:"html",code:d(D.config)},null,8,["code"])]),_:2},1032,["title","id"])),64))],64)}}}),xe={class:"chi-card -portal -bg--white"},De={class:"chi-card__content -p--0"},Ce=C({__name:"_radio-selection",setup(c){const s=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint"}],o={...w,style:{...w.style,portal:!0,striped:!0},pagination:{...w.pagination,compact:!0,firstLast:!0,pageJumper:!1},selectable:"radio"},h={head:N,body:R},n={vue:O(Ca,B,A()),htmlblueprint:ya};return(r,i)=>{const d=f("ChiDataTable"),t=$,_=L;return g(),k(_,{title:"Radio selection",id:"radio-selection-portal-data-table",tabs:s},{example:l(()=>[a("div",xe,[i[0]||(i[0]=a("div",{class:"chi-card__header -sm"},[a("div",{class:"chi-card__title"},"Title")],-1)),a("div",De,[e(d,{config:o,dataTableData:h})])])]),"code-vue":l(()=>[i[1]||(i[1]=a("div",{class:"chi-tab__description"},[p("Use "),a("code",null,"selectable"),p(" config to render rows with radio buttons")],-1)),e(t,{lang:"html",code:n.vue},null,8,["code"])]),"code-htmlblueprint":l(()=>[e(t,{lang:"html",code:n.htmlblueprint},null,8,["code"])]),_:1})}}}),ye={class:"chi-card -portal -bg--white"},Ne={class:"chi-card__content -p--0"},Le=C({__name:"_second-line-wrapping",setup(c){const s=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint"}],o={...w,style:{...w.style,portal:!0,striped:!0},pagination:{...w.pagination,compact:!0,firstLast:!0,pageJumper:!1},cellWrap:!0},h={head:{name:{label:"This is a long header content with a second line wrapping without tooltip: This is a long content for the tooltip in the wrapped cell",key:!0,bold:!0},id:{label:"ID",key:!0},lastLogin:{label:"Last Login"}},body:Na},v={vue:La,htmlblueprint:Ta};return(n,r)=>{const i=f("ChiDataTable"),d=$,t=L;return g(),k(t,{title:"Second line wrapping",id:"second-line-wrapping-data-table",tabs:s},{example:l(()=>[a("div",ye,[r[0]||(r[0]=a("div",{class:"chi-card__header -sm"},[a("div",{class:"chi-card__title"},"Title")],-1)),a("div",Ne,[e(i,{config:o,dataTableData:h})])])]),"code-vue":l(()=>[r[1]||(r[1]=a("div",{class:"chi-tab__description"},[p("Use "),a("code",null,"cellWrap"),p(" config to achieve the two line wrapping")],-1)),e(d,{lang:"html",code:v.vue},null,8,["code"])]),"code-htmlblueprint":l(()=>[e(d,{lang:"html",code:v.htmlblueprint},null,8,["code"])]),_:1})}}}),Te={class:"chi-card -portal -bg--white"},$e={class:"chi-card__content -p--0"},ke=C({__name:"_state",setup(c){const s=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint"}],o={...w,style:{...w.style,portal:!0,striped:!0},pagination:{...w.pagination,compact:!0,firstLast:!0,pageJumper:!1}},h=R.map(i=>i.id==="name-2"?{...i,state:"danger"}:i),v={head:{...N,name:{...N.name,key:!0,bold:!0},id:{...N.id,key:!0}},body:h},r={vue:O(X(!0),ia,A(!1,!0)),htmlblueprint:$a};return(i,d)=>{const t=f("ChiDataTable"),_=$,b=L;return g(),k(b,{title:"State",id:"state-data-table",tabs:s},{example:l(()=>[a("div",Te,[d[0]||(d[0]=a("div",{class:"chi-card__header -sm"},[a("div",{class:"chi-card__title"},"Title")],-1)),a("div",$e,[e(t,{config:o,dataTableData:v})])])]),"code-vue":l(()=>[d[1]||(d[1]=a("div",{class:"chi-tab__description"},[p("Use "),a("code",null,"state"),p(" config to achieve state styling")],-1)),e(_,{lang:"html",code:r.vue},null,8,["code"])]),"code-htmlblueprint":l(()=>[e(_,{lang:"html",code:r.htmlblueprint},null,8,["code"])]),_:1})}}}),Ie=C({__name:"_two-tier",setup(c){const s=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],o={htmlblueprint:`<div class="chi-card -portal -bg--white -bg-md--grey-15">
  <div class="chi-card__header -sm">
    <div class="chi-card__title">Title</div>
  </div>
  <div class="chi-card__content -p--0">
    <div class="chi-data-table -portal -compact">
      <div class="chi-data-table__head">
        <div class="chi-data-table__row">
          <div class="chi-data-table__cell -justify-content-md--start -sorting" aria-label="Sort Column Location"
            data-column="location" data-sort="ascending" data-label="Location">
            Location
            <chi-button variant="flat" type="icon">
              <chi-icon icon="arrow-up" size="xs"></chi-icon>
            </chi-button>
          </div>
          <div class="chi-data-table__cell -justify-content-md--start -sorting" aria-label="Sort Column High Utilization"
            data-column="highUtilization" data-sort="ascending" data-label="High Utilization">
            High Utilization
            <chi-button variant="flat" type="icon">
              <chi-icon icon="arrow-sort" size="xs"></chi-icon>
            </chi-button>
          </div>
          <div class="chi-data-table__cell -justify-content-md--start -sorting" aria-label="Sort Column Elevated Utilization"
            data-column="elevatedUtilization" data-sort="ascending" data-label="Elevated Utilization">
            Elevated Utilization
            <chi-button variant="flat" type="icon">
              <chi-icon icon="arrow-sort" size="xs"></chi-icon>
            </chi-button>
          </div>
          <div class="chi-data-table__cell -justify-content-md--start -sorting" aria-label="Sort Column Highest %"
            data-column="highest" data-sort="ascending" data-label="Highest %">
            Highest %
            <chi-button variant="flat" type="icon">
              <chi-icon icon="arrow-sort" size="xs"></chi-icon>
            </chi-button>
          </div>
        </div>
        <div class="chi-data-table__row">
          <div class="chi-data-table__cell"></div>
          <div class="chi-data-table__cell">
            <div class="-associated">Total</div>
            <div class="-associated">%</div>
          </div>
          <div class="chi-data-table__cell">
            <div class="-associated">Total</div>
            <div class="-associated">%</div>
          </div>
          <div class="chi-data-table__cell"></div>
        </div>
      </div>
      <div class="chi-data-table__body">
        <div class="chi-data-table__row -md">
          <div class="chi-data-table__cell -key -bold">
            <div>Location 1</div>
          </div>
          <div class="chi-data-table__cell">
            <div class="-associated">3</div>
            <div class="-associated">98%</div>
          </div>
          <div class="chi-data-table__cell">
            <div class="-associated">-</div>
            <div class="-associated">-</div>
          </div>
          <div class="chi-data-table__cell">
            <div>98%</div>
          </div>
        </div>
        <div class="chi-data-table__row -striped -md">
          <div class="chi-data-table__cell -key -bold">
            <div>Location 2</div>
          </div>
          <div class="chi-data-table__cell">
            <div class="-associated">1</div>
            <div class="-associated">98%</div>
          </div>
          <div class="chi-data-table__cell">
            <div class="-associated">3</div>
            <div class="-associated">67%</div>
          </div>
          <div class="chi-data-table__cell">
            <div>98%</div>
          </div>
        </div>
        <div class="chi-data-table__row -md">
          <div class="chi-data-table__cell -key -bold">
            <div>Location 3</div>
          </div>
          <div class="chi-data-table__cell">
            <div class="-associated">-</div>
            <div class="-associated">-</div>
          </div>
          <div class="chi-data-table__cell">
            <div class="-associated">2</div>
            <div class="-associated">66</div>
          </div>
          <div class="chi-data-table__cell">
            <div>66%</div>
          </div>
        </div>
      </div>
      <div class="chi-data-table__footer">
        <nav class="chi-pagination -compact" role="navigation" aria-label="Pagination">
          <div class="chi-pagination__content">
            <div class="chi-pagination__start">
              <div class="chi-pagination__results">
                <span class="chi-pagination__label">240 Results</span>
              </div>
            </div>
            <div class="chi-pagination__center">
              <div class="chi-pagination__button-group chi-button-group">
                <button class="chi-button -icon -flat -xs" aria-label="First page">
                  <div class="chi-button__content">
                    <i class="chi-icon icon-page-first" aria-hidden="true"></i>
                  </div>
                </button>
                <button class="chi-button -icon -flat -xs" aria-label="Previous page">
                  <div class="chi-button__content">
                    <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
                  </div>
                </button>
              </div>
              <div class="chi-pagination__label">
                <strong>2</strong>
                <span>of</span>
                <strong>3</strong>
              </div>
              <div class="chi-pagination__button-group chi-button-group">
                <button class="chi-button -icon -flat -xs" aria-label="Next page">
                  <div class="chi-button__content">
                    <i class="chi-icon icon-chevron-right" aria-hidden="true"></i>
                  </div>
                </button>
                <button class="chi-button -icon -flat -xs" aria-label="Last page">
                  <div class="chi-button__content">
                    <i class="chi-icon icon-page-last" aria-hidden="true"></i>
                  </div>
                </button>
              </div>
            </div>
            <div class="chi-pagination__end"></div>
          </div>
        </nav>
      </div>
    </div>
  </div>
</div>`};return(h,v)=>{const n=$,r=L;return g(),k(r,{title:"Two tier header",id:"two-tier-data-table",tabs:s},{example:l(()=>[...v[0]||(v[0]=[a("div",{class:"chi-card -portal -bg--white -bg-md--grey-15"},[a("div",{class:"chi-card__header -sm"},[a("div",{class:"chi-card__title"},"Title")]),a("div",{class:"chi-card__content -p--0"},[a("div",{class:"chi-data-table -portal -compact"},[a("div",{class:"chi-data-table__head"},[a("div",{class:"chi-data-table__row"},[a("div",{class:"chi-data-table__cell -justify-content-md--start -sorting","aria-label":"Sort Column Location","data-column":"localization","data-sort":"ascending","data-label":"Location"},[p("Location"),a("chi-button",{variant:"flat",type:"icon"},[a("chi-icon",{icon:"arrow-up",size:"xs"})])]),a("div",{class:"chi-data-table__cell -justify-content-md--start -sorting","aria-label":"Sort Column High Utilization","data-column":"highUtilization","data-sort":"ascending","data-label":"High Utilization"},[p("High Utilization"),a("chi-button",{variant:"flat",type:"icon"},[a("chi-icon",{icon:"arrow-sort",size:"xs"})])]),a("div",{class:"chi-data-table__cell -justify-content-md--start -sorting","aria-label":"Sort Column Elevated Utilization","data-column":"elevatedUtilization","data-sort":"ascending","data-label":"Elevated Utilization"},[p("Elevated Utilization"),a("chi-button",{variant:"flat",type:"icon"},[a("chi-icon",{icon:"arrow-sort",size:"xs"})])]),a("div",{class:"chi-data-table__cell -justify-content-md--start -sorting","aria-label":"Sort Column Highest %","data-column":"highest","data-sort":"ascending","data-label":"Highest %"},[p("Highest %"),a("chi-button",{variant:"flat",type:"icon"},[a("chi-icon",{icon:"arrow-sort",size:"xs"})])])]),a("div",{class:"chi-data-table__row"},[a("div",{class:"chi-data-table__cell"}),a("div",{class:"chi-data-table__cell"},[a("div",{class:"-associated"},"Total"),a("div",{class:"-associated"},"%")]),a("div",{class:"chi-data-table__cell"},[a("div",{class:"-associated"},"Total"),a("div",{class:"-associated"},"%")]),a("div",{class:"chi-data-table__cell"})])]),a("div",{class:"chi-data-table__body"},[a("div",{class:"chi-data-table__row -md"},[a("div",{class:"chi-data-table__cell -key -bold"},[a("div",null,"Location 1")]),a("div",{class:"chi-data-table__cell"},[a("div",{class:"-associated"},"3"),a("div",{class:"-associated"},"98%")]),a("div",{class:"chi-data-table__cell"},[a("div",{class:"-associated"},"-"),a("div",{class:"-associated"},"-")]),a("div",{class:"chi-data-table__cell"},[a("div",null,"98%")])]),a("div",{class:"chi-data-table__row -striped -md"},[a("div",{class:"chi-data-table__cell -key -bold"},[a("div",null,"Location 2")]),a("div",{class:"chi-data-table__cell"},[a("div",{class:"-associated"},"1"),a("div",{class:"-associated"},"98%")]),a("div",{class:"chi-data-table__cell"},[a("div",{class:"-associated"},"3"),a("div",{class:"-associated"},"67%")]),a("div",{class:"chi-data-table__cell"},[a("div",null,"98%")])]),a("div",{class:"chi-data-table__row -md"},[a("div",{class:"chi-data-table__cell -key -bold"},[a("div",null,"Location 3")]),a("div",{class:"chi-data-table__cell"},[a("div",{class:"-associated"},"-"),a("div",{class:"-associated"},"-")]),a("div",{class:"chi-data-table__cell"},[a("div",{class:"-associated"},"2"),a("div",{class:"-associated"},"66")]),a("div",{class:"chi-data-table__cell"},[a("div",null,"66%")])])]),a("div",{class:"chi-data-table__footer"},[a("nav",{class:"chi-pagination -compact",role:"navigation","aria-label":"Pagination"},[a("div",{class:"chi-pagination__content"},[a("div",{class:"chi-pagination__start"},[a("div",{class:"chi-pagination__results -text--xs"},[a("span",{class:"chi-pagination__label"},"240 Results")])]),a("div",{class:"chi-pagination__center"},[a("div",{class:"chi-pagination__button-group chi-button-group"},[a("button",{class:"chi-button -icon -flat -xs","aria-label":"First page"},[a("div",{class:"chi-button__content"},[a("i",{class:"chi-icon icon-page-first","aria-hidden":"true"})])]),a("button",{class:"chi-button -icon -flat -xs","aria-label":"Previous page"},[a("div",{class:"chi-button__content"},[a("i",{class:"chi-icon icon-chevron-left","aria-hidden":"true"})])])]),a("div",{class:"chi-pagination__label"},[a("strong",null,"2"),a("span",null,"of"),a("strong",null,"3")]),a("div",{class:"chi-pagination__button-group chi-button-group"},[a("button",{class:"chi-button -icon -flat -xs","aria-label":"Next page"},[a("div",{class:"chi-button__content"},[a("i",{class:"chi-icon icon-chevron-right","aria-hidden":"true"})])]),a("button",{class:"chi-button -icon -flat -xs","aria-label":"Last page"},[a("div",{class:"chi-button__content"},[a("i",{class:"chi-icon icon-page-last","aria-hidden":"true"})])])])]),a("div",{class:"chi-pagination__end"})])])])])])],-1)])]),"code-htmlblueprint":l(()=>[e(n,{lang:"html",code:o.htmlblueprint},null,8,["code"])]),_:1})}}}),Se={class:"chi-card -portal -bg--white"},ze={class:"chi-card__content -p--0"},Pe=["icon","color"],Ee={class:"-text--truncate -pl--1"},Re=C({__name:"_complex",setup(c){const s=S(null),o=()=>{s.value?.print("Data table - Complex")},h=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint",disabled:!0}],v=wa,n={head:ra,body:oa};return(r,i)=>{const d=f("ChiDataTableToolbar"),t=f("ChiDataTable"),_=L;return g(),k(_,{title:"Complex",id:"complex-data-table",tabs:h},{example:l(()=>[a("div",Se,[i[2]||(i[2]=a("div",{class:"chi-card__header -sm"},[a("div",{class:"chi-card__title"},"Title")],-1)),a("div",ze,[e(t,{config:P(v),dataTableData:n,ref_key:"dataTableComplex",ref:s},{status:l(b=>[a("chi-icon",{icon:b.icon,color:b.color,"aria-hidden":"true"},null,8,Pe),a("span",Ee,la(b.status),1)]),name:l(b=>[(g(),k(sa,{name:b.name,id:b.id,key:b.id},null,8,["name","id"]))]),toolbar:l(()=>[e(d,null,{end:l(()=>[a("chi-button",{onClick:o,variant:"flat",type:"icon","aria-label":"Print data table complex example"},[...i[0]||(i[0]=[a("chi-icon",{icon:"print"},null,-1)])])]),_:1})]),"bulk-actions":l(()=>[...i[1]||(i[1]=[a("div",{class:"chi-bulk-actions__buttons"},[a("div",{class:"chi-bulk-actions__buttons-mobile -z--40"},[a("chi-button",{variant:"flat",type:"icon","aria-label":"Edit"},[a("chi-icon",{icon:"edit"})]),a("chi-button",{variant:"flat",type:"icon","aria-label":"Compose"},[a("chi-icon",{icon:"compose"})]),a("chi-button",{variant:"flat",type:"icon","aria-label":"Delete"},[a("chi-icon",{icon:"delete"})]),a("chi-button",{variant:"flat",type:"icon","aria-label":"Print"},[a("chi-icon",{icon:"print"})])]),a("div",{class:"chi-bulk-actions__buttons-desktop"},[a("chi-button",{size:"xs","aria-label":"Download"},[a("chi-icon",{icon:"arrow-to-bottom"}),a("span",null,"Download")]),a("chi-button",{size:"xs","aria-label":"Compose"},[a("chi-icon",{icon:"arrow-to-bottom"}),a("span",null,"Compose")]),a("chi-button",{size:"xs","aria-label":"Delete"},[a("chi-icon",{icon:"arrow-to-bottom"}),a("span",null,"Delete")]),a("chi-button",{size:"xs","aria-label":"Print"},[a("chi-icon",{icon:"arrow-to-bottom"}),a("span",null,"Print")])])],-1)])]),_:1},8,["config"])])])]),"code-vue":l(()=>[e(na)]),_:1})}}}),Be={class:"chi-card -portal -bg--white"},Ae={class:"chi-card__content -p--0"},He=["innerHTML"],Me={class:"-d--flex"},Ve=["icon","color"],je=["innerHTML"],Ue=C({__name:"_highlight",setup(c){const s=[{active:!1,id:"webcomponent",label:"Web Component",disabled:!0},{active:!0,id:"vue",label:"Vue"},{active:!1,id:"htmlblueprint",label:"HTML Blueprint",disabled:!0}],o=S(null),h=S(null),v=S(""),n=S({head:J,body:H}),r=S({columns:J}),i={vue:pa(!0),htmlblueprint:""},d=b=>{v.value=b;const m=da(H,b,o.value),u=Q(m,b,o.value);n.value={...n.value,body:u}},t=()=>{const b=Q(H,"",o.value);n.value={...n.value,body:b},v.value=""},_=b=>{const m=h.value,u=new Set(b.map(y=>y.name));r.value.columns.forEach(y=>y.selected=u.has(y.name)),n.value={...n.value,head:r.value.columns},m._cleanInput()};return(b,m)=>{const u=f("ChiSearchInput"),y=f("ChiColumnCustomization"),D=f("ChiDataTableToolbar"),Z=f("ChiDataTable"),F=$,aa=L;return g(),k(aa,{title:"Highlight",id:"highlight-data-table",tabs:s},{"example-description":l(()=>[...m[0]||(m[0]=[a("p",{class:"-text"},[p(" In order to see the highlight effect in hidden columns, please search for "),a("code",null,"30"),p(" in the search input. Use "),a("code",null,"Column Customization vue component"),p(" feature to manipulate the columns visibility to show/hide them.")],-1)])]),example:l(()=>[a("div",Be,[m[1]||(m[1]=a("div",{class:"chi-card__header -sm"},[a("div",{class:"chi-card__title"},"Title")],-1)),a("div",Ae,[e(Z,{config:P(te),dataTableData:n.value,ref_key:"dataTableHighlight",ref:o},{toolbar:l(()=>[e(D,null,{start:l(()=>[e(u,{ref_key:"searchInput",ref:h,onChiInput:d,onChiClean:t},null,512)]),end:l(()=>[e(y,{"columns-data":r.value,onChiColumnsChange:_},null,8,["columns-data"])]),_:1})]),productName:l(z=>[a("chi-link",null,[a("span",{innerHTML:P(K)(z.productName,v.value)},null,8,He)])]),status:l(z=>[a("div",Me,[a("chi-icon",{class:"-mr--1",icon:z.icon,color:z.color},null,8,Ve),a("span",{innerHTML:P(K)(z.status,v.value)},null,8,je)])]),_:1},8,["config","dataTableData"])])])]),"code-vue":l(()=>[m[2]||(m[2]=a("div",{class:"chi-tab__description"},[p("Use "),a("code",null,"hideNonSelectedColumns"),p(" in config to hide non-selected columns")],-1)),e(F,{lang:"html",code:i.vue},null,8,["code"])]),"code-htmlblueprint":l(()=>[e(F,{lang:"html",code:i.htmlblueprint},null,8,["code"])]),_:1})}}}),Fe={key:0},We={key:1},Ye=C({__name:"index",setup(c){const s=ga();return(o,h)=>{const v=ma;return g(),I(E,null,[h[0]||(h[0]=a("h2",null,"Examples",-1)),e(v,null,{default:l(()=>[["lumen","centurylink"].includes(P(s))?(g(),I("div",Fe,[e(ie),e(Ga),e(re),e(qa),e(Qa),e(Ja),e(Xa),e(Wa),e(Za),e(Ya)])):q("",!0),["portal","brightspeed","colt"].includes(P(s))?(g(),I("div",We,[e(Re),e(pe),e(Ue),e(Le),e(ke),e(fe),e(Ce),e(he),e(Ie)])):q("",!0)]),_:1})],64)}}});export{Ye as _};
