import{_ as u}from"./DnPF01B5.js";import{_}from"./CdcsEwU-.js";import{e as d,q as b,i as D,o as p,w as i,b as c,a,d as h,c as x}from"./DBXeQHmC.js";const C=["items"],f=`<chi-drag id="drag-example"></chi-drag>

<script>
  const drag = document.getElementById('drag-example');

  drag.items = [
    { data: { title: 'Drag title 1', description: 'Drag description 1' }},
    { data: { title: 'Drag title 2', description: 'Drag description 2' }},
    { data: { title: 'Drag title 3', description: 'Drag description 3' }},
    { data: { title: 'Drag title 4', description: 'Drag description 4' }},
  ];

  drag.addEventListener('chiCloseClick', (ev) => {
    drag.items = drag.items.filter((item) => item.id !== ev.detail.id);
  });
<\/script>
`,w=d({__name:"_base",setup(m){const t=b([{data:{title:"Drag title 1",description:"Drag description 1"}},{data:{title:"Drag title 2",description:"Drag description 2"}},{data:{title:"Drag title 3",description:"Drag description 3"}},{data:{title:"Drag title 4",description:"Drag description 4"}}]),o=n=>{t.value=t.value.filter(e=>e.id!==n.detail.id)},l=[{active:!0,id:"webcomponent",label:"Web Component"},{disabled:!0,id:"htmlblueprint",label:"HTML Blueprint"}],s={webcomponent:f,htmlblueprint:""};return(n,e)=>{const r=u,g=_;return p(),D(g,{title:"Base",id:"base",tabs:l},{"example-description":i(()=>[...e[0]||(e[0]=[a("p",{class:"-text"},"Try to drag and drop items.",-1)])]),example:i(()=>[a("chi-drag",{items:t.value,"on:chiCloseClick":o},null,40,C)]),"code-webcomponent":i(()=>[c(r,{class:"html",lang:"html",code:s.webcomponent},null,8,["code"])]),_:1})}}}),v=["items"],k=`<chi-drag id="drag-non-closable-example"></chi-drag>

<script>
  const drag = document.getElementById('drag-non-closable-example');

  drag.items = [
    { data: { title: 'Drag title 1', description: 'Drag description 1' }, closable: false },
    { data: { title: 'Drag title 2', description: 'Drag description 2' }, closable: false },
    { data: { title: 'Drag title 3', description: 'Drag description 3' }, closable: false },
    { data: { title: 'Drag title 4', description: 'Drag description 4' }, closable: false },
  ];
<\/script>
`,B=d({__name:"_non-closable",setup(m){const t=b([{data:{title:"Drag title 1",description:"Drag description 1"},closable:!1},{data:{title:"Drag title 2",description:"Drag description 2"},closable:!1},{data:{title:"Drag title 3",description:"Drag description 3"},closable:!1},{data:{title:"Drag title 4",description:"Drag description 4"},closable:!1}]),o=[{active:!0,id:"webcomponent",label:"Web Component"},{disabled:!0,id:"htmlblueprint",label:"HTML Blueprint"}],l={webcomponent:k,htmlblueprint:""};return(s,n)=>{const e=u,r=_;return p(),D(r,{title:"Non-closable",id:"non-closable",tabs:o},{example:i(()=>[a("chi-drag",{items:t.value},null,8,v)]),"code-webcomponent":i(()=>[c(e,{class:"html",lang:"html",code:l.webcomponent},null,8,["code"])]),_:1})}}}),E=["items"],I=`<chi-drag id="drag-custom-icons-example"></chi-drag>

<script>
  const drag = document.getElementById('drag-custom-icons-example');

  drag.items = [
    { data: { title: 'Drag title 1', description: 'Drag description 1' }, icon: 'list-alt' },
    { data: { title: 'Drag title 2', description: 'Drag description 2' }, icon: 'chart-bar' },
    { data: { title: 'Drag title 3', description: 'Drag description 3' }, icon: 'cost' },
    { data: { title: 'Drag title 4', description: 'Drag description 4' }, icon: 'api' },
  ];

  drag.addEventListener('chiCloseClick', (ev) => {
    drag.items = drag.items.filter((item) => item.id !== ev.detail.id);
  });
<\/script>
`,$=d({__name:"_custom-icons",setup(m){const t=b([{data:{title:"Drag title 1",description:"Drag description 1"},icon:"list-alt"},{data:{title:"Drag title 2",description:"Drag description 2"},icon:"chart-bar"},{data:{title:"Drag title 3",description:"Drag description 3"},icon:"cost"},{data:{title:"Drag title 4",description:"Drag description 4"},icon:"api"}]),o=n=>{t.value=t.value.filter(e=>e.id!==n.detail.id)},l=[{active:!0,id:"webcomponent",label:"Web Component"},{disabled:!0,id:"htmlblueprint",label:"HTML Blueprint"}],s={webcomponent:I,htmlblueprint:""};return(n,e)=>{const r=u,g=_;return p(),D(g,{title:"Customized icons",id:"custom-icons",tabs:l},{example:i(()=>[a("chi-drag",{items:t.value,"on:chiCloseClick":o},null,40,E)]),"code-webcomponent":i(()=>[c(r,{class:"html",lang:"html",code:s.webcomponent},null,8,["code"])]),_:1})}}}),y=["items"],T=`<chi-drag id="drag-info-icon-example"></chi-drag>

<script>
  const drag = document.getElementById('drag-info-icon-example');

  drag.items = [
    {
      data: {
        title: 'Drag title 1',
        description: 'Drag description 1',
        infoIcon: {
          icon: 'circle-info-outline',
          message: 'Custom info text',
        },
      },
    },
    {
      data: {
        title: 'Drag title 2',
        description: 'Drag description 2',
        infoIcon: {
          icon: 'circle-info-outline',
          message: 'Custom info text',
        },
      },
    },
    {
      data: {
        title: 'Drag title 3',
        description: 'Drag description 3',
        infoIcon: {
          icon: 'circle-alert-outline',
          message: 'Custom alert text',
          color: 'danger',
        },
      },
    },
    {
      data: {
        title: 'Drag title 4',
        description: 'Drag description 4',
        infoIcon: {
          icon: 'circle-info-outline',
          message: 'Custom info text',
        },
      },
    },
  ];

  drag.addEventListener('chiCloseClick', (ev) => {
    drag.items = drag.items.filter((item) => item.id !== ev.detail.id);
  });
<\/script>
`,S=d({__name:"_info-icon",setup(m){const t=b([{data:{title:"Drag title 1",description:"Drag description 1",infoIcon:{icon:"circle-info-outline",message:"Custom info text"}}},{data:{title:"Drag title 2",description:"Drag description 2",infoIcon:{icon:"circle-info-outline",message:"Custom info text"}}},{data:{title:"Drag title 3",description:"Drag description 3",infoIcon:{icon:"circle-alert-outline",message:"Custom alert text",color:"danger"}}},{data:{title:"Drag title 4",description:"Drag description 4",infoIcon:{icon:"circle-info-outline",message:"Custom info text"}}}]),o=n=>{t.value=t.value.filter(e=>e.id!==n.detail.id)},l=[{active:!0,id:"webcomponent",label:"Web Component"},{disabled:!0,id:"htmlblueprint",label:"HTML Blueprint"}],s={webcomponent:T,htmlblueprint:""};return(n,e)=>{const r=u,g=_;return p(),D(g,{title:"Help",id:"info-icon",tabs:l},{"example-description":i(()=>[...e[0]||(e[0]=[a("p",{class:"-text"},[h("A "),a("code",null,"infoIcon"),h(" property allows you to add an info icon to each drag item with a custom message.")],-1)])]),example:i(()=>[a("chi-drag",{items:t.value,"on:chiCloseClick":o},null,40,y)]),"code-webcomponent":i(()=>[c(r,{class:"html",lang:"html",code:s.webcomponent},null,8,["code"])]),_:1})}}}),L=["items"],H=`<chi-drag id="drag-locked-example"></chi-drag>

<script>
  const drag = document.getElementById('drag-locked-example');

  drag.items = [
    { data: { title: 'Drag title 1', description: 'Drag description 1' }, locked: true },
    { data: { title: 'Drag title 2', description: 'Drag description 2' }, locked: true },
    { data: { title: 'Drag title 3', description: 'Drag description 3' }, locked: true },
    { data: { title: 'Drag title 4', description: 'Drag description 4' }, locked: true },
  ];
<\/script>
`,M=d({__name:"_locked",setup(m){const t=b([{data:{title:"Drag title 1",description:"Drag description 1"},locked:!0},{data:{title:"Drag title 2",description:"Drag description 2"},locked:!0},{data:{title:"Drag title 3",description:"Drag description 3"},locked:!0},{data:{title:"Drag title 4",description:"Drag description 4"},locked:!0}]),o=[{active:!0,id:"webcomponent",label:"Web Component"},{disabled:!0,id:"htmlblueprint",label:"HTML Blueprint"}],l={webcomponent:H,htmlblueprint:""};return(s,n)=>{const e=u,r=_;return p(),D(r,{title:"Locked",id:"locked",tabs:o},{"example-description":i(()=>[...n[0]||(n[0]=[a("p",{class:"-text"},[h("A "),a("code",null,"locked"),h(" item cannot be removed or dragged and can't render the custom icon.")],-1)])]),example:i(()=>[a("chi-drag",{items:t.value},null,8,L)]),"code-webcomponent":i(()=>[c(e,{class:"html",lang:"html",code:l.webcomponent},null,8,["code"])]),_:1})}}}),A=d({__name:"index",setup(m){return(t,o)=>(p(),x("div",null,[o[0]||(o[0]=a("h2",null,"Examples",-1)),c(w),c(B),c(M),c($),c(S)]))}});export{A as _};
