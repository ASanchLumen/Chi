import{_ as H}from"./DnPF01B5.js";import{_ as N}from"./CdcsEwU-.js";import{e as T,Q as g,q as z,H as O,a9 as $,i as f,o as n,w as p,b as w,a as i,k as b,c as a,F as l,r as t,aa as F,l as m,S as r,t as s,x as J,a8 as W,d as C,g as G}from"./DBXeQHmC.js";import{_ as K}from"./Bo0goINO.js";const U={ref:"mobile-nav-trigger",variant:"flat",type:"icon"},X={class:"chi-mobile-nav -global",ref:"mobile-nav"},Y={id:"main-menu"},Z={class:"chi-mobile-nav__header"},ii=["retain-selection","button"],ei={class:"chi-grid"},ci={class:"chi-col -w--4"},ni={class:"chi-col -w--7"},ai={key:0,class:"chi-col -w--1"},si={class:"chi-mobile-nav__list"},oi=["href"],li=["icon"],ti={key:1,icon:"chevron-right"},ri={class:"chi-mobile-nav__list"},di=["href"],hi=["icon"],mi={key:0,icon:"external-link",size:"sm"},ui={id:"services-menu"},vi={class:"chi-mobile-nav__list"},_i=["href"],pi={key:0,icon:"chevron-right"},bi={id:"apis-menu"},gi={class:"chi-mobile-nav__list"},wi=["href"],fi={key:0,icon:"chevron-right"},ki={id:"quotes-menu"},Ii={class:"chi-mobile-nav__list"},xi={id:"service-portals-menu"},Ti={class:"chi-mobile-nav__list"},yi={id:"view-apis-menu"},Si={class:"chi-mobile-nav__list"},Ci=`<!--Trigger button-->
<chi-button id="mobile-nav-trigger" variant="flat" type="icon">
  <chi-icon icon="menu"></chi-icon>
</chi-button>

<!--Mobile navigation drawer-->
<div class="chi-mobile-nav -global" id="mobile-nav">
  <chi-drawer id="mobile-nav-drawer">
    <div id="main-menu">
      <div class="chi-mobile-nav__header">
        <chi-dropdown
          id="enterprise-dropdown"
          class="enterprise-id-switcher"
          position="bottom"
          button="Enterprise ID: 1234567"
          size="sm"
          select-mode
        >
          <div class="chi-grid" slot="menu-header">
            <div class="chi-col -w--4">Enterprise ID</div>
            <div class="chi-col -w--7">Enterprise Name</div>
          </div>
          <a class="chi-dropdown__menu-item -active" slot="menu">
            <div class="chi-grid">
              <div class="chi-col -w--4">1234567</div>
              <div class="chi-col -w--7">Acme Incorporated</div>
            </div>
          </a>
          <a class="chi-dropdown__menu-item" slot="menu">
            <div class="chi-grid">
              <div class="chi-col -w--4">1234568</div>
              <div class="chi-col -w--7">Acme Incorporated</div>
            </div>
          </a>
          <a class="chi-dropdown__menu-item" slot="menu">
            <div class="chi-grid">
              <div class="chi-col -w--4">1234569</div>
              <div class="chi-col -w--7">Acme Incorporated</div>
              <div class="chi-col -w--1"><chi-spinner></chi-spinner></div>
            </div>
          </a>
          <a class="chi-dropdown__menu-item" slot="menu">
            <div class="chi-grid">
              <div class="chi-col -w--4">1234560</div>
              <div class="chi-col -w--7">Acme Incorporated</div>
            </div>
          </a>
          <div class="chi-divider" slot="menu-footer"></div>
          <chi-link slot="menu-footer">Manage My Enterprises</chi-link>
        </chi-dropdown>
      </div>
      <div class="chi-divider -my--0"></div>
      <ul class="chi-mobile-nav__list">
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="dashboard"></chi-icon>
            <span>Dashboard</span>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="bell"></chi-icon>
            <span>Alerts & Notifications</span>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link class="-active" href="#services-menu">
            <chi-icon icon="list-alt"></chi-icon>
            <span>Services</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link href="#apis-menu">
            <chi-icon icon="api"></chi-icon>
            <span>APIs</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="chart-bar"></chi-icon>
            <span>Monitoring & Reports</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="mail-open-dollar"></chi-icon>
            <span>Billing</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="users"></chi-icon>
            <span>Admin</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="life-ring"></chi-icon>
            <span>Support</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
      </ul>
      <div class="chi-divider -my--0"></div>
      <ul class="chi-mobile-nav__list">
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="circle-question"></chi-icon>
            <span>[Portal Name] Help</span>
            <chi-icon icon="external-link" size="sm"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="compose"></chi-icon>
            <span>Contact Lumen</span>
            <chi-icon icon="external-link" size="sm"></chi-icon>
          </chi-link>
        </li>
      </ul>
      <div class="chi-divider -my--0"></div>
      <ul class="chi-mobile-nav__list">
        <li class="chi-mobile-nav__item">
          <span class="chi-mobile-nav__email">jamie.johnson@company.com</span>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="user"></chi-icon>
            <span>My Profile</span>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="logout"></chi-icon>
            <span>Sign out</span>
          </chi-link>
        </li>
      </ul>
    </div>
    <div id="services-menu">
      <ul class="chi-mobile-nav__list">
        <li class="chi-mobile-nav__item">
          <chi-link href="https://lib.lumen.com/"> Manage Services </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link> Add Services </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link> Order Status </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <span>Service Tools</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <span>Service Requests</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link class="-active" href="#quotes-menu">
            <span>Quotes</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link href="#service-portals-menu">
            <span>Service Portals</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
      </ul>
    </div>
    <div id="apis-menu">
      <ul class="chi-mobile-nav__list">
        <li class="chi-mobile-nav__item">
          <chi-link href="#view-apis-menu">
            <span>View APIs</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link> Edit APIs </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link> API Settings </chi-link>
        </li>
      </ul>
    </div>
    <div id="quotes-menu">
      <ul class="chi-mobile-nav__list">
        <li class="chi-mobile-nav__item">
          <chi-link class="-active">View Quotes</chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>Create Quotes</chi-link>
        </li>
      </ul>
    </div>
    <div id="service-portals-menu">
      <ul class="chi-mobile-nav__list">
        <li class="chi-mobile-nav__item">
          <chi-link>Service Portal 1</chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>Service Portal 2</chi-link>
        </li>
      </ul>
    </div>
    <div id="view-apis-menu">
      <ul class="chi-mobile-nav__list">
        <li class="chi-mobile-nav__item">
          <chi-link>API 1</chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>API 2</chi-link>
        </li>
      </ul>
    </div>
  </chi-drawer>
</div>

<script>
  const enterpriseDropdown = document.getElementById('enterprise-dropdown');
  const mobileNav = document.getElementById('mobile-nav');
  const mobileNavTrigger = document.getElementById('mobile-nav-trigger');
  const mobileNavDrawer = document.getElementById('mobile-nav-drawer');

  chi.globalMobileNav(mobileNav, mobileNavTrigger, mobileNavDrawer, enterpriseDropdown);

  enterpriseDropdown.addEventListener('chiDropdownItemSelected', (e) => {
    // Handle enterprise selection change with custom logic
  });
<\/script>
`,Hi=T({__name:"_base_connect",setup(y){const u=[{active:!0,id:"webcomponent",label:"Web Component"},{disabled:!0,id:"htmlblueprint",label:"HTML Blueprint"}],d=g("mobile-nav"),h=g("mobile-nav-trigger"),v=g("mobile-nav-drawer"),_=g("enterprise-dropdown"),k=o=>{o.target.closest('a[href^="#"]')&&o.preventDefault()},I=[{icon:"dashboard",label:"Dashboard"},{icon:"bell",label:"Alerts & Notifications"},{icon:"list-alt",label:"Services",href:"#services-menu",hasChevron:!0,active:!0},{icon:"api",label:"APIs",href:"#apis-menu",hasChevron:!0},{icon:"chart-bar",label:"Monitoring & Reports",hasChevron:!0},{icon:"mail-open-dollar",label:"Billing",hasChevron:!0},{icon:"users",label:"Admin",hasChevron:!0},{icon:"life-ring",label:"Support",hasChevron:!0}],A=[{icon:"circle-question",label:"[Portal Name] Help",showRightIcon:!0},{icon:"compose",label:"Contact Lumen",showRightIcon:!0}],q=[{label:"Manage Services",href:"https://lib.lumen.com/"},{label:"Add Services"},{label:"Order Status"},{label:"Service Tools",hasChevron:!0},{label:"Service Requests",hasChevron:!0},{label:"Quotes",href:"#quotes-menu",hasChevron:!0,active:!0},{label:"Service Portals",href:"#service-portals-menu",hasChevron:!0}],E=[{label:"View APIs",href:"#view-apis-menu",hasChevron:!0},{label:"Edit APIs"},{label:"API Settings"}],D=[{label:"View Quotes",active:!0},{label:"Create Quotes"}],M=[{label:"Service Portal 1"},{label:"Service Portal 2"}],P=[{label:"API 1"},{label:"API 2"}],x=z("1234567"),S=O(()=>`Enterprise ID: ${x.value}`),B=[{id:"1234567",name:"Acme Incorporated",active:!0},{id:"1234568",name:"Acme Incorporated"},{id:"1234569",name:"Acme Incorporated",spinner:!0},{id:"1234560",name:"Acme Incorporated"}],V=o=>(o||"").split(`
`)[0];async function L(o){const c=V(o.detail);o.currentTarget.resetSelection(),x.value=c}$([d,h,v,_],()=>{d.value&&h.value&&v.value&&_.value&&chi.globalMobileNav(d.value,h.value,v.value,_.value)});const Q={webcomponent:Ci,htmlblueprint:""};return(o,c)=>{const R=H,j=N;return n(),f(j,{title:"Base",id:"base-connect",tabs:u},{example:p(()=>[i("chi-button",U,[...c[1]||(c[1]=[i("chi-icon",{icon:"menu"},null,-1),i("span",null,"Click to open Mobile Nav",-1)])],512),c[10]||(c[10]=i("p",{class:"-text -mb--3"},"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus eu dignissim nisi, gravida pharetra elit. Etiam eu urna orci. Nulla et lorem eleifend, ultrices massa id, molestie urna. Nulla nec quam in turpis fermentum dictum vitae ac nibh. Suspendisse lacus nisi, sollicitudin in commodo quis, euismod id enim. Donec semper nunc et tellus convallis, tristique varius turpis gravida. Quisque hendrerit magna ac bibendum molestie. Nullam scelerisque libero vitae lorem dignissim ullamcorper. Integer mollis auctor enim vel molestie. Etiam id vestibulum augue, vitae dapibus quam. Nunc tincidunt aliquet lacus nec malesuada. Donec ultricies augue non lorem eleifend, eget ullamcorper lacus elementum. Donec condimentum enim nec justo auctor, nec bibendum ipsum dapibus.",-1)),c[11]||(c[11]=i("p",{class:"-text -mb--3"},"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus eu dignissim nisi, gravida pharetra elit. Etiam eu urna orci. Nulla et lorem eleifend, ultrices massa id, molestie urna. Nulla nec quam in turpis fermentum dictum vitae ac nibh. Suspendisse lacus nisi, sollicitudin in commodo quis, euismod id enim. Donec semper nunc et tellus convallis, tristique varius turpis gravida. Quisque hendrerit magna ac bibendum molestie. Nullam scelerisque libero vitae lorem dignissim ullamcorper. Integer mollis auctor enim vel molestie. Etiam id vestibulum augue, vitae dapibus quam. Nunc tincidunt aliquet lacus nec malesuada. Donec ultricies augue non lorem eleifend, eget ullamcorper lacus elementum. Donec condimentum enim nec justo auctor, nec bibendum ipsum dapibus.",-1)),i("div",X,[i("chi-drawer",{ref:"mobile-nav-drawer",onClickCapture:k},[i("div",Y,[i("div",Z,[i("chi-dropdown",{class:"enterprise-id-switcher",ref:"enterprise-dropdown",position:"bottom",size:"sm","select-mode":"","retain-selection":b(S),button:b(S),"on:chiDropdownItemSelected":L},[c[3]||(c[3]=i("div",{slot:"menu-header"},[i("div",{class:"chi-grid"},[i("div",{class:"chi-col -w--4"},"Enterprise ID"),i("div",{class:"chi-col -w--7"},"Enterprise Name")])],-1)),(n(),a(l,null,t(B,e=>i("a",{class:m(["chi-dropdown__menu-item",{"-active":e.id===b(x)}]),key:e.id,slot:"menu",href:"#",onClick:c[0]||(c[0]=F(()=>{},["prevent"]))},[i("div",ei,[i("div",ci,s(e.id),1),i("div",ni,s(e.name),1),e.spinner?(n(),a("div",ai,[...c[2]||(c[2]=[i("chi-spinner",null,null,-1)])])):r("",!0)])],2)),64)),c[4]||(c[4]=i("div",{class:"chi-divider",slot:"menu-footer"},null,-1)),c[5]||(c[5]=i("chi-link",{slot:"menu-footer"},"Manage My Enterprises",-1))],40,ii)]),c[6]||(c[6]=i("div",{class:"chi-divider -my--0"},null,-1)),i("ul",si,[(n(),a(l,null,t(I,e=>i("li",{class:"chi-mobile-nav__item",key:e.label},[i("chi-link",{href:e.href,class:m({"-active":e.active})},[e.icon?(n(),a("chi-icon",{key:0,icon:e.icon},null,8,li)):r("",!0),i("span",null,s(e.label),1),e.hasChevron?(n(),a("chi-icon",ti)):r("",!0)],10,oi)])),64))]),c[7]||(c[7]=i("div",{class:"chi-divider -my--0"},null,-1)),i("ul",ri,[(n(),a(l,null,t(A,e=>i("li",{class:"chi-mobile-nav__item",key:e.label},[i("chi-link",{href:e.href},[i("chi-icon",{icon:e.icon},null,8,hi),i("span",null,s(e.label),1),e.showRightIcon?(n(),a("chi-icon",mi)):r("",!0)],8,di)])),64))]),c[8]||(c[8]=i("div",{class:"chi-divider -my--0"},null,-1)),c[9]||(c[9]=i("ul",{class:"chi-mobile-nav__list"},[i("li",{class:"chi-mobile-nav__item"},[i("span",{class:"chi-mobile-nav__email"},"jamie.johnson@company.com")]),i("li",{class:"chi-mobile-nav__item"},[i("chi-link",null,[i("chi-icon",{icon:"user"}),i("span",null,"My Profile")])]),i("li",{class:"chi-mobile-nav__item"},[i("chi-link",null,[i("chi-icon",{icon:"logout"}),i("span",null,"Sign out")])])],-1))]),i("div",ui,[i("ul",vi,[(n(),a(l,null,t(q,e=>i("li",{class:"chi-mobile-nav__item",key:e.label},[i("chi-link",{href:e.href,class:m({"-active":e.active})},[i("span",null,s(e.label),1),e.hasChevron?(n(),a("chi-icon",pi)):r("",!0)],10,_i)])),64))])]),i("div",bi,[i("ul",gi,[(n(),a(l,null,t(E,e=>i("li",{class:"chi-mobile-nav__item",key:e.label},[i("chi-link",{href:e.href,class:m({"-active":e.active})},[i("span",null,s(e.label),1),e.hasChevron?(n(),a("chi-icon",fi)):r("",!0)],10,wi)])),64))])]),i("div",ki,[i("ul",Ii,[(n(),a(l,null,t(D,e=>i("li",{class:"chi-mobile-nav__item",key:e.label},[i("chi-link",{class:m({"-active":e.active})},s(e.label),3)])),64))])]),i("div",xi,[i("ul",Ti,[(n(),a(l,null,t(M,e=>i("li",{class:"chi-mobile-nav__item",key:e.label},[i("chi-link",{class:m({"-active":e.active})},s(e.label),3)])),64))])]),i("div",yi,[i("ul",Si,[(n(),a(l,null,t(P,e=>i("li",{class:"chi-mobile-nav__item",key:e.label},[i("chi-link",{class:m({"-active":e.active})},s(e.label),3)])),64))])])],544)],512)]),"code-webcomponent":p(()=>[w(R,{class:"html",lang:"html",code:Q.webcomponent},null,8,["code"])]),_:1})}}}),Ni=T({__name:"_interaction",setup(y){const u=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],d={webcomponent:"",htmlblueprint:`<!-- Trigger -->
<button class="chi-button -icon -flat" id="mobile-navigation-interaction-trigger" data-target="#mobile-navigation-example" aria-label="Open Menu">
  <div class="chi-button__content">
    <i class="chi-icon icon-menu -sm--2" aria-hidden="true"></i>
  </div>
</button>

<!-- Mobile Navigation -->
<div class="chi-mobile-nav" id="mobile-navigation-example">
  <div class="chi-backdrop -closed -position--absolute -animated">
    <div class="chi-backdrop__wrapper">
      <div class="chi-drawer -left -animated chi-mobile-nav__first-level -position--absolute">
        <div class="-position--relative">
          <div class="chi-mobile-nav__first-level-content -w--100">
            <div class="chi-drawer__header chi-mobile-nav__header">
              <button
                class="chi-button -flat chi-dropdown__trigger -animate -no-hover -b--transparent"
                id="button-site-menu2"
                data-target="dropdown-2-menu"
              >
                Control Center
              </button>
              <button class="chi-button -icon -close" aria-label="Close">
                <div class="chi-button__content">
                  <i class="chi-icon icon-x" aria-hidden="true"></i>
                </div>
              </button>
            </div>
            <div class="chi-mobile-nav__dropdown">
              <div
                class="chi-dropdown__menu -list chi-mobile-nav__dropdown-content"
                id="dropdown-2-menu"
              >
                <a class="chi-dropdown__menu-item -h--auto -active" href="#">
                  <span class="chi-dropdown__menu-item_title">App name</span>
                  <span class="chi-dropdown__menu-item_text">
                    App description
                  </span>
                </a>
                <a class="chi-dropdown__menu-item -h--auto" href="#">
                  <span class="chi-dropdown__menu-item_title">App name 2</span>
                  <span class="chi-dropdown__menu-item_text">
                    App description
                  </span>
                </a>
                <a class="chi-dropdown__menu-item -h--auto" href="#">
                  <span class="chi-dropdown__menu-item_title">App name 3</span>
                  <span class="chi-dropdown__menu-item_text">
                    App description
                  </span>
                </a>
              </div>
            </div>
            <div class="chi-drawer__content chi-mobile-nav__content">
              <div class="chi-mobile-nav__user">
                <div class="chi-mobile-nav__user-name">
                  <span>Alessandro Ray</span>
                </div>
                <button
                  class="chi-button -flat chi-dropdown__trigger -px--1 -animate -no-hover -b--transparent -text--normal"
                  id="button-user-menu2"
                  data-target="dropdown-3-menu"
                >
                  Menu
                </button>
              </div>
              <div class="chi-mobile-nav__dropdown">
                <div
                  class="chi-dropdown__menu chi-mobile-nav__dropdown-content"
                  id="dropdown-3-menu"
                >
                  <a class="chi-dropdown__menu-item" href="#">
                    <i class="chi-icon icon-user" aria-hidden="true"></i>
                    <span>Item 1</span>
                  </a>
                  <a class="chi-dropdown__menu-item" href="#">
                    <i class="chi-icon icon-logout" aria-hidden="true"></i>
                    <span>Item 2</span>
                  </a>
                </div>
              </div>
              <ul class="chi-tabs -vertical -icons">
                <li class="-active">
                  <a
                    href="#second-level-1"
                    class=" chi-drawer__subitem-list-trigger"
                  >
                    <i class="chi-icon icon-atom" aria-hidden="true"></i>
                    <span>Toggle me</span>
                  </a>
                </li>
                <li>
                  <a
                    href="#second-level-2"
                    class=" chi-drawer__subitem-list-trigger"
                  >
                    <i class="chi-icon icon-atom" aria-hidden="true"></i>
                    <span>Toggle me</span>
                  </a>
                </li>
                <li>
                  <a href="#tab-link">
                    <i class="chi-icon icon-atom" aria-hidden="true"></i>
                    <span>Tab link</span>
                  </a>
                </li>
                <li>
                  <a href="#tab-link">
                    <i class="chi-icon icon-atom" aria-hidden="true"></i>
                    <span>Tab link</span>
                  </a>
                </li>
              </ul>
              <div class="chi-divider"></div>
              <ul class="chi-tabs -vertical -icons">
                <li>
                  <a class="-text--primary" href="#tab-link">
                    <i class="chi-icon icon-user" aria-hidden="true"></i>
                    <span>My Profile</span>
                  </a>
                </li>
                <li>
                  <a class="-text--primary" href="#tab-link">
                    <i
                      class="chi-icon icon-bell-settings-outline"
                      aria-hidden="true"
                    ></i>
                    <span>Notification Settings</span>
                  </a>
                </li>
                <li>
                  <a class="-text--primary" href="#tab-link">
                    <i class="chi-icon icon-logout" aria-hidden="true"></i>
                    <span>Sign Out</span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="chi-mobile-nav__drawers">
          <div
            class="chi-drawer -right -position--absolute"
            id="second-level-1"
          >
            <div class="chi-drawer__header chi-mobile-nav__header">
              <button
                class="chi-button -flat -icon -no-hover -back"
                aria-label="Back"
              >
                <div class="chi-button__content">
                  <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
                </div>
              </button>
              <div class="chi-mobile-nav__header-title">Inventory</div>
              <button class="chi-button -icon -close" aria-label="Close">
                <div class="chi-button__content">
                  <i class="chi-icon icon-x" aria-hidden="true"></i>
                </div>
              </button>
            </div>
            <div class="chi-drawer__content chi-mobile-nav__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <div class="chi-accordion">
                      <div class="chi-accordion__item">
                        <button class="chi-accordion__trigger">
                          <div class="chi-accordion__title">Item 1.1</div>
                          <i
                            class="chi-icon icon-chevron-down"
                            aria-hidden="true"
                          ></i>
                        </button>
                        <div class="chi-accordion__content">
                          <a href="#exampleHashTarget">
                            <span>Item 1.1.1</span>
                          </a>
                          <a href="#exampleHashTarget">
                            <span>Item 1.1.2</span>
                          </a>
                        </div>
                      </div>
                      <div class="chi-accordion__item">
                        <button class="chi-accordion__trigger">
                          <div class="chi-accordion__title">Item 1.2</div>
                          <i
                            class="chi-icon icon-chevron-down"
                            aria-hidden="true"
                          ></i>
                        </button>
                        <div class="chi-accordion__content">
                          <a href="#exampleHashTarget">
                            <span>Item 1.2.1</span>
                          </a>
                          <a href="#exampleHashTarget">
                            <span>Item 1.2.2</span>
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="chi-accordion__item -active -expanded">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <div class="chi-accordion">
                      <div class="chi-accordion__item">
                        <button class="chi-accordion__trigger">
                          <div class="chi-accordion__title">Item 2.1</div>
                          <i
                            class="chi-icon icon-chevron-down"
                            aria-hidden="true"
                          ></i>
                        </button>
                        <div class="chi-accordion__content">
                          <a href="#exampleHashTarget">
                            <span>Item 2.1.1</span>
                          </a>
                          <a href="#exampleHashTarget">
                            <span>Item 2.1.2</span>
                          </a>
                        </div>
                      </div>
                      <div class="chi-accordion__item -active -expanded">
                        <button class="chi-accordion__trigger">
                          <div class="chi-accordion__title">Item 2.2</div>
                          <i
                            class="chi-icon icon-chevron-down"
                            aria-hidden="true"
                          ></i>
                        </button>
                        <div class="chi-accordion__content">
                          <a href="#exampleHashTarget">
                            <span>Item 2.2.1</span>
                          </a>
                          <a class="-active" href="#exampleHashTarget">
                            <span>Item 2.2.2</span>
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <a href="#exampleHashTarget">
                  <span>
                    External
                    <i
                      class="chi-icon icon-external-link -xs"
                      aria-hidden="true"
                    ></i>
                  </span>
                </a>
              </div>
            </div>
          </div>
          <div
            class="chi-drawer -right -position--absolute"
            id="second-level-2"
          >
            <div class="chi-drawer__header chi-mobile-nav__header">
              <button
                class="chi-button -flat -icon -no-hover -back"
                aria-label="Back"
              >
                <div class="chi-button__content">
                  <i class="chi-icon icon-chevron-left" aria-hidden="true"></i>
                </div>
              </button>
              <div class="chi-mobile-nav__header-title">Inventory</div>
              <button class="chi-button -icon -close" aria-label="Close">
                <div class="chi-button__content">
                  <i class="chi-icon icon-x" aria-hidden="true"></i>
                </div>
              </button>
            </div>
            <div class="chi-drawer__content chi-mobile-nav__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <div class="chi-accordion">
                      <div class="chi-accordion__item">
                        <button class="chi-accordion__trigger">
                          <div class="chi-accordion__title">Item 1.1</div>
                          <i
                            class="chi-icon icon-chevron-down"
                            aria-hidden="true"
                          ></i>
                        </button>
                        <div class="chi-accordion__content">
                          <a href="#exampleHashTarget">
                            <span>Item 1.1.1</span>
                          </a>
                          <a href="#exampleHashTarget">
                            <span>Item 1.1.2</span>
                          </a>
                        </div>
                      </div>
                      <div class="chi-accordion__item">
                        <button class="chi-accordion__trigger">
                          <div class="chi-accordion__title">Item 1.2</div>
                          <i
                            class="chi-icon icon-chevron-down"
                            aria-hidden="true"
                          ></i>
                        </button>
                        <div class="chi-accordion__content">
                          <a href="#exampleHashTarget">
                            <span>Item 1.2.1</span>
                          </a>
                          <a href="#exampleHashTarget">
                            <span>Item 1.2.2</span>
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <div class="chi-accordion">
                      <div class="chi-accordion__item">
                        <button class="chi-accordion__trigger">
                          <div class="chi-accordion__title">Item 2.1</div>
                          <i
                            class="chi-icon icon-chevron-down"
                            aria-hidden="true"
                          ></i>
                        </button>
                        <div class="chi-accordion__content">
                          <a href="#exampleHashTarget">
                            <span>Item 2.1.1</span>
                          </a>
                          <a href="#exampleHashTarget">
                            <span>Item 2.1.2</span>
                          </a>
                        </div>
                      </div>
                      <div class="chi-accordion__item">
                        <button class="chi-accordion__trigger">
                          <div class="chi-accordion__title">Item 2.2</div>
                          <i
                            class="chi-icon icon-chevron-down"
                            aria-hidden="true"
                          ></i>
                        </button>
                        <div class="chi-accordion__content">
                          <a href="#exampleHashTarget">
                            <span>Item 2.2.1</span>
                          </a>
                          <a href="#exampleHashTarget">
                            <span>Item 2.2.2</span>
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <a href="#exampleHashTarget">
                  <span>
                    External
                    <i
                      class="chi-icon icon-external-link -xs"
                      aria-hidden="true"
                    ></i>
                  </span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- JavaScript -->
<script>
  chi.mobilenav(document.querySelector("#mobile-navigation-interaction-trigger"));
<\/script>`};return J(async()=>{await W(),chi.mobilenav(document.querySelector("#mobile-navigation-interaction-trigger"))}),(h,v)=>{const _=H,k=K,I=N;return n(),f(I,{title:"Interaction",id:"interaction",padding:"-p--0",tabs:u},{example:p(()=>[...v[0]||(v[0]=[i("div",{class:"-mb--3 -overflow--hidden"},[i("div",{class:"-position--relative -z--0 -overflow--hidden",style:{height:"25rem"}},[i("div",{class:"-p--3"},[i("div",{class:"-d--flex -align-items--center"},[i("button",{class:"chi-button -icon -flat",id:"mobile-navigation-interaction-trigger","data-target":"#mobile-navigation-example","aria-label":"Open Menu"},[i("div",{class:"chi-button__content"},[i("i",{class:"chi-icon icon-menu -sm--2","aria-hidden":"true"})])]),i("b",{class:"-ml--2"},"Click menu button to open Mobile navigation")]),i("p",{class:"-text -mb--3"},"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus eu dignissim nisi, gravida pharetra elit. Etiam eu urna orci. Nulla et lorem eleifend, ultrices massa id, molestie urna. Nulla nec quam in turpis fermentum dictum vitae ac nibh. Suspendisse lacus nisi, sollicitudin in commodo quis, euismod id enim. Donec semper nunc et tellus convallis, tristique varius turpis gravida. Quisque hendrerit magna ac bibendum molestie. Nullam scelerisque libero vitae lorem dignissim ullamcorper. Integer mollis auctor enim vel molestie. Etiam id vestibulum augue, vitae dapibus quam. Nunc tincidunt aliquet lacus nec malesuada. Donec ultricies augue non lorem eleifend, eget ullamcorper lacus elementum. Donec condimentum enim nec justo auctor, nec bibendum ipsum dapibus."),i("p",{class:"-text -mb--3"},"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus eu dignissim nisi, gravida pharetra elit. Etiam eu urna orci. Nulla et lorem eleifend, ultrices massa id, molestie urna. Nulla nec quam in turpis fermentum dictum vitae ac nibh. Suspendisse lacus nisi, sollicitudin in commodo quis, euismod id enim. Donec semper nunc et tellus convallis, tristique varius turpis gravida. Quisque hendrerit magna ac bibendum molestie. Nullam scelerisque libero vitae lorem dignissim ullamcorper. Integer mollis auctor enim vel molestie. Etiam id vestibulum augue, vitae dapibus quam. Nunc tincidunt aliquet lacus nec malesuada. Donec ultricies augue non lorem eleifend, eget ullamcorper lacus elementum. Donec condimentum enim nec justo auctor, nec bibendum ipsum dapibus.")]),i("div",{class:"chi-mobile-nav",id:"mobile-navigation-example"},[i("div",{class:"chi-backdrop -closed -position--absolute"},[i("div",{class:"chi-backdrop__wrapper"},[i("div",{class:"chi-drawer -left -animated chi-mobile-nav__first-level -position--absolute"},[i("div",{class:"-position--relative"},[i("div",{class:"chi-mobile-nav__first-level-content -w--100"},[i("div",{class:"chi-drawer__header chi-mobile-nav__header"},[i("button",{class:"chi-button -flat chi-dropdown__trigger -animate -no-hover -b--transparent",id:"button-site-menu2","data-target":"dropdown-2-menu"},"Control Center"),i("button",{class:"chi-button -icon -close","aria-label":"Close"},[i("div",{class:"chi-button__content"},[i("i",{class:"chi-icon icon-x","aria-hidden":"true"})])])]),i("div",{class:"chi-mobile-nav__dropdown"},[i("div",{class:"chi-dropdown__menu -list chi-mobile-nav__dropdown-content",id:"dropdown-2-menu"},[i("a",{class:"chi-dropdown__menu-item -h--auto -active",href:"#"},[i("span",{class:"chi-dropdown__menu-item_title"},"App name"),i("span",{class:"chi-dropdown__menu-item_text"},"App description")]),i("a",{class:"chi-dropdown__menu-item -h--auto",href:"#"},[i("span",{class:"chi-dropdown__menu-item_title"},"App name 2"),i("span",{class:"chi-dropdown__menu-item_text"},"App description")]),i("a",{class:"chi-dropdown__menu-item -h--auto",href:"#"},[i("span",{class:"chi-dropdown__menu-item_title"},"App name 3"),i("span",{class:"chi-dropdown__menu-item_text"},"App description")])])]),i("div",{class:"chi-drawer__content chi-mobile-nav__content"},[i("div",{class:"chi-mobile-nav__user"},[i("div",{class:"chi-mobile-nav__user-name"},[i("span",null,"Alessandro Ray")]),i("button",{class:"chi-button -flat chi-dropdown__trigger -px--1 -animate -no-hover -b--transparent -text--normal",id:"button-user-menu2","data-target":"dropdown-3-menu"},"Menu")]),i("div",{class:"chi-mobile-nav__dropdown"},[i("div",{class:"chi-dropdown__menu chi-mobile-nav__dropdown-content",id:"dropdown-3-menu"},[i("a",{class:"chi-dropdown__menu-item",href:"#"},[i("i",{class:"chi-icon icon-user","aria-hidden":"true"}),i("span",null,"Item 1")]),i("a",{class:"chi-dropdown__menu-item",href:"#"},[i("i",{class:"chi-icon icon-logout","aria-hidden":"true"}),i("span",null,"Item 2")])])]),i("ul",{class:"chi-tabs -vertical -icons"},[i("li",{class:"-active"},[i("a",{href:"#second-level-1"},[i("i",{class:"chi-icon icon-atom","aria-hidden":"true"}),i("span",null,"Toggle me")])]),i("li",null,[i("a",{href:"#second-level-2"},[i("i",{class:"chi-icon icon-atom","aria-hidden":"true"}),i("span",null,"Toggle me")])]),i("li",null,[i("a",{href:"#tab-link"},[i("i",{class:"chi-icon icon-atom","aria-hidden":"true"}),i("span",null,"Tab link")])]),i("li",null,[i("a",{href:"#tab-link"},[i("i",{class:"chi-icon icon-atom","aria-hidden":"true"}),i("span",null,"Tab link")])])]),i("div",{class:"chi-divider"}),i("ul",{class:"chi-tabs -vertical -icons"},[i("li",null,[i("a",{class:"-text--primary",href:"#tab-link"},[i("i",{class:"chi-icon icon-user","aria-hidden":"true"}),i("span",null,"My Profile")])]),i("li",null,[i("a",{class:"-text--primary",href:"#tab-link"},[i("i",{class:"chi-icon icon-bell-settings-outline","aria-hidden":"true"}),i("span",null,"Notification Settings")])]),i("li",null,[i("a",{class:"-text--primary",href:"#tab-link"},[i("i",{class:"chi-icon icon-logout","aria-hidden":"true"}),i("span",null,"Sign Out")])])])])])]),i("div",{class:"chi-mobile-nav__drawers"},[i("div",{class:"chi-drawer -right -position--absolute",id:"second-level-1"},[i("div",{class:"chi-drawer__header chi-mobile-nav__header"},[i("button",{class:"chi-button -flat -icon -no-hover -back","aria-label":"Back"},[i("div",{class:"chi-button__content"},[i("i",{class:"chi-icon icon-chevron-left","aria-hidden":"true"})])]),i("div",{class:"chi-mobile-nav__header-title"},"Inventory"),i("button",{class:"chi-button -icon -close","aria-label":"Close"},[i("div",{class:"chi-button__content"},[i("i",{class:"chi-icon icon-x","aria-hidden":"true"})])])]),i("div",{class:"chi-drawer__content chi-mobile-nav__content"},[i("div",{class:"chi-accordion"},[i("div",{class:"chi-accordion__item"},[i("button",{class:"chi-accordion__trigger"},[i("div",{class:"chi-accordion__title"},"Item 1"),i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"})]),i("div",{class:"chi-accordion__content"},[i("div",{class:"chi-accordion"},[i("div",{class:"chi-accordion__item"},[i("button",{class:"chi-accordion__trigger"},[i("div",{class:"chi-accordion__title"},"Item 1.1"),i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"})]),i("div",{class:"chi-accordion__content"},[i("a",{href:"#exampleHashTarget"},[i("span",null,"Item 1.1.1")]),i("a",{href:"#exampleHashTarget"},[i("span",null,"Item 1.1.2")])])]),i("div",{class:"chi-accordion__item"},[i("button",{class:"chi-accordion__trigger"},[i("div",{class:"chi-accordion__title"},"Item 1.2"),i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"})]),i("div",{class:"chi-accordion__content"},[i("a",{href:"#exampleHashTarget"},[i("span",null,"Item 1.2.1")]),i("a",{href:"#exampleHashTarget"},[i("span",null,"Item 1.2.2")])])])])])]),i("div",{class:"chi-accordion__item -active -expanded"},[i("button",{class:"chi-accordion__trigger"},[i("div",{class:"chi-accordion__title"},"Item 2"),i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"})]),i("div",{class:"chi-accordion__content"},[i("div",{class:"chi-accordion"},[i("div",{class:"chi-accordion__item"},[i("button",{class:"chi-accordion__trigger"},[i("div",{class:"chi-accordion__title"},"Item 2.1"),i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"})]),i("div",{class:"chi-accordion__content"},[i("a",{href:"#exampleHashTarget"},[i("span",null,"Item 2.1.1")]),i("a",{href:"#exampleHashTarget"},[i("span",null,"Item 2.1.2")])])]),i("div",{class:"chi-accordion__item -active -expanded"},[i("button",{class:"chi-accordion__trigger"},[i("div",{class:"chi-accordion__title"},"Item 2.2"),i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"})]),i("div",{class:"chi-accordion__content"},[i("a",{href:"#exampleHashTarget"},[i("span",null,"Item 2.2.1")]),i("a",{class:"-active",href:"#exampleHashTarget"},[i("span",null,"Item 2.2.2")])])])])])]),i("a",{href:"#exampleHashTarget"},[i("span",null,[C("External"),i("i",{class:"chi-icon icon-external-link -xs","aria-hidden":"true"})])])])])]),i("div",{class:"chi-drawer -right -position--absolute",id:"second-level-2"},[i("div",{class:"chi-drawer__header chi-mobile-nav__header"},[i("button",{class:"chi-button -flat -icon -no-hover -back","aria-label":"Back"},[i("div",{class:"chi-button__content"},[i("i",{class:"chi-icon icon-chevron-left","aria-hidden":"true"})])]),i("div",{class:"chi-mobile-nav__header-title"},"Inventory"),i("button",{class:"chi-button -icon -close","aria-label":"Close"},[i("div",{class:"chi-button__content"},[i("i",{class:"chi-icon icon-x","aria-hidden":"true"})])])]),i("div",{class:"chi-drawer__content chi-mobile-nav__content"},[i("div",{class:"chi-accordion"},[i("div",{class:"chi-accordion__item"},[i("button",{class:"chi-accordion__trigger"},[i("div",{class:"chi-accordion__title"},"Item 1"),i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"})]),i("div",{class:"chi-accordion__content"},[i("div",{class:"chi-accordion"},[i("div",{class:"chi-accordion__item"},[i("button",{class:"chi-accordion__trigger"},[i("div",{class:"chi-accordion__title"},"Item 1.1"),i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"})]),i("div",{class:"chi-accordion__content"},[i("a",{href:"#exampleHashTarget"},[i("span",null,"Item 1.1.1")]),i("a",{href:"#exampleHashTarget"},[i("span",null,"Item 1.1.2")])])]),i("div",{class:"chi-accordion__item"},[i("button",{class:"chi-accordion__trigger"},[i("div",{class:"chi-accordion__title"},"Item 1.2"),i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"})]),i("div",{class:"chi-accordion__content"},[i("a",{href:"#exampleHashTarget"},[i("span",null,"Item 1.2.1")]),i("a",{href:"#exampleHashTarget"},[i("span",null,"Item 1.2.2")])])])])])]),i("div",{class:"chi-accordion__item"},[i("button",{class:"chi-accordion__trigger"},[i("div",{class:"chi-accordion__title"},"Item 2"),i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"})]),i("div",{class:"chi-accordion__content"},[i("div",{class:"chi-accordion"},[i("div",{class:"chi-accordion__item"},[i("button",{class:"chi-accordion__trigger"},[i("div",{class:"chi-accordion__title"},"Item 2.1"),i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"})]),i("div",{class:"chi-accordion__content"},[i("a",{href:"#exampleHashTarget"},[i("span",null,"Item 2.1.1")]),i("a",{href:"#exampleHashTarget"},[i("span",null,"Item 2.1.2")])])]),i("div",{class:"chi-accordion__item"},[i("button",{class:"chi-accordion__trigger"},[i("div",{class:"chi-accordion__title"},"Item 2.2"),i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"})]),i("div",{class:"chi-accordion__content"},[i("a",{href:"#exampleHashTarget"},[i("span",null,"Item 2.2.1")]),i("a",{href:"#exampleHashTarget"},[i("span",null,"Item 2.2.2")])])])])])]),i("a",{href:"#exampleHashTarget"},[i("span",null,[C("External"),i("i",{class:"chi-icon icon-external-link -xs","aria-hidden":"true"})])])])])])])])])])])])],-1)])]),"code-webcomponent":p(()=>[w(_,{class:"html",lang:"html",code:d.webcomponent},null,8,["code"])]),"code-htmlblueprint":p(()=>[w(k),w(_,{lang:"html",code:d.htmlblueprint},null,8,["code"])]),_:1})}}}),Mi=T({__name:"index",setup(y){const u=G();return(d,h)=>(n(),a("div",null,[h[0]||(h[0]=i("h2",null,"Examples",-1)),["connect"].includes(b(u))?(n(),f(Hi,{key:0})):r("",!0),["connect"].includes(b(u))?r("",!0):(n(),f(Ni,{key:1}))]))}});export{Mi as _};
