import{am as n,an as o}from"./DBXeQHmC.js";const e=(s,t)=>{const{size:m}=t.dynamicComputedProps,r=[o("size",m,m!=="md")],a=n(t,r);return`<${s}${a}></${s}>`};export{e as snippet};
