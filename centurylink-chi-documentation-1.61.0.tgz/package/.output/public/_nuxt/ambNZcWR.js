import{_ as d}from"./DnPF01B5.js";import{_ as b}from"./CdcsEwU-.js";import{e as p,i as f,o as r,w as l,b as i,a as e,c as g}from"./DBXeQHmC.js";const x=`<chi-customize-panel id="customize-panel-example">
  <chi-button slot="trigger" variant="flat" type="icon">
    <chi-icon icon="table-column-settings" size="sm--2"></chi-icon>
    <span>Open panel</span>
  </chi-button>
</chi-customize-panel>

<script>
  const customizePanel = document.getElementById('customize-panel-example');

  customizePanel.items = [
    { label: 'Option 1', description: 'lorem ipsum dolor amet', selected: true },
    { label: 'Option 2', description: 'lorem ipsum dolor amet', selected: false },
    { label: 'Option 3', description: 'lorem ipsum dolor amet', selected: true },
    { label: 'Option 4', description: 'lorem ipsum dolor amet', selected: false },
  ];

  customizePanel.config = {
    itemsName: 'Columns',
  };
<\/script>
`,h=p({__name:"_base",setup(u){const n={itemsName:"Columns"},t=[{label:"Option 1",description:"lorem ipsum dolor amet",selected:!0},{label:"Option 2",description:"lorem ipsum dolor amet",selected:!1},{label:"Option 3",description:"lorem ipsum dolor amet",selected:!0},{label:"Option 4",description:"lorem ipsum dolor amet",selected:!1}],c=[{active:!0,id:"webcomponent",label:"Web Component"},{disabled:!0,id:"htmlblueprint",label:"HTML Blueprint"}],s={webcomponent:x,htmlblueprint:""};return(_,o)=>{const m=d,a=b;return r(),f(a,{title:"Base",id:"base",tabs:c},{example:l(()=>[e("chi-customize-panel",{items:t,config:n},[...o[0]||(o[0]=[e("chi-button",{slot:"trigger",variant:"flat",type:"icon"},[e("chi-icon",{icon:"table-column-settings",size:"sm--2"}),e("span",null,"Open panel")],-1)])])]),"code-webcomponent":l(()=>[i(m,{class:"html",lang:"html",code:s.webcomponent},null,8,["code"])]),_:1})}}}),C=`<chi-customize-panel id="customize-panel-locked-example">
  <chi-button slot="trigger" variant="flat" type="icon">
    <chi-icon icon="table-column-settings" size="sm--2"></chi-icon>
    <span>Open panel</span>
  </chi-button>
</chi-customize-panel>

<script>
  const customizePanel = document.getElementById('customize-panel-locked-example');

  customizePanel.items = [
    { label: 'Option 1', description: 'lorem ipsum dolor amet', selected: true, locked: true },
    { label: 'Option 2', description: 'lorem ipsum dolor amet', selected: false, locked: true },
    { label: 'Option 3', description: 'lorem ipsum dolor amet', selected: true, locked: true },
    { label: 'Option 4', description: 'lorem ipsum dolor amet', selected: false, locked: true },
  ];

  customizePanel.config = {
    itemsName: 'Columns',
  };
<\/script>
`,O=p({__name:"_locked",setup(u){const n=[{label:"Option 1",description:"lorem ipsum dolor amet",selected:!0,locked:!0},{label:"Option 2",description:"lorem ipsum dolor amet",selected:!1,locked:!0},{label:"Option 3",description:"lorem ipsum dolor amet",selected:!0,locked:!0},{label:"Option 4",description:"lorem ipsum dolor amet",selected:!1,locked:!0}],t={itemsName:"Columns"},c=[{active:!0,id:"webcomponent",label:"Web Component"},{disabled:!0,id:"htmlblueprint",label:"HTML Blueprint"}],s={webcomponent:C,htmlblueprint:""};return(_,o)=>{const m=d,a=b;return r(),f(a,{title:"Locked",id:"locked",tabs:c},{example:l(()=>[e("chi-customize-panel",{items:n,config:t},[...o[0]||(o[0]=[e("chi-button",{slot:"trigger",variant:"flat",type:"icon"},[e("chi-icon",{icon:"table-column-settings",size:"sm--2"}),e("span",null,"Open panel")],-1)])])]),"code-webcomponent":l(()=>[i(m,{class:"html",lang:"html",code:s.webcomponent},null,8,["code"])]),_:1})}}}),z=`<chi-customize-panel id="customize-panel-info-icon-example">
  <chi-button slot="trigger" variant="flat" type="icon">
    <chi-icon icon="table-column-settings" size="sm--2"></chi-icon>
    <span>Open panel</span>
  </chi-button>
</chi-customize-panel>

<script>
  const customizePanel = document.getElementById('customize-panel-info-icon-example');

  customizePanel.items = [
    {
      label: 'Option 1',
      description: 'lorem ipsum dolor amet',
      selected: true,
      infoIcon: { icon: 'circle-info-outline', message: 'Custom info text' }
    },
    {
      label: 'Option 2',
      description: 'lorem ipsum dolor amet',
      selected: false,
      infoIcon: { icon: 'circle-info-outline', message: 'Custom info text' }
    },
    {
      label: 'Option 3',
      description: 'lorem ipsum dolor amet',
      selected: true,
      infoIcon: { icon: 'circle-alert-outline', message: 'Custom alert text', color: 'danger' }
    },
    {
      label: 'Option 4',
      description: 'lorem ipsum dolor amet',
      selected: false,
      infoIcon: { icon: 'circle-info-outline', message: 'Custom info text' }
    },
  ];

  customizePanel.config = {
    itemsName: 'Columns',
  };
<\/script>
`,I=p({__name:"_info-icon",setup(u){const n=[{label:"Option 1",description:"lorem ipsum dolor amet",selected:!0,infoIcon:{icon:"circle-info-outline",message:"Custom info text"}},{label:"Option 2",description:"lorem ipsum dolor amet",selected:!1,infoIcon:{icon:"circle-info-outline",message:"Custom info text"}},{label:"Option 3",description:"lorem ipsum dolor amet",selected:!0,infoIcon:{icon:"circle-alert-outline",message:"Custom alert text",color:"danger"}},{label:"Option 4",description:"lorem ipsum dolor amet",selected:!1,infoIcon:{icon:"circle-info-outline",message:"Custom info text"}}],t={itemsName:"Columns"},c=[{active:!0,id:"webcomponent",label:"Web Component"},{disabled:!0,id:"htmlblueprint",label:"HTML Blueprint"}],s={webcomponent:z,htmlblueprint:""};return(_,o)=>{const m=d,a=b;return r(),f(a,{title:"Info Icons",id:"info-icons",tabs:c},{example:l(()=>[e("chi-customize-panel",{items:n,config:t},[...o[0]||(o[0]=[e("chi-button",{slot:"trigger",variant:"flat",type:"icon"},[e("chi-icon",{icon:"table-column-settings",size:"sm--2"}),e("span",null,"Open panel")],-1)])])]),"code-webcomponent":l(()=>[i(m,{class:"html",lang:"html",code:s.webcomponent},null,8,["code"])]),_:1})}}}),w=`<chi-customize-panel id="customize-panel-complex-example" search>
  <chi-button slot="trigger" variant="flat" type="icon">
    <chi-icon icon="table-column-settings" size="sm--2"></chi-icon>
    <span>Open panel</span>
  </chi-button>
</chi-customize-panel>

<script>
  const customizePanel = document.getElementById('customize-panel-complex-example');

  customizePanel.items = [
    {
      label: 'Option 1',
      description: 'lorem ipsum dolor amet',
      selected: true,
      locked: true,
      infoIcon: {
        icon: 'circle-info-outline',
        message: 'Custom info text',
      },
    },
    {
      label: 'Option 2',
      description: 'lorem ipsum dolor amet',
      selected: false,
      infoIcon: {
        icon: 'circle-info-outline',
        message: 'Custom info text',
      },
    },
    {
      label: 'Option 3',
      description: 'lorem ipsum dolor amet',
      selected: true,
      infoIcon: {
        icon: 'circle-alert-outline',
        message: 'Custom alert text',
        color: 'danger',
      },
    },
    {
      label: 'Option 4',
      description: 'lorem ipsum dolor amet',
      selected: false,
      infoIcon: {
        icon: 'circle-info-outline',
        message: 'Custom info text',
      },
    },
    {
      label: 'Option 5',
      description: 'lorem ipsum dolor amet',
      selected: true,
      infoIcon: {
        icon: 'circle-info-outline',
        message: 'Custom info text',
      },
    },
    {
      label: 'Option 6',
      description: 'lorem ipsum dolor amet',
      selected: false,
      locked: true,
      infoIcon: {
        icon: 'circle-info-outline',
        message: 'Custom info text',
      },
    },
  ];

  customizePanel.config = {
    itemsName: 'Columns',
  };
<\/script>
`,k=p({__name:"_complex",setup(u){const n=[{label:"Option 1",description:"lorem ipsum dolor amet",selected:!0,locked:!0,infoIcon:{icon:"circle-info-outline",message:"Custom info text"}},{label:"Option 2",description:"lorem ipsum dolor amet",selected:!1,infoIcon:{icon:"circle-info-outline",message:"Custom info text"}},{label:"Option 3",description:"lorem ipsum dolor amet",selected:!0,infoIcon:{icon:"circle-alert-outline",message:"Custom alert text",color:"danger"}},{label:"Option 4",description:"lorem ipsum dolor amet",selected:!1,infoIcon:{icon:"circle-info-outline",message:"Custom info text"}},{label:"Option 5",description:"lorem ipsum dolor amet",selected:!0,infoIcon:{icon:"circle-info-outline",message:"Custom info text"}},{label:"Option 6",description:"lorem ipsum dolor amet",selected:!1,locked:!0,infoIcon:{icon:"circle-info-outline",message:"Custom info text"}}],t={itemsName:"Columns"},c=[{active:!0,id:"webcomponent",label:"Web Component"},{disabled:!0,id:"htmlblueprint",label:"HTML Blueprint"}],s={webcomponent:w,htmlblueprint:""};return(_,o)=>{const m=d,a=b;return r(),f(a,{title:"Complex",id:"complex",tabs:c},{example:l(()=>[e("chi-customize-panel",{items:n,config:t,search:""},[...o[0]||(o[0]=[e("chi-button",{slot:"trigger",variant:"flat",type:"icon"},[e("chi-icon",{icon:"table-column-settings",size:"sm--2"}),e("span",null,"Open panel")],-1)])])]),"code-webcomponent":l(()=>[i(m,{class:"html",lang:"html",code:s.webcomponent},null,8,["code"])]),_:1})}}}),P=p({__name:"index",setup(u){return(n,t)=>(r(),g("div",null,[t[0]||(t[0]=e("h2",null,"Examples",-1)),i(h),i(O),i(I),i(k)]))}});export{P as _};
