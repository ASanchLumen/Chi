import{an as m,am as l}from"./DBXeQHmC.js";const p=t=>`
    <div class="chi-carousel__item -p--1">
      Custom item ${t}
    </div>
`,c=t=>`
  <div class="-d--flex" slot="items">
    ${t.join("").trim()}
  </div>
`,u=(t,a)=>{const s=a.dynamicComputedProps,o=[m("interval",s.interval,!!s.autoplay)],r=l(a,o),e=[];for(let i=0;i<(s?.totalItems||0);i++){const n=String(i+1);e.push(p(n).trimEnd())}return`<${t}${r}>${c(e)}</${t}>`};export{u as snippet};
