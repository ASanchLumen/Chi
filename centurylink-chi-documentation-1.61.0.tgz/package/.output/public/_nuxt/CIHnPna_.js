import{as as o,aI as r,ar as u}from"./DBXeQHmC.js";const d=(e,p)=>{const{size:s,value:a,supB:t}=p.dynamicComputedProps,i=s&&s!=="md"?` ${o[s.toUpperCase()]}`:"";return[`<div class="${r.PRICE}${i}">`,...u(["<sup>$</sup>",String(a),`<sup>${t}</sup>`]),"</div>"].join(`
`)};export{d as snippet};
