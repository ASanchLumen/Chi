import{_ as P}from"./DnPF01B5.js";import{_ as C}from"./CdcsEwU-.js";import{e as S,q,H as W,i as I,o as i,w as m,b as y,k as M,a as e,c as a,S as E,F as f,r as w,t as k,d as V,Q as N,x as ee,a8 as ie,a9 as te,aa as z,l as $,B as j,R as oe,a4 as ae}from"./DBXeQHmC.js";import{_ as se}from"./DlAUqK2U.js";import{_ as re,b as de,h as he,c as pe}from"./5jRS-OJG.js";import{_ as me}from"./Bjy4eZkV.js";const ue={class:"chi-grid -no-gutter"},ve={class:"chi-col -w--12"},be={class:"-p--2 -text--center"},_e=["color"],ge=["color"],ke=`<chi-badge color="success">
  <chi-icon icon="atom" size="xs"></chi-icon>
  <span>Success</span>
</chi-badge>

<chi-badge variant="outline" color="success">
  <chi-icon icon="atom" size="xs"></chi-icon>
  <span>Success</span>
</chi-badge>`,fe=S({__name:"_badge",props:{id:{},title:{}},setup(v){const n=v,o=q([{active:!0,id:"base",label:"Base"},{id:"outline",label:"Outline"},{id:"icon",label:"Icon"}]),c=[{label:"Success",color:"success"},{label:"Info",color:"accent-1"},{label:"Muted",color:"muted"},{label:"Warning",color:"warning"},{label:"Danger",color:"danger"}],l=q("base");function p(x){o.value.forEach(b=>{b.active=b.id===x.id}),l.value=x.id}const _=W(()=>{switch(l.value){case"outline":return r;case"icon":return ke;default:return u}});function s(x){return x.replace(/<\/chi-badge>\s*/g,`</chi-badge>

`).trim()+`
`}const u=s(`<chi-badge color="success">Success</chi-badge>
<chi-badge color="accent-1">Info</chi-badge>
<chi-badge color="muted">Muted</chi-badge>
<chi-badge color="warning">Warning</chi-badge>
<chi-badge color="danger">Danger</chi-badge>
`),r=s(`<chi-badge variant="outline" color="success">Success</chi-badge>
<chi-badge variant="outline" color="accent-1">Info</chi-badge>
<chi-badge variant="outline" color="muted">Muted</chi-badge>
<chi-badge variant="outline" color="warning">Warning</chi-badge>
<chi-badge variant="outline" color="danger">Danger</chi-badge>
`);return(x,b)=>{const d=P,A=C;return i(),I(A,{title:n.title,id:n.id,showSnippetTabs:!1,"head-tabs":o.value,onChiHeadTabsChange:p},{example:m(()=>[e("div",ue,[e("div",ve,[e("div",be,[l.value==="base"?(i(),a(f,{key:0},w(c,B=>e("chi-badge",{class:"-m--1",color:B.color},k(B.label),9,_e)),64)):E("",!0),l.value==="outline"?(i(),a(f,{key:1},w(c,B=>e("chi-badge",{class:"-m--1",color:B.color,variant:"outline"},k(B.label),9,ge)),64)):E("",!0),l.value==="icon"?(i(),a(f,{key:2},[b[0]||(b[0]=e("chi-badge",{class:"-m--1",color:"success"},[e("chi-icon",{icon:"atom",size:"xs"}),e("span",null,"Success")],-1)),b[1]||(b[1]=e("chi-badge",{class:"-m--1",color:"success",variant:"outline"},[e("chi-icon",{icon:"atom",size:"xs"}),e("span",null,"Success")],-1))],64)):E("",!0)])])])]),"code-htmlblueprint":m(()=>[y(d,{class:"html",lang:"html",code:M(_)},null,8,["code"])]),_:1},8,["title","id","head-tabs"])}}}),we=`<!-- Primary Button -->
<chi-button color="primary">Primary</chi-button>

<!-- Secondary Button -->
<chi-button>Secondary</chi-button>

<!-- Tertiary Button -->
<chi-button variant="flat">Tertiary</chi-button>
`,ye=S({__name:"_button",props:{id:{},title:{}},setup(v){const n=v;return(o,c)=>{const l=P,p=C;return i(),I(p,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[...c[0]||(c[0]=[e("div",{class:"-d--flex -flex--wrap",style:{gap:"12px"}},[e("chi-button",{color:"primary"},"Primary"),e("chi-button",null,"Secondary"),e("chi-button",{variant:"flat"},"Tertiary")],-1)])]),"code-htmlblueprint":m(()=>[y(l,{class:"html",lang:"html",code:we})]),_:1},8,["title","id"])}}}),xe=`<!-- Base card -->
<chi-card title="Base card" variant="outline">
  Content goes here
</chi-card>

<!-- Accordion card -->
<chi-card title="Accordion card" type="accordion" variant="outline">
  Content goes here
</chi-card>

<!-- Widget card with Link or CTA -->
<chi-card title="Widget with link" widget type="compact-title" variant="outline">
  <div slot="compact-title">
    <chi-link>
      Optional link
    </chi-link>
  </div>
  Content goes here
</chi-card>

<!-- KPI card -->
<chi-card id="kpi-card" title="KPI card" type="kpi" metric="$1.234,56">
  Content goes here
</chi-card>

<!-- KPI card with fixed-width -->
<chi-card title="KPI card" type="kpi" metric="12" fixed-width>
  Content goes here
</chi-card>

<!-- KPI card with disabled state -->
<chi-card title="Disabled KPI card" type="kpi" metric="12" fixed-width disabled>
  Content goes here
</chi-card>
`,Ie=S({__name:"_card",props:{id:{},title:{}},setup(v){const n=v;return(o,c)=>{const l=P,p=C;return i(),I(p,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[...c[0]||(c[0]=[e("div",{class:"-d--flex -flex--column -w--100",style:{gap:"16px"}},[e("chi-card",{title:"Base card",variant:"outline"},"Content goes here"),e("div",{class:"-d--flex -flex--grow1 -align-items--center",style:{gap:"12px"}},[e("chi-card",{class:"-w--50",title:"Accordion card",type:"accordion",variant:"outline"},"Content goes here"),e("chi-card",{class:"-w--50",title:"Widget with link",widget:"",type:"compact-title",variant:"outline"},[e("div",{slot:"compact-title"},[e("chi-link",null,"Optional link")]),V("Content goes here")])]),e("div",{class:"-d--flex -flex--grow1",style:{gap:"12px"}},[e("chi-card",{class:"-w--50",title:"KPI card",type:"kpi",metric:"$1.234,56"},"Content goes here"),e("chi-card",{class:"-w--50",title:"KPI card",type:"kpi",metric:"12","fixed-width":""},"Content goes here")]),e("chi-card",{class:"-w--50",title:"Disabled KPI card",type:"kpi",metric:"12","fixed-width":"",disabled:""},"Content goes here")],-1)])]),"code-htmlblueprint":m(()=>[y(l,{class:"html",lang:"html",code:xe})]),_:1},8,["title","id"])}}}),Se={class:"-d--flex -flex--column -w--100 -g--2"},Ce={title:"Alerts",variant:"outline",type:"alert",notifications:"6"},Pe={slot:"compact-title"},Ae={icon:"more-vert",variant:"flat"},De=`<!-- Base Card Alert -->
<chi-card title="Alerts" variant="outline" type="alert" notifications="6">
  <!-- All the inner cards -->
  <chi-card title="[Alert title]" class="alert__inner-card" variant="outline" eyebrow="[Product/Service Name]" type="compact-title">
    <div slot="compact-title">
      <chi-dropdown icon="more-vert" variant="flat">
        <a class="chi-dropdown__menu-item" slot="menu">Item 1</a>
        <a class="chi-dropdown__menu-item" slot="menu">Item 2</a>
        <a class="chi-dropdown__menu-item" slot="menu">Item 3</a>
      </chi-dropdown>
    </div>
    <div class="alert__inner-content">
      <chi-link>ID 123456567</chi-link>
      <chi-badge color="muted">Email Sent</chi-badge>
    </div>
  </chi-card>
</chi-card>

<!-- Empty Card Alert -->
<chi-card title="Alerts" variant="outline" type="alert" empty></chi-card>
`,Ee=S({__name:"_card_alert",props:{id:{},title:{}},setup(v){const n=v;return(o,c)=>{const l=P,p=C;return i(),I(p,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[e("div",Se,[e("chi-card",Ce,[(i(),a(f,null,w(6,_=>e("chi-card",{class:"alert__inner-card",key:_,title:"[Alert title]",variant:"outline",eyebrow:"[Product/Service Name]",type:"compact-title"},[e("div",Pe,[e("chi-dropdown",Ae,[(i(),a(f,null,w(3,s=>e("a",{class:"chi-dropdown__menu-item",key:s,slot:"menu"},"Item "+k(s),1)),64))])]),c[0]||(c[0]=e("div",{class:"alert__inner-content"},[e("chi-link",null,"ID 123456567"),e("chi-badge",{color:"muted"},"Email Sent")],-1))])),64))]),c[1]||(c[1]=e("chi-card",{title:"Alerts",variant:"outline",type:"alert",empty:""},null,-1))])]),"code-htmlblueprint":m(()=>[y(l,{class:"html",lang:"html",code:De})]),_:1},8,["title","id"])}}}),$e=`<!-- Base Checkbox -->
<chi-checkbox label="Checkbox"></chi-checkbox>

<!-- Checked Checkbox -->
<chi-checkbox label="Checked" checked></chi-checkbox>

<!-- Indeterminate Checkbox -->
<chi-checkbox label="Indeterminate" indeterminate></chi-checkbox>

<!-- Disabled Checkbox -->
<chi-checkbox label="Disabled" disabled></chi-checkbox>
`,Me=S({__name:"_checkbox",props:{id:{},title:{}},setup(v){const n=v;return(o,c)=>{const l=P,p=C;return i(),I(p,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[...c[0]||(c[0]=[e("div",{class:"-d--flex -g--5"},[e("chi-checkbox",{label:"Checkbox"}),e("chi-checkbox",{label:"Checked",checked:""}),e("chi-checkbox",{label:"Indeterminate",indeterminate:""}),e("chi-checkbox",{label:"Disabled",disabled:""})],-1)])]),"code-htmlblueprint":m(()=>[y(l,{class:"html",lang:"html",code:$e})]),_:1},8,["title","id"])}}}),Be={class:"connect-app-layout--dashboard"},Ne={class:"chi-header -lg"},qe={class:"chi-header__content"},Te={class:"-d-xl--block chi-header__start"},ze={class:"chi-header__start"},Le={id:"mobile-nav-trigger",ref:"mobile-nav-trigger",size:"lg",color:"dark",type:"icon",variant:"flat"},Re={class:"-d--none -d-lg--flex chi-header__end"},Fe=["retain-selection","button"],Ve={class:"chi-grid"},Oe={class:"chi-col -w--4"},Qe={class:"chi-col -w--7"},He={key:0,class:"chi-col -w--1"},Ue={class:"app-layout-wrapper -d--flex -flex--grow1"},je={class:"chi-sidenav -global -h--auto -d--none -d-md--block",id:"global-nav",ref:"dashboard-global-nav"},We={class:"chi-sidenav__content"},Ge={class:"chi-sidenav__list"},Ke={class:"chi-sidenav__item-wrapper"},Je={key:0},Ze=["icon"],Xe=["size"],Ye=["id"],ei=["slot"],ii={class:"chi-sidenav__item-guide"},ti=["id"],li=["slot"],ni={class:"chi-sidenav__item-guide"},ci={class:"chi-sidenav__item-wrapper"},oi=["icon"],ai={id:"main-menu"},si={class:"chi-mobile-nav__header"},ri=["retain-selection","button"],di={class:"chi-grid"},hi={class:"chi-col -w--4"},pi={class:"chi-col -w--7"},mi={key:0,class:"chi-col -w--1"},ui={class:"chi-mobile-nav__list"},vi=["href"],bi=["icon"],_i={key:1,icon:"chevron-right"},gi={class:"chi-mobile-nav__list"},ki=["href"],fi=["icon"],wi={id:"dashboard-mobile-nav-services-menu"},yi={class:"chi-mobile-nav__list"},xi=["href"],Ii={key:0,icon:"chevron-right"},Si={id:"dashboard-mobile-nav-apis-menu"},Ci={class:"chi-mobile-nav__list"},Pi=["href"],Ai={key:0,icon:"chevron-right"},Di={id:"dashboard-mobile-nav-quotes-menu"},Ei={class:"chi-mobile-nav__list"},$i={id:"dashboard-mobile-nav-service-portals-menu"},Mi={class:"chi-mobile-nav__list"},Bi={id:"dashboard-mobile-nav-view-apis-menu"},Ni={class:"chi-mobile-nav__list"},qi={class:"chi-main--wrapper -flex--grow1"},Ti={narnia:"","help-position":"right","header-background":"",title:"Dashboard"},zi={class:"chi-main__accordion"},Li={slot:"core-capabilities"},Ri={class:"chi-grid",id:"coreCapabilitiesGrid"},Fi={class:"chi-col -d--flex -w--12 -g--2",id:"services-and-accordion-cards"},Vi={variant:"outline",type:"compact-title",widget:"",title:"Services"},Oi={slot:"compact-title"},Qi={class:"chi-col -w--12 -w-lg--12 -mt--2 -mt-lg--0 -position--static"},Hi={class:"-d--flex -mb--2"},Ui={ref:"dashboard-help-drawer",backdrop:"",position:"right",title:"Title"},ji=`<!-- Connect App layout - Dashboard -->
<div class="connect-app-layout--dashboard">

  <!-- Header -->
  <header class="chi-header -lg">
    <div class="chi-header__brandbar"></div>
    <nav class="chi-header__content">
      <div class="chi-header__brand">
        <chi-link href="/" alternative-text="Lumen">
          <chi-brand logo="lumen" />
        </chi-link>
        <span class="chi-header__title -d--none -d-sm--flex">[Portal Name]</span>
      </div>
      <div class="chi-header__start -d--none -d-xl--block">
        <chi-button id="toggle-nav" variant="flat" size="lg" type="icon" color="dark">
          <chi-icon icon="menu" size="sm--3"></chi-icon>
        </chi-button>
      </div>
      <div class="chi-header__start -d-md--none">
        <chi-button id="mobile-nav-trigger" variant="flat" type="icon" color="dark" size="lg">
          <chi-icon icon="menu" size="sm--3"></chi-icon>
        </chi-button>
      </div>
      <div class="chi-header__end -d--none -d-lg--flex">
        <chi-dropdown class="enterprise-id-switcher" position="bottom-end" button="Enterprise ID: 1234567" size="sm" select-mode>
          <div class="chi-grid" slot="menu-header">
            <div class="chi-col -w--4">Enterprise ID</div>
            <div class="chi-col -w--7">Enterprise Name</div>
          </div>
          <a class="chi-dropdown__menu-item -active" slot="menu">
            <div class="chi-grid">
              <div class="chi-col -w--4">1234567</div>
              <div class="chi-col -w--4">Acme Incorporated</div>
            </div>
          </a>
          <a class="chi-dropdown__menu-item" slot="menu">
            <div class="chi-grid">
              <div class="chi-col -w--4">1234568</div>
              <div class="chi-col -w--7">Acme Incorporated</div>
            </div>
          </a>
          <a class="chi-dropdown__menu-item" slot="menu">
            <div class="chi-grid">
              <div class="chi-col -w--4">1234569</div>
              <div class="chi-col -w--7">Acme Incorporated</div>
              <div class="chi-col -w--1">
                <chi-spinner></chi-spinner>
              </div>
            </div>
          </a>
          <a class="chi-dropdown__menu-item" slot="menu">
            <div class="chi-grid">
              <div class="chi-col -w--4">1234560</div>
              <div class="chi-col -w--7">Acme Incorporated</div>
            </div>
          </a>
          <chi-link slot="menu-footer">Manage My Enterprises</chi-link>
        </chi-dropdown>
        <div class="chi-divider -vertical"></div>
        <chi-dropdown position="bottom" size="sm" button="Menu" variant="flat">
          <a class="chi-dropdown__menu-item" href="#" slot="menu">
            <chi-icon icon="user"></chi-icon>
            Item 1
          </a>
          <a class="chi-dropdown__menu-item" href="#" slot="menu">
            <chi-icon icon="login"></chi-icon>
            Item 2
          </a>
        </chi-dropdown>
      </div>
    </nav>
  </header>

  <!-- App layout wrapper -->
  <div class="app-layout-wrapper -d--flex -flex--grow1">

    <!-- Side navigation -->
    <aside id="global-nav" class="chi-sidenav -global -h--auto -d--none -d-md--block">
      <div class="chi-sidenav__content">
        <nav>
          <ul class="chi-sidenav__list">
            <li class="chi-sidenav__item">
              <div class="chi-sidenav__item-wrapper">
                <chi-link>
                  <chi-icon icon="dashboard"></chi-icon>
                  <span>Dashboard</span>
                </chi-link>
              </div>
            </li>
            <li class="chi-sidenav__item">
              <div class="chi-sidenav__item-wrapper">
                <chi-link>
                  <chi-icon icon="bell"></chi-icon>
                  <chi-badge size="xs" text-weight="bold" type="notification">22</chi-badge>
                  <span>Alerts & Notifications</span>
                </chi-link>
              </div>
            </li>
            <li class="chi-sidenav__item">
              <div class="chi-sidenav__item-wrapper">
                <chi-accordion id="services" type="link">
                  <div slot="services-template">
                    <div class="chi-sidenav__item-guide">
                      <chi-link>Manage Services</chi-link>
                      <chi-link>Add Services</chi-link>
                      <chi-link>Order Status</chi-link>
                      <chi-accordion id="services-tools" type="link">
                        <div slot="services-tools-template">
                          <div class="chi-sidenav__item-guide">
                            <chi-link>ELS & LI Managements</chi-link>
                            <chi-link>Network Storage</chi-link>
                            <chi-link class="-active">Edge Bare Metal</chi-link>
                            <chi-link>SASE Management</chi-link>
                            <chi-link>Voice Complete Features</chi-link>
                            <chi-link>+1 Switched Toll Free</chi-link>
                            <chi-link>Cross Connect</chi-link>
                            <chi-link>Enhanced Routing</chi-link>
                            <chi-link>Manage Voicemail</chi-link>
                            <chi-link>Security Certificate Management</chi-link>
                            <chi-link>Toll Free Management</chi-link>
                          </div>
                        </div>
                      </chi-accordion>
                      <chi-accordion id="services-requests" type="link">
                        <div slot="services-requests-template">
                          <div class="chi-sidenav__item-guide">
                            <chi-link>Requests Page 1</chi-link>
                            <chi-link>Requests Page 2</chi-link>
                            <chi-link>Requests Page 3</chi-link>
                          </div>
                        </div>
                      </chi-accordion>
                      <chi-accordion id="services-quotes" type="link">
                        <div slot="services-quotes-template">
                          <div class="chi-sidenav__item-guide">
                            <chi-link>Quotes Page 1</chi-link>
                            <chi-link>Quotes Page 2</chi-link>
                            <chi-link>Quotes Page 3</chi-link>
                          </div>
                        </div>
                      </chi-accordion>
                      <chi-accordion id="services-portals" type="link">
                        <div slot="services-portals-template">
                          <div class="chi-sidenav__item-guide">
                            <chi-link>Portals Page 1</chi-link>
                            <chi-link>Portals Page 2</chi-link>
                            <chi-link>Portals Page 3</chi-link>
                          </div>
                        </div>
                      </chi-accordion>
                    </div>
                  </div>
                </chi-accordion>
              </div>
            </li>
            <li class="chi-sidenav__item">
              <div class="chi-sidenav__item-wrapper">
                <chi-accordion id="apis" type="link">
                  <div slot="apis-template">
                    <div class="chi-sidenav__item-guide">
                      <chi-link>APIs page 1</chi-link>
                      <chi-link>APIs page 2</chi-link>
                      <chi-link>APIs page 3</chi-link>
                    </div>
                  </div>
                </chi-accordion>
              </div>
            </li>
            <li class="chi-sidenav__item">
              <div class="chi-sidenav__item-wrapper">
                <chi-accordion id="monitoring-and-reports" type="link">
                  <div slot="monitoring-and-reports-template">
                    <div class="chi-sidenav__item-guide">
                      <chi-link>Monitoring & Reports page 1</chi-link>
                      <chi-link>Monitoring & Reports page 2</chi-link>
                      <chi-link>Monitoring & Reports page 3</chi-link>
                    </div>
                  </div>
                </chi-accordion>
              </div>
            </li>
            <li class="chi-sidenav__item">
              <div class="chi-sidenav__item-wrapper">
                <chi-accordion id="billing" type="link">
                  <div slot="billing-template">
                    <div class="chi-sidenav__item-guide">
                      <chi-link>Billing page 1</chi-link>
                      <chi-link>Billing page 2</chi-link>
                      <chi-link>Billing page 3</chi-link>
                    </div>
                  </div>
                </chi-accordion>
              </div>
            </li>
            <li class="chi-sidenav__item">
              <div class="chi-sidenav__item-wrapper">
                <chi-accordion id="admin" type="link">
                  <div slot="admin-template">
                    <div class="chi-sidenav__item-guide">
                      <chi-link>Admin page 1</chi-link>
                      <chi-link>Admin page 2</chi-link>
                      <chi-link>Admin page 3</chi-link>
                    </div>
                  </div>
                </chi-accordion>
              </div>
            </li>
            <li class="chi-sidenav__item">
              <div class="chi-sidenav__item-wrapper">
                <chi-accordion id="support" type="link">
                  <div slot="support-template">
                    <div class="chi-sidenav__item-guide">
                      <chi-link>Support page 1</chi-link>
                      <chi-link>Support page 2</chi-link>
                      <chi-link>Support page 3</chi-link>
                    </div>
                  </div>
                </chi-accordion>
              </div>
            </li>
            <div class="chi-divider"></div>
            <li class="chi-sidenav__item">
              <div class="chi-sidenav__item-wrapper">
                <chi-link>
                  <chi-icon icon="circle-question"></chi-icon>
                  <span>[Portal Name] Help</span>
                </chi-link>
              </div>
            </li>
            <li class="chi-sidenav__item">
              <div class="chi-sidenav__item-wrapper">
                <chi-link>
                  <chi-icon icon="compose"></chi-icon>
                  <span>Contact Lumen</span>
                </chi-link>
              </div>
            </li>
          </ul>
        </nav>
      </div>
    </aside>

    <div class="chi-mobile-nav -global" id="mobile-nav">
      <chi-drawer id="mobile-nav-drawer">
        <div id="main-menu">
          <div class="chi-mobile-nav__header">
            <chi-dropdown id="enterprise-dropdown" class="enterprise-id-switcher" position="bottom" button="Enterprise ID: 1234567" size="sm" select-mode>
              <div class="chi-grid" slot="menu-header">
                <div class="chi-col -w--4">Enterprise ID</div>
                <div class="chi-col -w--7">Enterprise Name</div>
              </div>
              <a class="chi-dropdown__menu-item -active" slot="menu">
                <div class="chi-grid">
                  <div class="chi-col -w--4">1234567</div>
                  <div class="chi-col -w--7">Acme Incorporated</div>
                </div>
              </a>
              <a class="chi-dropdown__menu-item" slot="menu">
                <div class="chi-grid">
                  <div class="chi-col -w--4">1234568</div>
                  <div class="chi-col -w--7">Acme Incorporated</div>
                </div>
              </a>
              <a class="chi-dropdown__menu-item" slot="menu">
                <div class="chi-grid">
                  <div class="chi-col -w--4">1234569</div>
                  <div class="chi-col -w--7">Acme Incorporated</div>
                  <div class="chi-col -w--1">
                    <chi-spinner></chi-spinner>
                  </div>
                </div>
              </a>
              <a class="chi-dropdown__menu-item" slot="menu">
                <div class="chi-grid">
                  <div class="chi-col -w--4">1234560</div>
                  <div class="chi-col -w--7">Acme Incorporated</div>
                </div>
              </a>
              <div class="chi-divider" slot="menu-footer"></div>
              <chi-link slot="menu-footer">Manage My Enterprises</chi-link>
            </chi-dropdown>
          </div>
          <div class="chi-divider -my--0"></div>
          <ul class="chi-mobile-nav__list">
            <li class="chi-mobile-nav__item">
              <chi-link>
                <chi-icon icon="dashboard"></chi-icon>
                <span>Dashboard</span>
              </chi-link>
            </li>
            <li class="chi-mobile-nav__item">
                <chi-link>
                  <chi-icon icon="bell"></chi-icon>
                  <chi-badge size="xs" text-weight="bold" type="notification">22</chi-badge>
                  <span>Alerts & Notifications</span>
                </chi-link>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link class="-active" href="#services-menu">
                <chi-icon icon="list-alt"></chi-icon>
                <span>Services</span>
                <chi-icon icon="chevron-right"></chi-icon>
              </chi-link>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link href="#apis-menu">
                <chi-icon icon="api"></chi-icon>
                <span>APIs</span>
                <chi-icon icon="chevron-right"></chi-icon>
              </chi-link>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link>
                <chi-icon icon="chart-bar"></chi-icon>
                <span>Monitoring & Reports</span>
                <chi-icon icon="chevron-right"></chi-icon>
              </chi-link>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link>
                <chi-icon icon="mail-open-dollar"></chi-icon>
                <span>Billing</span>
                <chi-icon icon="chevron-right"></chi-icon>
              </chi-link>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link>
                <chi-icon icon="users"></chi-icon>
                <span>Admin</span>
                <chi-icon icon="chevron-right"></chi-icon>
              </chi-link>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link>
                <chi-icon icon="life-ring"></chi-icon>
                <span>Support</span>
                <chi-icon icon="chevron-right"></chi-icon>
              </chi-link>
            </li>
          </ul>
          <div class="chi-divider -my--0"></div>
          <ul class="chi-mobile-nav__list">
            <li class="chi-mobile-nav__item">
              <chi-link>
                <chi-icon icon="circle-question"></chi-icon>
                <span>[Portal Name] Help</span>
              </chi-link>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link>
                <chi-icon icon="compose"></chi-icon>
                <span>Contact Lumen</span>
              </chi-link>
            </li>
          </ul>
          <div class="chi-divider -my--0"></div>
          <ul class="chi-mobile-nav__list">
            <li class="chi-mobile-nav__item">
              <span class="chi-mobile-nav__email">jamie.johnson@company.com</span>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link>
                <chi-icon icon="user"></chi-icon>
                <span>My Profile</span>
              </chi-link>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link>
                <chi-icon icon="logout"></chi-icon>
                <span>Sign out</span>
              </chi-link>
            </li>
          </ul>
        </div>
        <div id="services-menu">
          <ul class="chi-mobile-nav__list">
            <li class="chi-mobile-nav__item">
              <chi-link href="https://lib.lumen.com/"> Manage Services </chi-link>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link> Add Services </chi-link>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link> Order Status </chi-link>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link>
                <span>Service Tools</span>
                <chi-icon icon="chevron-right"></chi-icon>
              </chi-link>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link>
                <span>Service Requests</span>
                <chi-icon icon="chevron-right"></chi-icon>
              </chi-link>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link class="-active" href="#quotes-menu">
                <span>Quotes</span>
                <chi-icon icon="chevron-right"></chi-icon>
              </chi-link>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link href="#service-portals-menu">
                <span>Service Portals</span>
                <chi-icon icon="chevron-right"></chi-icon>
              </chi-link>
            </li>
          </ul>
        </div>
        <div id="apis-menu">
          <ul class="chi-mobile-nav__list">
            <li class="chi-mobile-nav__item">
              <chi-link href="#view-apis-menu">
                <span>View APIs</span>
                <chi-icon icon="chevron-right"></chi-icon>
              </chi-link>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link> Edit APIs </chi-link>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link> API Settings </chi-link>
            </li>
          </ul>
        </div>
        <div id="quotes-menu">
          <ul class="chi-mobile-nav__list">
            <li class="chi-mobile-nav__item">
              <chi-link class="-active">View Quotes</chi-link>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link>Create Quotes</chi-link>
            </li>
          </ul>
        </div>
        <div id="service-portals-menu">
          <ul class="chi-mobile-nav__list">
            <li class="chi-mobile-nav__item">
              <chi-link>Service Portal 1</chi-link>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link>Service Portal 2</chi-link>
            </li>
          </ul>
        </div>
        <div id="view-apis-menu">
          <ul class="chi-mobile-nav__list">
            <li class="chi-mobile-nav__item">
              <chi-link>API 1</chi-link>
            </li>
            <li class="chi-mobile-nav__item">
              <chi-link>API 2</chi-link>
            </li>
          </ul>
        </div>
      </chi-drawer>
    </div>

    <!-- App layout -->
    <div class="chi-main--wrapper -flex--grow1">
      <chi-main title="Dashboard" header-background help-position="right" narnia>
        <chi-button extra-class="-bg--white" slot="help-icon" id="help-button">
          <chi-icon icon="circle-question-outline" size="sm"></chi-icon>
          <span>Help</span>
        </chi-button>

        <div class="chi-main__accordion">
          <chi-accordion id="main-accordion" portal>
            <div slot="core-capabilities">
              <p class="-text -mb--3">
                Access tools to locate services, monitor open orders, review requests and tickets, and manage invoices
                effortlessly.
              </p>
              <div id="coreCapabilitiesGrid" class="chi-grid">
                <div id="services-and-accordion-cards" class="chi-col -d--flex -flex--column -w--12 -w-lg--4 -g--2">
                  <chi-card title="Services" widget type="compact-title" variant="outline">
                    <div slot="compact-title">
                      <chi-link no-underline size="md">Manage services</chi-link>
                    </div>
                    <div class="chi-form__item -mt--2">
                      <chi-label>Find by Service ID</chi-label>
                      <chi-search-input placeholder="Service ID, Nickname, or Location"></chi-search-input>
                    </div>
                    <div class="chi-form__item -mt--3">
                      <chi-label>Find by Product or Service Tool</chi-label>
                      <chi-dropdown-select id="services-dropdown" button="Select a product or service tool"></chi-dropdown-select>
                    </div>
                  </chi-card>
                  <chi-card title="Alerts" variant="outline" type="alert" notifications="22">
                    <chi-card title="[Alert title]" class="alert__inner-card" variant="outline" eyebrow="[Product/Service Name]" type="compact-title">
                      <div slot="compact-title">
                        <chi-dropdown icon="more-vert" variant="flat">
                          <a class="chi-dropdown__menu-item" slot="menu">Item 1</a>
                          <a class="chi-dropdown__menu-item" slot="menu">Item 2</a>
                          <a class="chi-dropdown__menu-item" slot="menu">Item 3</a>
                        </chi-dropdown>
                      </div>
                      <div class="alert__inner-content">
                        <chi-link>ID 123456567</chi-link>
                        <chi-badge color="muted">Email Sent</chi-badge>
                      </div>
                    </chi-card>
                    <chi-card title="[Alert title]" class="alert__inner-card" variant="outline" eyebrow="[Product/Service Name]" type="compact-title">
                      <div slot="compact-title">
                        <chi-dropdown icon="more-vert" variant="flat">
                          <a class="chi-dropdown__menu-item" slot="menu">Item 1</a>
                          <a class="chi-dropdown__menu-item" slot="menu">Item 2</a>
                          <a class="chi-dropdown__menu-item" slot="menu">Item 3</a>
                        </chi-dropdown>
                      </div>
                      <div class="alert__inner-content">
                        <chi-link>ID 123456567</chi-link>
                        <chi-badge color="muted">Email Sent</chi-badge>
                      </div>
                    </chi-card>
                    <chi-card title="[Alert title]" class="alert__inner-card" variant="outline" eyebrow="[Product/Service Name]" type="compact-title">
                      <div slot="compact-title">
                        <chi-dropdown icon="more-vert" variant="flat">
                          <a class="chi-dropdown__menu-item" slot="menu">Item 1</a>
                          <a class="chi-dropdown__menu-item" slot="menu">Item 2</a>
                          <a class="chi-dropdown__menu-item" slot="menu">Item 3</a>
                        </chi-dropdown>
                      </div>
                      <div class="alert__inner-content">
                        <chi-link>ID 123456567</chi-link>
                        <chi-badge color="muted">Email Sent</chi-badge>
                      </div>
                    </chi-card>
                    <chi-card title="[Alert title]" class="alert__inner-card" variant="outline" eyebrow="[Product/Service Name]" type="compact-title">
                      <div slot="compact-title">
                        <chi-dropdown icon="more-vert" variant="flat">
                          <a class="chi-dropdown__menu-item" slot="menu">Item 1</a>
                          <a class="chi-dropdown__menu-item" slot="menu">Item 2</a>
                          <a class="chi-dropdown__menu-item" slot="menu">Item 3</a>
                        </chi-dropdown>
                      </div>
                      <div class="alert__inner-content">
                        <chi-link>ID 123456567</chi-link>
                        <chi-badge color="muted">Email Sent</chi-badge>
                      </div>
                    </chi-card>
                    <chi-card title="[Alert title]" class="alert__inner-card" variant="outline" eyebrow="[Product/Service Name]" type="compact-title">
                      <div slot="compact-title">
                        <chi-dropdown icon="more-vert" variant="flat">
                          <a class="chi-dropdown__menu-item" slot="menu">Item 1</a>
                          <a class="chi-dropdown__menu-item" slot="menu">Item 2</a>
                          <a class="chi-dropdown__menu-item" slot="menu">Item 3</a>
                        </chi-dropdown>
                      </div>
                      <div class="alert__inner-content">
                        <chi-link>ID 123456567</chi-link>
                        <chi-badge color="muted">Email Sent</chi-badge>
                      </div>
                    </chi-card>
                    <chi-card title="[Alert title]" class="alert__inner-card" variant="outline" eyebrow="[Product/Service Name]" type="compact-title">
                      <div slot="compact-title">
                        <chi-dropdown icon="more-vert" variant="flat">
                          <a class="chi-dropdown__menu-item" slot="menu">Item 1</a>
                          <a class="chi-dropdown__menu-item" slot="menu">Item 2</a>
                          <a class="chi-dropdown__menu-item" slot="menu">Item 3</a>
                        </chi-dropdown>
                      </div>
                      <div class="alert__inner-content">
                        <chi-link>ID 123456567</chi-link>
                        <chi-badge color="muted">Email Sent</chi-badge>
                      </div>
                    </chi-card>
                  </chi-card>
                  <chi-card title="Scheduled Maintenance" type="accordion" variant="outline">
                    <div class="-w--100 -text--left" slot="card-accordion-header">
                      <chi-link size="md">View all</chi-link>
                    </div>
                    <chi-date></chi-date>
                  </chi-card>
                  <chi-card title="Favourite Pages" type="accordion" variant="outline">
                    <p class="-text -my--2">
                      These are the top pages you visit most often — up to 8 of your most frequently accessed.
                    </p>
                    <div class="chi-grid">
                      <div class="chi-col -w--6 -mt--1">
                        <chi-link no-underline>Favourite Page 1</chi-link>
                      </div>
                      <div class="chi-col -w--6 -mt--1">
                        <chi-link no-underline>Favourite Page 2</chi-link>
                      </div>
                      <div class="chi-col -w--6 -mt--1">
                        <chi-link no-underline>Favourite Page 3</chi-link>
                      </div>
                      <div class="chi-col -w--6 -mt--1">
                        <chi-link no-underline>Favourite Page 4 With a Longer Title</chi-link>
                      </div>
                      <div class="chi-col -w--6 -mt--1">
                        <chi-link no-underline>Favourite Page 5</chi-link>
                      </div>
                      <div class="chi-col -w--6 -mt--1">
                        <chi-link no-underline>Favourite Page 6</chi-link>
                      </div>
                      <div class="chi-col -w--6 -mt--1">
                        <chi-link no-underline>Favourite Page 7</chi-link>
                      </div>
                      <div class="chi-col -w--6 -mt--1">
                        <chi-link no-underline>Favourite Page 8</chi-link>
                      </div>
                    </div>
                  </chi-card>
                </div>

                <!-- SNAPSHOTS -->
                <div class="chi-col -w--12 -w-lg--8 -mt--2 -mt-lg--0">
                  <div class="-d--flex -mb--2">
                    <span class="-text--bold">Snapshots</span>
                    <chi-customize-panel id="customize-snapshots-panel" class="-ml--2">
                      <chi-link size="md" slot="trigger">Customize</chi-link>
                    </chi-customize-panel>
                  </div>
                  <div class="-d--flex -flex--wrap -g--2 snapshots-dashboard-wrapper">
                    <chi-card title="Pay Balance Due" type="kpi" metric="$3,000,130.87" fixed-width id="payBalanceDue"></chi-card>
                    <chi-card title="Active Repair Tickets" type="kpi" metric="23" fixed-width> Past 90 days </chi-card>
                    <chi-card title="Disconnect Requests" type="kpi" metric="26" fixed-width> Past 30 days </chi-card>
                    <chi-card type="kpi" title="Open Orders" fixed-width>
                      <div class="-text--muted -d--flex -flex--column -h--100 -justify-content--between">
                        <span>Past 90 days.</span>
                        <div class="-d--flex -align-items--center -g--1">
                          <chi-icon icon="circle-alert-outline" color="muted"></chi-icon>
                          <span class="-text--xs">Data can't be retrieved.</span>
                        </div>
                      </div>
                    </chi-card>
                    <chi-card title="Change Requests" type="kpi" metric="6" fixed-width> Past 30 days </chi-card>
                    <chi-card title="Network Visibility: Status" type="kpi" fixed-width id="network-visibility" info-icon-message="Helpful info here"></chi-card>
                  </div>
                </div>
              </div>
            </div>
          </chi-accordion>
        </div>

        <div class="chi-divider -my--3"></div>

        <div class="chi-grid -mb--3">
          <div class="chi-col -w--7">
            <h3>On-Demand Services Overview</h3>
            <p class="-text  -mt--0">Visualize your active on-demand services and explore expansion opportunities across our network</p>
          </div>
          <div class="chi-col -w--5">
            <div class="-d--flex -g--3 -justify-content--end -mt--2">
              <chi-button>
                <chi-icon icon="plus" size="sm"></chi-icon>
                <span>Add services</span>
              </chi-button>
              <chi-button>Manage services</chi-button>
            </div>
          </div>
        </div>

        <!-- Map section -->
        <div id="map" class="-position--relative">
          <!-- Map image -->
          <div id="map-image"></div>
          <!-- Port Availability Card -->
          <chi-card id="port-availability" variant="outline" float>
            <div class="-d--flex -flex--column -flex-xl--row -align-items--center -g--2">
              <div class="-d--inline-flex -align-items--center -g--2 -w--100 -w-xl--50 -mr--auto -mr-xl--none">
                <chi-label class="-text--nowrap">Port availability</chi-label>
                <chi-search-input placeholder="Enter a location address to check Lumen port availability"></chi-search-input>
              </div>
              <div class="-d--inline-flex -align-items--center -g--2 -mr--auto -mr-xl--none">
                <div class="chi-divider -vertical -d--none -d-xl--inline-flex" style="height: 2rem"></div>
                <chi-label>Show</chi-label>
                <chi-checkbox label="Active Services"></chi-checkbox>
                <chi-checkbox label="Available Port Locations" checked></chi-checkbox>
              </div>
            </div>
          </chi-card>
        </div>

      </chi-main>

      <!-- Help drawer -->
      <chi-drawer id="help-drawer" title="Title" position="right" backdrop>
        <chi-label size="xl">Search</chi-label>
        <chi-search-input placeholder="I need help with..."></chi-search-input>
        <div class="chi-form__item">
          <chi-label class="-mt--4 -mb--2" size="xl">Subtitle 1</chi-label>
          <chi-link class="-mb--1" href="#" size="sm">Link 1</chi-link>
          <chi-link href="#" size="sm">Link 2</chi-link>
        </div>
        <div class="chi-form__item">
          <chi-label class="-mt--4 -mb--2" size="xl">Subtitle 2</chi-label>
          <chi-link class="-mb--1" href="#" size="sm">Link 1</chi-link>
          <chi-link class="-mb--1" href="#" size="sm">Link 2</chi-link>
          <chi-link class="-mb--1" href="#" size="sm">Link 3</chi-link>
          <chi-link href="#" size="sm">Link 4</chi-link>
        </div>
        <div class="chi-divider -my--2"></div>
        <chi-link href="#" size="sm">Link</chi-link>
      </chi-drawer>

    </div>
  </div>
</div>

<script>
const servicesAccordion = document.getElementById("services");
const servicesToolsAccordion = document.getElementById("services-tools");
const servicesRequestsAccordion = document.getElementById("services-requests");
const servicesQuotesAccordion = document.getElementById("services-quotes");
const servicesPortalsAccordion = document.getElementById("services-portals");

servicesAccordion.accordions = [
  {
    title: "Services",
    icon: "list-alt",
    template: "services-template"
  }
];
servicesToolsAccordion.accordions = [
  {
    title: "Service Tools",
    template: "services-tools-template"
  }
];
servicesRequestsAccordion.accordions = [
  {
    title: "Service Requests",
    template: "services-requests-template"
  }
];
servicesQuotesAccordion.accordions = [
  {
    title: "Quotes",
    template: "services-quotes-template"
  }
];
servicesPortalsAccordion.accordions = [
  {
    title: "Service Portals",
    template: "services-portals-template"
  }
];

const apisAccordion = document.getElementById("apis");

apisAccordion.accordions = [
  {
    title: "APIs",
    icon: "api",
    template: "apis-template"
  }
];

const monitoringAndReportsAccordion = document.getElementById(
  "monitoring-and-reports"
);

monitoringAndReportsAccordion.accordions = [
  {
    title: "Monitoring & Reports",
    icon: "chart-bar",
    template: "monitoring-and-reports-template"
  }
];

const billingAccordion = document.getElementById("billing");

billingAccordion.accordions = [
  {
    title: "Billing",
    icon: "mail-open-dollar",
    template: "billing-template"
  }
];

const adminAccordion = document.getElementById("admin");

adminAccordion.accordions = [
  {
    title: "Admin",
    icon: "users",
    template: "admin-template"
  }
];

const supportAccordion = document.getElementById("support");

supportAccordion.accordions = [
  {
    title: "Support",
    icon: "life-ring",
    template: "support-template"
  }
];

const sidenavElement = document.getElementById("global-nav");
const globalNav = chi.globalNav(sidenavElement);
const toggleNavButton = document.getElementById("toggle-nav");

toggleNavButton.addEventListener(
  "click",
  () => (globalNav.expanded = !globalNav.expanded)
);

const switchers = document.querySelectorAll(".enterprise-id-switcher");
switchers.forEach((switcher) => {
  const items = switcher.querySelectorAll(".chi-dropdown__menu-item");

  items.forEach((item) => {
    item.addEventListener("click", (e) => {
      // Add custom switcher logic to update selected item
    });
  });
});

const mobileNav = document.getElementById("mobile-nav");
const mobileNavTrigger = document.getElementById("mobile-nav-trigger");
const mobileNavDrawer = document.getElementById("mobile-nav-drawer");
const enterpriseDropdown = document.getElementById("enterprise-dropdown");

chi.globalMobileNav(
  mobileNav,
  mobileNavTrigger,
  mobileNavDrawer,
  enterpriseDropdown
);

// Change icon dynamically in header for mobile-nav
mobileNavDrawer.addEventListener('chiDrawerShow', () => {
  mobileNavTrigger.querySelector('chi-icon').icon = 'x';
});

mobileNavDrawer.addEventListener('chiDrawerHide', () => {
  mobileNavTrigger.querySelector('chi-icon').icon = 'menu';
});

const coreCapabilitiesAccordion = document.getElementById("main-accordion");
coreCapabilitiesAccordion.accordions = [
  {
    title: "Core Capabilities",
    template: "core-capabilities"
  }
];

document.querySelector("#help-button").addEventListener("click", function () {
  var drawerElem = document.querySelector("#help-drawer");
  drawerElem.toggle();
});

const networkVisibilityCard = document.getElementById("network-visibility");
networkVisibilityCard.metric = [
  { label: "Down", value: "97" },
  { label: "Up", value: "143" }
];

const customizeSnapshotsPanel = document.getElementById(
  "customize-snapshots-panel"
);
const snapshots = [
  {
    label: "Pay balance due",
    description: "Outstanding balance across billing accounts",
    selected: true
  },
  {
    label: "Active repair tickets",
    description: "Active repair tickets within the past 90 days",
    selected: true
  },
  {
    label: "Open orders",
    description:
      "Lorem ipsum dolor amet Lorem ipsum dolor amet Lorem ipsum dolor amet Lorem ipsum dolor amet",
    selected: true,
    infoIcon: { message: "Permissions are required to view data from this snapshot. Please contact a system admin.", color: "danger", icon: 'circle-alert-outline' }
  },
  {
    label: "Change requests",
    description: "Lorem ipsum dolor amet",
    selected: true
  },
  {
    label: "Active portal support tickets",
    description: "Lorem ipsum dolor amet",
    selected: false
  },
  {
    label: "Disconnect requests",
    description: "Lorem ipsum dolor amet",
    infoIcon: { message: "Permissions are required to view data from this snapshot. Please contact a system admin.", color: "danger", icon: 'circle-alert-outline' },
    selected: false
  },
  {
    label: "Outstanding billing accounts",
    description: "Lorem ipsum dolor amet",
    selected: false
  },
  {
    label: "Potential repair tickets",
    description: "Lorem ipsum dolor amet",
    selected: false
  }
];

customizeSnapshotsPanel.items = snapshots;
customizeSnapshotsPanel.config = { itemsName: "Snapshots" };
customizeSnapshotsPanel.addEventListener("chiReset", (ev) =>
  console.log("Customize panel was reset")
);
<\/script>

<style>
// Project custom classes
</style>
`,Wi=S({__name:"_dashboard",props:{id:{},title:{}},setup(v){const n=v,o=N("dashboard-help-drawer"),c=N("dashboard-global-nav"),l=q(),p=N("mobile-nav"),_=N("mobile-nav-trigger"),s=N("mobile-nav-drawer"),u=N("enterprise-dropdown"),r=q("1234567"),x=W(()=>`Enterprise ID: ${r.value}`),b=[{title:"Dashboard",icon:"dashboard"},{title:"Alerts & Notifications",icon:"bell",badge:{label:"22",size:"xs"}},{title:"Services",icon:"list-alt",accordionId:"dashboard-services",templateId:"dashboard-services-template",children:[{title:"Manage Services"},{title:"Add Services"},{title:"Order Status"},{title:"Service Tools",accordionId:"dashboard-services-tools",templateId:"dashboard-services-tools-template",children:[{title:"ELS & LI Managements"},{title:"Network Storage"},{title:"Edge Bare Metal",active:!0},{title:"SASE Management"},{title:"Voice Complete Features"},{title:"+1 Switched Toll Free"},{title:"Cross Connect"},{title:"Enhanced Routing"},{title:"Manage Voicemail"},{title:"Security Certificate Management"},{title:"Toll Free Management"}]},{title:"Service Requests",accordionId:"dashboard-services-requests",templateId:"dashboard-services-requests-template",children:[{title:"Requests Page 1"},{title:"Requests Page 2"},{title:"Requests Page 3"}]},{title:"Quotes",accordionId:"dashboard-services-quotes",templateId:"dashboard-services-quotes-template",children:[{title:"Quotes Page 1"},{title:"Quotes Page 2"},{title:"Quotes Page 3"}]},{title:"Service Portals",accordionId:"dashboard-services-portals",templateId:"dashboard-services-portals-template",children:[{title:"Portals Page 1"},{title:"Portals Page 2"},{title:"Portals Page 3"}]}]},{title:"APIs",icon:"api",accordionId:"dashboard-apis",templateId:"dashboard-apis-template",children:[{title:"APIs page 1"},{title:"APIs page 2"},{title:"APIs page 3"}]},{title:"Monitoring & Reports",icon:"chart-bar",accordionId:"dashboard-monitoring-and-reports",templateId:"dashboard-monitoring-and-reports-template",children:[{title:"Monitoring & Reports page 1"},{title:"Monitoring & Reports page 2"},{title:"Monitoring & Reports page 3"}]},{title:"Billing",icon:"cost",accordionId:"dashboard-billing",templateId:"dashboard-billing-template",children:[{title:"Billing page 1"},{title:"Billing page 2"},{title:"Billing page 3"}]},{title:"Admin",icon:"users",accordionId:"dashboard-admin",templateId:"dashboard-admin-template",children:[{title:"Admin page 1"},{title:"Admin page 2"},{title:"Admin page 3"}]},{title:"Support",icon:"life-ring",accordionId:"dashboard-support",templateId:"dashboard-support-template",children:[{title:"Support page 1"},{title:"Support page 2"},{title:"Support page 3"}]}],d=[{title:"[Portal Name] Help",icon:"circle-question"},{title:"Contact Lumen",icon:"compose"}],A=[{icon:"dashboard",label:"Dashboard"},{icon:"bell",label:"Alerts & Notifications"},{icon:"list-alt",label:"Services",href:"#dashboard-mobile-nav-services-menu",hasChevron:!0,active:!0},{icon:"api",label:"APIs",href:"#dashboard-mobile-nav-apis-menu",hasChevron:!0},{icon:"chart-bar",label:"Monitoring & Reports",hasChevron:!0},{icon:"mail-open-dollar",label:"Billing",hasChevron:!0},{icon:"users",label:"Admin",hasChevron:!0},{icon:"life-ring",label:"Support",hasChevron:!0}],B=[{icon:"circle-question",label:"[Portal Name] Help"},{icon:"compose",label:"Contact Lumen"}],L=[{label:"Manage Services",href:"https://lib.lumen.com/"},{label:"Add Services"},{label:"Order Status"},{label:"Service Tools",hasChevron:!0},{label:"Service Requests",hasChevron:!0},{label:"Quotes",href:"#dashboard-mobile-nav-quotes-menu",hasChevron:!0,active:!0},{label:"Service Portals",href:"#dashboard-mobile-nav-service-portals-menu",hasChevron:!0}],F=[{label:"View APIs",href:"#dashboard-mobile-nav-view-apis-menu",hasChevron:!0},{label:"Edit APIs"},{label:"API Settings"}],Q=[{label:"View Quotes",active:!0},{label:"Create Quotes"}],R=[{label:"Service Portal 1"},{label:"Service Portal 2"}],T=[{label:"API 1"},{label:"API 2"}],D=[{id:"1234567",name:"Acme Incorporated",active:!0},{id:"1234568",name:"Acme Incorporated"},{id:"1234569",name:"Acme Incorporated",spinner:!0},{id:"1234560",name:"Acme Incorporated"}],G=[{title:"Core Capabilities",template:"core-capabilities"}],K=[{label:"Down",value:"97"},{label:"Up",value:"143"}],g=[{label:"Pay balance due",description:"Outstanding balance across billing accounts",selected:!0},{label:"Active repair tickets",description:"Active repair tickets within the past 90 days",selected:!0},{label:"Open orders",description:"Lorem ipsum dolor amet Lorem ipsum dolor amet Lorem ipsum dolor amet Lorem ipsum dolor amet",selected:!0,infoIcon:{message:"Permissions are required to view data from this snapshot. Please contact a system admin.",color:"danger",icon:"circle-alert-outline"}},{label:"Change requests",description:"Lorem ipsum dolor amet",selected:!0},{label:"Active portal support tickets",description:"Lorem ipsum dolor amet",selected:!1},{label:"Disconnect requests",description:"Lorem ipsum dolor amet",infoIcon:{message:"Permissions are required to view data from this snapshot. Please contact a system admin.",color:"danger",icon:"circle-alert-outline"},selected:!1},{label:"Outstanding billing accounts",description:"Lorem ipsum dolor amet",selected:!1},{label:"Potential repair tickets",description:"Lorem ipsum dolor amet",selected:!1}],Z=H=>{H.forEach(t=>{if(t.accordionId&&t.templateId){const U=document.getElementById(t.accordionId);U&&(U.accordions=[{title:t.title,icon:t.icon,template:t.templateId}])}t.children&&Z(t.children)})},X=async H=>{const t=H.detail.split(`
`)[0];H.currentTarget.resetSelection(),r.value=t};return ee(()=>{ie(()=>{c.value&&(l.value=chi.globalNav(c.value,{expanded:!1})),Z(b),s.value&&_.value&&(s.value.addEventListener("chiDrawerShow",()=>{_.value.querySelector("chi-icon").icon="x"}),s.value.addEventListener("chiDrawerHide",()=>{_.value.querySelector("chi-icon").icon="menu"}))})}),te([p,_,s,u],()=>{p&&_&&s&&u&&chi.globalMobileNav(p.value,_.value,s.value,u.value)}),(H,t)=>{const U=P,le=C;return i(),I(le,{title:n.title,id:n.id,showSnippetTabs:!1,padding:"-p--0"},{example:m(()=>[e("div",Be,[e("header",Ne,[t[17]||(t[17]=e("div",{class:"chi-header__brandbar"},null,-1)),e("nav",qe,[t[16]||(t[16]=e("div",{class:"chi-header__brand"},[e("chi-link",{"alternative-text":"Lumen",href:"/"},[e("chi-brand",{logo:"lumen"})]),e("span",{class:"-d--none -d-sm--flex chi-header__title"},"[Portal Name]")],-1)),e("div",Te,[e("chi-button",{id:"toggle-nav",onClick:t[0]||(t[0]=h=>M(l).expanded=!M(l).expanded),color:"dark",type:"icon",size:"lg",variant:"flat"},[...t[8]||(t[8]=[e("chi-icon",{size:"sm--3",icon:"menu"},null,-1)])])]),e("div",ze,[e("chi-button",Le,[...t[9]||(t[9]=[e("chi-icon",{size:"sm--3",icon:"menu"},null,-1)])],512)]),e("div",Re,[e("chi-dropdown",{class:"enterprise-id-switcher","select-mode":"",size:"sm",position:"bottom-end","retain-selection":M(x),button:M(x),"on:chiDropdownItemSelected":X},[t[11]||(t[11]=e("div",{class:"chi-grid",slot:"menu-header"},[e("div",{class:"chi-col -w--4"},"Enterprise ID"),e("div",{class:"chi-col -w--7"},"Enterprise Name")],-1)),(i(),a(f,null,w(D,h=>e("a",{class:$(["chi-dropdown__menu-item",{"-active":h.id===M(r)}]),key:`item-${h.id}`,slot:"menu",onClick:t[1]||(t[1]=z(()=>{},["prevent"]))},[e("div",Ve,[e("div",Oe,k(h.id),1),e("div",Qe,k(h.name),1),h.spinner?(i(),a("div",He,[...t[10]||(t[10]=[e("chi-spinner",null,null,-1)])])):E("",!0)])],2)),64)),t[12]||(t[12]=e("div",{class:"chi-divider",slot:"menu-footer"},null,-1)),t[13]||(t[13]=e("chi-link",{slot:"menu-footer"},"Manage My Enterprises",-1))],40,Fe),t[14]||(t[14]=e("div",{class:"chi-divider -vertical"},null,-1)),t[15]||(t[15]=e("chi-dropdown",{variant:"flat",button:"Menu",size:"sm",position:"bottom"},[e("a",{class:"chi-dropdown__menu-item",slot:"menu",href:"#"},[e("chi-icon",{icon:"user"}),V("Item 1")]),e("a",{class:"chi-dropdown__menu-item",slot:"menu",href:"#"},[e("chi-icon",{icon:"login"}),V("Item 2")])],-1))])])]),e("div",Ue,[e("aside",je,[e("div",We,[e("nav",null,[e("ul",Ge,[(i(),a(f,null,w(b,(h,J)=>e("li",{class:"chi-sidenav__item",key:J},[e("div",Ke,[!h.children&&!h.accordionId?(i(),a("chi-link",Je,[e("chi-icon",{icon:h.icon},null,8,Ze),h.badge?(i(),a("chi-badge",{key:0,size:h.badge.size,type:"notification","text-weight":"bold"},k(h.badge.label),9,Xe)):E("",!0),e("span",null,k(h.title),1)])):(i(),a("chi-accordion",{key:1,ref_for:!0,ref:h.accordionId,id:h.accordionId,type:"link"},[e("div",{slot:h.templateId},[e("div",ii,[(i(!0),a(f,null,w(h.children,(O,ne)=>(i(),a(f,{key:ne},[O.accordionId?(i(),a("chi-accordion",{key:0,id:O.accordionId,type:"link"},[e("div",{slot:O.templateId},[e("div",ni,[(i(!0),a(f,null,w(O.children,(Y,ce)=>(i(),a("chi-link",{key:ce,class:$({"-active":Y.active})},k(Y.title),3))),128))])],8,li)],8,ti)):(i(),a("chi-link",{key:1,class:$({"-active":O.active})},k(O.title),3))],64))),128))])],8,ei)],8,Ye))])])),64)),t[18]||(t[18]=e("div",{class:"chi-divider"},null,-1)),(i(),a(f,null,w(d,(h,J)=>e("li",{class:"chi-sidenav__item",key:"footer-"+J},[e("div",ci,[e("chi-link",null,[e("chi-icon",{icon:h.icon},null,8,oi),e("span",null,k(h.title),1)])])])),64))])])])],512),e("div",{class:"chi-mobile-nav -global",id:"mobileNav",ref_key:"mobileNav",ref:p},[e("chi-drawer",{ref:"mobile-nav-drawer",onClick:t[3]||(t[3]=z(()=>{},["prevent"]))},[e("div",ai,[e("div",si,[e("chi-dropdown",{class:"enterprise-id-switcher",ref:"enterprise-dropdown",position:"bottom",size:"sm","select-mode":"","retain-selection":M(x),button:M(x),"on:chiDropdownItemSelected":X},[t[20]||(t[20]=e("div",{slot:"menu-header"},[e("div",{class:"chi-grid"},[e("div",{class:"chi-col -w--4"},"Enterprise ID"),e("div",{class:"chi-col -w--7"},"Enterprise Name")])],-1)),(i(),a(f,null,w(D,h=>e("a",{class:$(["chi-dropdown__menu-item",{"-active":h.id===M(r)}]),key:h.id,slot:"menu",href:"#",onClick:t[2]||(t[2]=z(()=>{},["prevent"]))},[e("div",di,[e("div",hi,k(h.id),1),e("div",pi,k(h.name),1),h.spinner?(i(),a("div",mi,[...t[19]||(t[19]=[e("chi-spinner",null,null,-1)])])):E("",!0)])],2)),64)),t[21]||(t[21]=e("div",{class:"chi-divider",slot:"menu-footer"},null,-1)),t[22]||(t[22]=e("chi-link",{slot:"menu-footer"},"Manage My Enterprises",-1))],40,ri)]),t[23]||(t[23]=e("div",{class:"chi-divider -my--0"},null,-1)),e("ul",ui,[(i(),a(f,null,w(A,h=>e("li",{class:"chi-mobile-nav__item",key:h.label},[e("chi-link",{href:h.href,class:$({"-active":h.active})},[h.icon?(i(),a("chi-icon",{key:0,icon:h.icon},null,8,bi)):E("",!0),e("span",null,k(h.label),1),h.hasChevron?(i(),a("chi-icon",_i)):E("",!0)],10,vi)])),64))]),t[24]||(t[24]=e("div",{class:"chi-divider -my--0"},null,-1)),e("ul",gi,[(i(),a(f,null,w(B,h=>e("li",{class:"chi-mobile-nav__item",key:h.label},[e("chi-link",{href:h.href},[e("chi-icon",{icon:h.icon},null,8,fi),e("span",null,k(h.label),1)],8,ki)])),64))]),t[25]||(t[25]=e("div",{class:"chi-divider -my--0"},null,-1)),t[26]||(t[26]=e("ul",{class:"chi-mobile-nav__list"},[e("li",{class:"chi-mobile-nav__item"},[e("span",{class:"chi-mobile-nav__email"},"jamie.johnson@company.com")]),e("li",{class:"chi-mobile-nav__item"},[e("chi-link",null,[e("chi-icon",{icon:"user"}),e("span",null,"My Profile")])]),e("li",{class:"chi-mobile-nav__item"},[e("chi-link",null,[e("chi-icon",{icon:"logout"}),e("span",null,"Sign out")])])],-1))]),e("div",wi,[e("ul",yi,[(i(),a(f,null,w(L,h=>e("li",{class:"chi-mobile-nav__item",key:h.label},[e("chi-link",{href:h.href,class:$({"-active":h.active})},[e("span",null,k(h.label),1),h.hasChevron?(i(),a("chi-icon",Ii)):E("",!0)],10,xi)])),64))])]),e("div",Si,[e("ul",Ci,[(i(),a(f,null,w(F,h=>e("li",{class:"chi-mobile-nav__item",key:h.label},[e("chi-link",{href:h.href,class:$({"-active":h.active})},[e("span",null,k(h.label),1),h.hasChevron?(i(),a("chi-icon",Ai)):E("",!0)],10,Pi)])),64))])]),e("div",Di,[e("ul",Ei,[(i(),a(f,null,w(Q,h=>e("li",{class:"chi-mobile-nav__item",key:h.label},[e("chi-link",{class:$({"-active":h.active})},k(h.label),3)])),64))])]),e("div",$i,[e("ul",Mi,[(i(),a(f,null,w(R,h=>e("li",{class:"chi-mobile-nav__item",key:h.label},[e("chi-link",{class:$({"-active":h.active})},k(h.label),3)])),64))])]),e("div",Bi,[e("ul",Ni,[(i(),a(f,null,w(T,h=>e("li",{class:"chi-mobile-nav__item",key:h.label},[e("chi-link",{class:$({"-active":h.active})},k(h.label),3)])),64))])])],512)],512),e("div",qi,[e("chi-main",Ti,[e("chi-button",{onClick:t[4]||(t[4]=(...h)=>o.value.toggle&&o.value.toggle(...h)),slot:"help-icon","extra-class":"-bg--white"},[...t[27]||(t[27]=[e("chi-icon",{size:"sm",icon:"circle-question-outline"},null,-1),e("span",null,"Help",-1)])]),t[39]||(t[39]=e("chi-alert",{slot:"page-alert",icon:"circle-info",title:"[Page pilot banner title]",toast:"",closable:""},"[Page pilot banner message content]",-1)),e("div",zi,[e("chi-accordion",{portal:"",accordions:G},[e("div",Li,[t[38]||(t[38]=e("p",{class:"-text -mb--3"},"Access tools to locate services, monitor open orders, review requests and tickets, and manage invoices effortlessly.",-1)),e("div",Ri,[e("div",Fi,[e("chi-card",Vi,[e("div",Oi,[e("chi-link",{onClick:t[5]||(t[5]=z(()=>{},["prevent"])),size:"md","no-underline":""},"Manage services")]),t[28]||(t[28]=e("div",{class:"-mt--2 chi-form__item"},[e("chi-label",null,"Find by Service ID"),e("chi-search-input",{placeholder:"Service ID, Nickname, or Location"})],-1)),t[29]||(t[29]=e("div",{class:"-mt--3 chi-form__item"},[e("chi-label",null,"Find by Product or Service Tool"),e("chi-dropdown-select",{button:"Select a product or service tool"})],-1))]),t[30]||(t[30]=e("div",{class:"accordion-cards -d--flex -flex--column -g--2"},[e("chi-card",{notifications:"22",type:"alert",variant:"outline",title:"Alerts"},[e("chi-card",{class:"alert__inner-card",type:"compact-title",eyebrow:"[Product/Service Name]",variant:"outline",title:"[Alert title]"},[e("div",{slot:"compact-title"},[e("chi-dropdown",{variant:"flat",icon:"more-vert"},[e("a",{class:"chi-dropdown__menu-item",slot:"menu"},"Item 1"),e("a",{class:"chi-dropdown__menu-item",slot:"menu"},"Item 2"),e("a",{class:"chi-dropdown__menu-item",slot:"menu"},"Item 3")])]),e("div",{class:"alert__inner-content"},[e("chi-link",null,"ID 123456567"),e("chi-badge",{color:"muted"},"Email Sent")])]),e("chi-card",{class:"alert__inner-card",type:"compact-title",eyebrow:"[Product/Service Name]",variant:"outline",title:"[Alert title]"},[e("div",{slot:"compact-title"},[e("chi-dropdown",{variant:"flat",icon:"more-vert"},[e("a",{class:"chi-dropdown__menu-item",slot:"menu"},"Item 1"),e("a",{class:"chi-dropdown__menu-item",slot:"menu"},"Item 2"),e("a",{class:"chi-dropdown__menu-item",slot:"menu"},"Item 3")])]),e("div",{class:"alert__inner-content"},[e("chi-link",null,"ID 123456567"),e("chi-badge",{color:"muted"},"Email Sent")])]),e("chi-card",{class:"alert__inner-card",type:"compact-title",eyebrow:"[Product/Service Name]",variant:"outline",title:"[Alert title]"},[e("div",{slot:"compact-title"},[e("chi-dropdown",{variant:"flat",icon:"more-vert"},[e("a",{class:"chi-dropdown__menu-item",slot:"menu"},"Item 1"),e("a",{class:"chi-dropdown__menu-item",slot:"menu"},"Item 2"),e("a",{class:"chi-dropdown__menu-item",slot:"menu"},"Item 3")])]),e("div",{class:"alert__inner-content"},[e("chi-link",null,"ID 123456567"),e("chi-badge",{color:"muted"},"Email Sent")])]),e("chi-card",{class:"alert__inner-card",type:"compact-title",eyebrow:"[Product/Service Name]",variant:"outline",title:"[Alert title]"},[e("div",{slot:"compact-title"},[e("chi-dropdown",{variant:"flat",icon:"more-vert"},[e("a",{class:"chi-dropdown__menu-item",slot:"menu"},"Item 1"),e("a",{class:"chi-dropdown__menu-item",slot:"menu"},"Item 2"),e("a",{class:"chi-dropdown__menu-item",slot:"menu"},"Item 3")])]),e("div",{class:"alert__inner-content"},[e("chi-link",null,"ID 123456567"),e("chi-badge",{color:"muted"},"Email Sent")])]),e("chi-card",{class:"alert__inner-card",type:"compact-title",eyebrow:"[Product/Service Name]",variant:"outline",title:"[Alert title]"},[e("div",{slot:"compact-title"},[e("chi-dropdown",{variant:"flat",icon:"more-vert"},[e("a",{class:"chi-dropdown__menu-item",slot:"menu"},"Item 1"),e("a",{class:"chi-dropdown__menu-item",slot:"menu"},"Item 2"),e("a",{class:"chi-dropdown__menu-item",slot:"menu"},"Item 3")])]),e("div",{class:"alert__inner-content"},[e("chi-link",null,"ID 123456567"),e("chi-badge",{color:"muted"},"Email Sent")])]),e("chi-card",{class:"alert__inner-card",type:"compact-title",eyebrow:"[Product/Service Name]",variant:"outline",title:"[Alert title]"},[e("div",{slot:"compact-title"},[e("chi-dropdown",{variant:"flat",icon:"more-vert"},[e("a",{class:"chi-dropdown__menu-item",slot:"menu"},"Item 1"),e("a",{class:"chi-dropdown__menu-item",slot:"menu"},"Item 2"),e("a",{class:"chi-dropdown__menu-item",slot:"menu"},"Item 3")])]),e("div",{class:"alert__inner-content"},[e("chi-link",null,"ID 123456567"),e("chi-badge",{color:"muted"},"Email Sent")])])]),e("chi-card",{variant:"outline",type:"accordion",title:"Scheduled Maintenance"},[e("div",{class:"-w--100 -text--left",slot:"card-accordion-header"},[e("chi-link",{size:"md"},"View all")]),e("chi-date")]),e("chi-card",{variant:"outline",type:"accordion",title:"Favourite Pages"},[e("p",{class:"-text -my--2"},"These are the top pages you visit most often — up to 8 of your most frequently accessed."),e("div",{class:"chi-grid"},[e("div",{class:"chi-col -w--6 -mt--1"},[e("chi-link",{"no-underline":""},"Favourite Page 1")]),e("div",{class:"chi-col -w--6 -mt--1"},[e("chi-link",{"no-underline":""},"Favourite Page 2")]),e("div",{class:"chi-col -w--6 -mt--1"},[e("chi-link",{"no-underline":""},"Favourite Page 3")]),e("div",{class:"chi-col -w--6 -mt--1"},[e("chi-link",{"no-underline":""},"Favourite Page 4 With a Longer Title")]),e("div",{class:"chi-col -w--6 -mt--1"},[e("chi-link",{"no-underline":""},"Favourite Page 5")]),e("div",{class:"chi-col -w--6 -mt--1"},[e("chi-link",{"no-underline":""},"Favourite Page 6")]),e("div",{class:"chi-col -w--6 -mt--1"},[e("chi-link",{"no-underline":""},"Favourite Page 7")]),e("div",{class:"chi-col -w--6 -mt--1"},[e("chi-link",{"no-underline":""},"Favourite Page 8")])])])],-1))]),t[37]||(t[37]=e("div",{class:"chi-divider -my--3"},null,-1)),e("div",Qi,[e("div",Hi,[t[31]||(t[31]=e("span",{class:"-text--bold"},"Snapshots",-1)),e("chi-customize-panel",{class:"-ml--2","on:chiReset":t[7]||(t[7]=()=>console.log("Customize panel was reset")),items:g,config:{itemsName:"Snapshots"}},[e("chi-link",{onClick:t[6]||(t[6]=z(()=>{},["prevent"])),slot:"trigger",size:"md"},"Customize")],32)]),e("div",{class:"-d--flex -flex--wrap -g--2 snapshots-dashboard-wrapper"},[t[32]||(t[32]=e("chi-card",{id:"dashboard-payBalanceDue","fixed-width":"",metric:"$3,000,130.87",type:"kpi",title:"Pay Balance Due"},null,-1)),t[33]||(t[33]=e("chi-card",{"fixed-width":"",metric:"23",type:"kpi",title:"Active Repair Tickets"},"Past 90 days",-1)),t[34]||(t[34]=e("chi-card",{"fixed-width":"",metric:"26",type:"kpi",title:"Disconnect Requests"},"Past 30 days",-1)),t[35]||(t[35]=e("chi-card",{"fixed-width":"",title:"Open Orders",type:"kpi"},[e("div",{class:"-text--muted -d--flex -flex--column -h--100 -justify-content--between"},[e("span",null,"Past 90 days."),e("div",{class:"-d--flex -align-items--center -g--1"},[e("chi-icon",{color:"muted",icon:"circle-alert-outline"}),e("span",{class:"-text--xs"},"Data can't be retrieved.")])])],-1)),t[36]||(t[36]=e("chi-card",{"fixed-width":"",metric:"6",type:"kpi",title:"Change Requests"},"Past 30 days",-1)),e("chi-card",{"info-icon-message":"Helpful info here","fixed-width":"",type:"kpi",title:"Network Visibility: Status",metric:K})])])])])])]),t[40]||(t[40]=e("div",{class:"chi-divider -my--3"},null,-1)),t[41]||(t[41]=e("div",{class:"chi-grid -mb--3"},[e("div",{class:"chi-col -w--7"},[e("h3",null,"On-Demand Services Overview"),e("p",{class:"-text -mt--0"},"Visualize your active on-demand services and explore expansion opportunities across our network")]),e("div",{class:"chi-col -w--5"},[e("div",{class:"-d--flex -g--3 -justify-content--end -mt--2"},[e("chi-button",null,[e("chi-icon",{size:"sm",icon:"plus"}),e("span",null,"Add services")]),e("chi-button",null,"Manage services")])])],-1)),t[42]||(t[42]=e("div",{class:"-position--relative",id:"dashboard-map"},[e("div",{id:"dashboard-map-image"}),e("chi-card",{id:"dashboard-port-availability",variant:"outline",float:""},[e("div",{class:"-d--flex -flex--column -flex-xl--row -align-items--center -g--2"},[e("div",{class:"-d--inline-flex -align-items--center -g--2 -w--100 -w-xl--50 -mr--auto -mr-xl--none"},[e("chi-label",{class:"-text--nowrap"},"Port availability"),e("chi-search-input",{placeholder:"Enter a location address to check Lumen port availability"})]),e("div",{class:"-d--inline-flex -align-items--center -g--2 -mr--auto -mr-xl--none"},[e("div",{class:"chi-divider -vertical -d--none -d-xl--inline-flex",style:{height:"2rem"}}),e("chi-label",null,"Show"),e("chi-checkbox",{label:"Active Services"}),e("chi-checkbox",{checked:"",label:"Available Port Locations"})])])])],-1))]),e("chi-drawer",Ui,[...t[43]||(t[43]=[e("chi-label",{size:"xl"},"Search",-1),e("chi-search-input",{placeholder:"I need help with..."},null,-1),e("div",{class:"chi-form__item"},[e("chi-label",{class:"-mt--4 -mb--2",size:"xl"},"Subtitle 1"),e("chi-link",{class:"-mb--1",size:"sm",href:"#"},"Link 1"),e("chi-link",{size:"sm",href:"#"},"Link 2")],-1),e("div",{class:"chi-form__item"},[e("chi-label",{class:"-mt--4 -mb--2",size:"xl"},"Subtitle 2"),e("chi-link",{class:"-mb--1",size:"sm",href:"#"},"Link 1"),e("chi-link",{class:"-mb--1",size:"sm",href:"#"},"Link 2"),e("chi-link",{class:"-mb--1",size:"sm",href:"#"},"Link 3"),e("chi-link",{size:"sm",href:"#"},"Link 4")],-1),e("div",{class:"chi-divider -my--2"},null,-1),e("chi-link",{size:"sm",href:"#"},"Link",-1)])],512)])])])]),"code-htmlblueprint":m(()=>[y(U,{class:"html",lang:"html",code:ji})]),_:1},8,["title","id"])}}}),Gi=se(Wi,[["__scopeId","data-v-502debb4"]]),Ki=["icon","color"],Ji={class:"-text--truncate -pl--1"},Zi=S({__name:"_data_table",props:{id:{},title:{}},setup(v){const n=v,o=pe,c={head:he,body:de};return(l,p)=>{const _=j("ChiDataTable"),s=C;return i(),I(s,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[y(_,{config:M(o),dataTableData:c,ref:"dataTableComplex"},{status:m(u=>[e("chi-icon",{icon:u.icon,color:u.color,"aria-hidden":"true"},null,8,Ki),e("span",Ji,k(u.status),1)]),name:m(u=>[(i(),I(me,{name:u.name,id:u.id,key:u.id},null,8,["name","id"]))]),_:1},8,["config"])]),"code-htmlblueprint":m(()=>[y(re)]),_:1},8,["title","id"])}}}),Xi=`<!-- Base Date Picker -->
<chi-date-picker></chi-date-picker>

<!-- Date Picker with Predefined Value, Min and Max -->
<chi-date-picker value="11/15/2025" min="11/05/2025" max="11/25/2025"></chi-date-picker>

<!-- Disabled Date Picker -->
<chi-date-picker disabled></chi-date-picker>
`,Yi=S({__name:"_date_picker",props:{id:{},title:{}},setup(v){const n=v;return(o,c)=>{const l=P,p=C;return i(),I(p,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[...c[0]||(c[0]=[e("div",{class:"-d--flex -flex--wrap -g--2"},[e("chi-date-picker"),e("chi-date-picker",{value:"11/15/2025",min:"11/05/2025",max:"11/25/2025"}),e("chi-date-picker",{disabled:""})],-1)])]),"code-htmlblueprint":m(()=>[y(l,{class:"html",lang:"html",code:Xi})]),_:1},8,["title","id"])}}}),et=`<chi-drag id="drag-example"></chi-drag>

<script>
  const drag = document.getElementById('drag-example');

  drag.items = [
    { data: { title: 'Drag title 1', description: 'Drag description 1' }},
    { data: { title: 'Drag title 2', description: 'Drag description 2' }},
    { data: { title: 'Drag title 3', description: 'Drag description 3' }},
    { data: { title: 'Drag title 4', description: 'Drag description 4' }},
  ];
<\/script>
`,it=S({__name:"_drag_and_drop",props:{id:{},title:{}},setup(v){const n=v,o=[{data:{title:"Drag title 1",description:"Drag description 1"}},{data:{title:"Drag title 2",description:"Drag description 2"}},{data:{title:"Drag title 3",description:"Drag description 3"}},{data:{title:"Drag title 4",description:"Drag description 4"}}];return(c,l)=>{const p=P,_=C;return i(),I(_,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[e("chi-drag",{items:o})]),"code-htmlblueprint":m(()=>[y(p,{class:"html",lang:"html",code:et})]),_:1},8,["title","id"])}}}),tt={class:"-d--flex -flex--column -justify-content--center"},lt=`<!-- Trigger Button -->
<chi-button id="drawer-trigger" variant="flat" type="icon">
  <chi-icon icon="menu" size="sm--2"></chi-icon>
  <span>Click to open drawer</span>
</chi-button>

<!-- Drawer -->
<chi-drawer id="drawer" title="Drawer title" position="left" backdrop backlink="Back link" backlinkHref="#drawer">
  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>

  <div slot="footer" class="-d--flex">
    <chi-button color="primary">Save</chi-button>
    <chi-button>Reset</chi-button>
    <chi-button variant="flat">Cancel</chi-button>
  </div>
</chi-drawer>

<script>
  const trigger = document.getElementById('drawer-trigger');
  
  trigger.addEventListener('click', () => {
    const drawer = document.getElementById('drawer');
    
    drawer.toggle();
    // Or:
    // drawer.active = !drawer.active;
  });
<\/script>
`,nt=S({__name:"_drawer",props:{id:{},title:{}},setup(v){const n=v,o=N("drawer");return(c,l)=>{const p=P,_=C;return i(),I(_,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[e("div",tt,[e("chi-button",{variant:"flat",type:"icon",onClick:l[0]||(l[0]=s=>o.value.toggle())},[...l[1]||(l[1]=[e("chi-icon",{icon:"menu",size:"sm--2"},null,-1),e("span",null,"Click to open drawer",-1)])]),e("chi-drawer",{ref_key:"drawer",ref:o,title:"Drawer title",position:"left",backdrop:"",backlink:"Back link",backlinkHref:"#drawer"},[(i(),a(f,null,w(6,s=>(i(),a(f,{key:s},[l[2]||(l[2]=e("p",null,"Lorem ipsum dolor sit amet, consectetur adipisicing elit.",-1)),l[3]||(l[3]=e("p",null,"Adipisci aliquid amet aspernatur commodi consectetur cupiditate exercitationem iusto minima",-1)),l[4]||(l[4]=e("p",null,"numquam officia perferendis praesentium, repellendus sapiente sed ut velit, vitae. Nulla, vero?",-1))],64))),64)),l[5]||(l[5]=e("div",{class:"-d--flex",slot:"footer",style:{gap:"1rem"}},[e("chi-button",{color:"primary"},"Save"),e("chi-button",null,"Reset"),e("chi-button",{variant:"flat"},"Cancel")],-1))],512)])]),"code-htmlblueprint":m(()=>[y(p,{class:"html",lang:"html",code:lt})]),_:1},8,["title","id"])}}}),ct=`<!-- Base dropdown -->
<chi-dropdown-select class="dropdown-select-base" button="Base dropdown"></chi-dropdown-select>

<!-- Multiple dropdown -->
<chi-dropdown-select class="dropdown-select-multiple" button="Dropdown multiple" multiple search></chi-dropdown-select>

<!-- Disabled dropdown -->
<chi-dropdown-select class="dropdown-select-disabled" button="Disabled dropdown" disabled></chi-dropdown-select>

<script>
  const dropdownSelectBase = document.getElementById('dropdown-select-base');
  const dropdownSelectMultiple = document.getElementById('dropdown-select-multiple');
  const dropdownSelectDisabled = document.getElementById('dropdown-select-disabled');

  dropdownSelectBase.items = dropdownSelectMultiple.items = dropdownSelectDisabled.items = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
    { label: 'Option 4' },
    { label: 'Option 5' },
  ];
<\/script>
`,ot=S({__name:"_dropdown_select",props:{id:{},title:{}},setup(v){const n=v,o=[{label:"Option 1"},{label:"Option 2"},{label:"Option 3"},{label:"Option 4"},{label:"Option 5"}];return(c,l)=>{const p=P,_=C;return i(),I(_,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[e("div",{class:"-d--flex -flex--wrap -g--2"},[e("chi-dropdown-select",{button:"Base dropdown",items:o}),e("chi-dropdown-select",{button:"Dropdown multiple",items:o,multiple:"",search:""}),e("chi-dropdown-select",{button:"Disabled dropdown",items:o,disabled:""})])]),"code-htmlblueprint":m(()=>[y(p,{class:"html",lang:"html",code:ct})]),_:1},8,["title","id"])}}}),at={class:"-d--flex -flex--wrap -g--4"},st=`<!-- Base input -->
<input type="file" class="chi-file-input" id="base-input" aria-label="Choose file">
<label for="base-input">No file chosen</label>

<!-- Multiple input -->
<input type="file" class="chi-file-input" id="multiple-input" aria-label="Choose files" multiple>
<label for="multiple-input">No files chosen</label>

<!-- Disabled input -->
<input type="file" class="chi-file-input" id="disabled-input" aria-label="Choose file" disabled>
<label for="disabled-input">Disabled file input</label>

<script>
  document.querySelectorAll('input[type="file"].chi-file-input').forEach(input => {
    input.addEventListener('change', () => {
      const { files, value, nextElementSibling: label } = input;
      const fileName = files?.length > 1 ? files.length + ' files selected' : value.split('\\\\').pop();
      if (label && fileName) label.textContent = fileName;
    });
  });
<\/script>
`,rt=S({__name:"_file_input",props:{id:{},title:{}},setup(v){const n=v,o=c=>{const l=c.target,{files:p,value:_,nextElementSibling:s}=l,u=p?.length>1?`${p.length} files selected`:_.split("\\").pop();s&&u&&(s.innerHTML=u)};return(c,l)=>{const p=P,_=C;return i(),I(_,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[e("div",at,[e("section",null,[e("input",{class:"chi-file-input",onChange:o,type:"file","aria-label":"Choose file",id:"base-input"},null,32),l[0]||(l[0]=e("label",{for:"base-input"},"No file choosen",-1))]),e("section",null,[e("input",{class:"chi-file-input",onChange:o,type:"file","aria-label":"Choose files",id:"multiple-input",multiple:""},null,32),l[1]||(l[1]=e("label",{for:"multiple-input"},"No files choosen",-1))]),e("section",null,[e("input",{class:"chi-file-input",onChange:o,type:"file","aria-label":"Choose file",id:"disabled-input",disabled:""},null,32),l[2]||(l[2]=e("label",{for:"disabled-input"},"Disabled file input",-1))])])]),"code-htmlblueprint":m(()=>[y(p,{class:"html",lang:"html",code:st})]),_:1},8,["title","id"])}}}),dt=`<!-- Base Footer -->
<footer class="chi-footer -row">
  <div class="chi-footer__content">
    <div class="chi-footer__internal">
      <div class="chi-footer__internal-content">
        <div class="chi-footer__copyright">&copy; 2026 Lumen Technologies. All Rights Reserved. Lumen is a registered trademark in the United States, EU and certain other countries.</div>
        <div class="chi-footer__links">
          <chi-link href="https://www.lumen.com/en-us/about.html">About Us</chi-link>
          <chi-link href="https://www.lumen.com/en-us/about/accessibility.html">Accessibility</chi-link>
          <chi-link href="#">Business Referral Program</chi-link>
          <chi-link href="https://www.lumen.com/en-us/about/legal/commission-for-complaints-for-telecom-television-services-ccts.html">Canadian Ombudsman</chi-link>
          <chi-link href="https://jobs.lumen.com" target="_blank">Careers</chi-link>
          <chi-link href="https://www.lumen.com/en-us/contact-us.html">Contact Us</chi-link>
          <chi-link href="#">Cookie Settings</chi-link>
          <chi-link href="https://www.lumen.com/en-us/about/governance.html">Governance</chi-link>
          <chi-link href="https://www.lumen.com/en-us/about/legal.html">Legal</chi-link>
          <chi-link href="https://www.lumen.com/en-us/about/legal/privacy-center.html">Privacy</chi-link>
          <chi-link href="https://www.lumen.com/en-us/about/public-policy.html">Public Policy</chi-link>
          <chi-link href="https://docs.lumen.com" target="_blank">Support</chi-link>
        </div>
      </div>
    </div>
  </div>
</footer>
`,ht=S({__name:"_footer",props:{id:{},title:{}},setup(v){const n=v;return(o,c)=>{const l=P,p=C;return i(),I(p,{title:n.title,id:n.id,showSnippetTabs:!1,additionalClasses:"-bg--grey-20"},{example:m(()=>[...c[0]||(c[0]=[e("footer",{class:"chi-footer -row"},[e("div",{class:"chi-footer__content"},[e("div",{class:"chi-footer__internal"},[e("div",{class:"chi-footer__internal-content"},[e("div",{class:"chi-footer__copyright"},"© 2026 Lumen Technologies. All Rights Reserved. Lumen is a registered trademark in the United States, EU and certain other countries."),e("div",{class:"chi-footer__links"},[e("chi-link",{href:"https://www.lumen.com/en-us/about.html"},"About Us"),e("chi-link",{href:"https://www.lumen.com/en-us/about/accessibility.html"},"Accessibility"),e("chi-link",{href:"#"},"Business Referral Program"),e("chi-link",{href:"https://www.lumen.com/en-us/about/legal/commission-for-complaints-for-telecom-television-services-ccts.html"},"Canadian Ombudsman"),e("chi-link",{target:"_blank",href:"https://jobs.lumen.com"},"Careers"),e("chi-link",{href:"https://www.lumen.com/en-us/contact-us.html"},"Contact Us"),e("chi-link",{href:"#"},"Cookie Settings"),e("chi-link",{href:"https://www.lumen.com/en-us/about/governance.html"},"Governance"),e("chi-link",{href:"https://www.lumen.com/en-us/about/legal.html"},"Legal"),e("chi-link",{href:"https://www.lumen.com/en-us/about/legal/privacy-center.html"},"Privacy"),e("chi-link",{href:"https://www.lumen.com/en-us/about/public-policy.html"},"Public Policy"),e("chi-link",{target:"_blank",href:"https://docs.lumen.com"},"Support")])])])])],-1)])]),"code-htmlblueprint":m(()=>[y(l,{class:"html",lang:"html",code:dt})]),_:1},8,["title","id"])}}}),pt={class:"chi-header -lg"},mt={class:"chi-header__content"},ut={class:"chi-header__end -d--none -d-lg--flex"},vt=["retain-selection","button"],bt={class:"chi-grid"},_t={class:"chi-col -w--4"},gt={class:"chi-col -w--7"},kt={key:0,class:"chi-col -w--1"},ft={position:"bottom",size:"sm",button:"user@lumen.com",variant:"flat"},wt=["icon"],yt={class:"chi-header -impersonation -lg -mt--4"},xt={class:"chi-header__content"},It={class:"chi-header__end -d-lg--flex -d--none"},St=["retain-selection","button"],Ct={class:"chi-grid"},Pt={class:"chi-col -w--4"},At={class:"chi-col -w--7"},Dt={key:0,class:"chi-col -w--1"},Et={position:"bottom",size:"sm",button:"user@lumen.com",variant:"flat"},$t=["icon"],Mt=`<!-- Base Header -->
<header class="chi-header -lg">
  <div class="chi-header__brandbar"></div>
  <nav class="chi-header__content">
    <div class="chi-header__brand">
      <chi-link href="/" alternative-text="Lumen">
        <chi-brand logo="lumen"/>
      </chi-link>
      <span class="chi-header__title">[Portal Name]</span>
    </div>
    <div class="chi-header__start">
      <chi-button id="toggle-nav" variant="flat" size="lg" type="icon" color="dark" class="-d--flex -d-lg--none -d-xl--flex">
        <chi-icon icon="menu" size="sm--3"></chi-icon>
      </chi-button>
    </div>
    <div class="chi-header__end -d--none -d-lg--flex">
      <chi-dropdown id="enterprise-switcher" class="enterprise-id-switcher" position="bottom-end" button="Enterprise ID: 1234567" size="sm" select-mode>
        <div class="chi-grid" slot="menu-header">
          <div class="chi-col -w--4">Enterprise ID</div>
          <div class="chi-col -w--7">Enterprise Name</div>
        </div>
        <a class="chi-dropdown__menu-item -active" slot="menu">
          <div class="chi-grid">
            <div class="chi-col -w--4">1234567</div>
            <div class="chi-col -w--7">Acme Incorporated</div>
          </div>
        </a>
        <a class="chi-dropdown__menu-item" slot="menu">
          <div class="chi-grid">
            <div class="chi-col -w--4">1234568</div>
            <div class="chi-col -w--7">Acme Incorporated</div>
          </div>
        </a>
        <a class="chi-dropdown__menu-item" slot="menu">
          <div class="chi-grid">
            <div class="chi-col -w--4">1234569</div>
            <div class="chi-col -w--7">Acme Incorporated</div>
            <div class="chi-col -w--1"><chi-spinner></chi-spinner></div>
          </div>
        </a>
        <a class="chi-dropdown__menu-item" slot="menu">
          <div class="chi-grid">
            <div class="chi-col -w--4">1234560</div>
            <div class="chi-col -w--7">Acme Incorporated</div>
          </div>
        </a>
        <div class="chi-divider" slot="menu-footer"></div>
        <chi-link slot="menu-footer">Manage My Enterprises</chi-link>
      </chi-dropdown>
      <div class="chi-divider -vertical"></div>
      <chi-dropdown position="bottom" size="sm" button="user@lumen.com" variant="flat">
        <a class="chi-dropdown__menu-item" href="#" slot="menu">
          <chi-icon icon="user"></chi-icon>
          My profile
        </a>
        <a class="chi-dropdown__menu-item" href="#" slot="menu">
          <chi-icon icon="login"></chi-icon>
          Sign out
        </a>
      </chi-dropdown>
    </div>
  </nav>
</header>

<!-- Header with Impersonation Bar -->
<header class="chi-header -impersonation -lg">
  <div class="chi-impersonation-bar">
    <div class="chi-impersonation-bar__content">
      <span class="chi-impersonation-bar__label">Signed in as:</span>
      <strong class="chi-impersonation-bar__username">User</strong>
      <div class="chi-impersonation-bar__divider chi-divider -inverse -vertical -h--75"></div>
      <button
        id="button-logout"
        class="chi-button -flat -light -xs -icon -no-hover -b--0"
        aria-label="Log out"
        data-tooltip="Log out"
        data-position="bottom"
      >
        <div class="chi-button__content">
          <chi-icon icon="logout" size="xs"></chi-icon>
        </div>
      </button>
    </div>
  </div>
  <nav class="chi-header__content">
    <div class="chi-header__brand">
      <chi-link href="#" alternative-text="Lumen">
        <chi-brand logo="lumen"/>
      </chi-link>
      <span class="chi-header__title">[Portal Name]</span>
    </div>
    <div class="chi-header__start">
      <chi-button id="toggle-nav" variant="flat" size="lg" type="icon" color="dark" class="-d--flex -d-lg--none -d-xl--flex">
        <chi-icon icon="menu" size="sm--3"></chi-icon>
      </chi-button>
    </div>
    <div class="chi-header__end -d--none -d-lg--flex">
      <chi-dropdown
        id="enterprise-switcher"
        class="enterprise-id-switcher"
        position="bottom-end"
        button="Enterprise ID: 1234567"
        size="sm"
        select-mode
      >
        <div class="chi-grid" slot="menu-header">
          <div class="chi-col -w--4">Enterprise ID</div>
          <div class="chi-col -w--7">Enterprise Name</div>
        </div>
        <a class="chi-dropdown__menu-item -active" slot="menu">
          <div class="chi-grid">
            <div class="chi-col -w--4">1234567</div>
            <div class="chi-col -w--7">Acme Incorporated</div>
          </div>
        </a>
        <a class="chi-dropdown__menu-item" slot="menu">
          <div class="chi-grid">
            <div class="chi-col -w--4">1234568</div>
            <div class="chi-col -w--7">Acme Incorporated</div>
          </div>
        </a>
        <a class="chi-dropdown__menu-item" slot="menu">
          <div class="chi-grid">
            <div class="chi-col -w--4">1234569</div>
            <div class="chi-col -w--7">Acme Incorporated</div>
            <div class="chi-col -w--1"><chi-spinner></chi-spinner></div>
          </div>
        </a>
        <a class="chi-dropdown__menu-item" slot="menu">
          <div class="chi-grid">
            <div class="chi-col -w--4">1234560</div>
            <div class="chi-col -w--7">Acme Incorporated</div>
          </div>
        </a>
        <div class="chi-divider" slot="menu-footer"></div>
        <chi-link slot="menu-footer">Manage My Enterprises</chi-link>
      </chi-dropdown>
      <div class="chi-divider -vertical"></div>
      <chi-dropdown position="bottom" size="sm" button="user@lumen.com" variant="flat">
        <a class="chi-dropdown__menu-item" href="#" slot="menu">
          <chi-icon icon="user"></chi-icon>
          My profile
        </a>
        <a class="chi-dropdown__menu-item" href="#" slot="menu">
          <chi-icon icon="login"></chi-icon>
          Sign out
        </a>
      </chi-dropdown>
    </div>
  </nav>
</header>

<script>
  const switcher = document.getElementById('enterprise-switcher');

  switcher.addEventListener('chiDropdownItemSelected', (e) => {
    // Implement your logic here
  });
<\/script>
`,Bt=S({__name:"_header",props:{id:{},title:{}},setup(v){const n=v,o=q("1234567"),c=W(()=>`Enterprise ID: ${o.value}`),l=[{id:"1234567",name:"Acme Incorporated",active:!0},{id:"1234568",name:"Acme Incorporated"},{id:"1234569",name:"Acme Incorporated",spinner:!0},{id:"1234560",name:"Acme Incorporated"}],p=[{icon:"user",label:"My profile"},{icon:"login",label:"Sign out"}],_=u=>(u||"").split(`
`)[0];async function s(u){const r=_(u.detail);u.currentTarget.resetSelection(),o.value=r}return(u,r)=>{const x=P,b=C;return i(),I(b,{title:n.title,id:n.id,showSnippetTabs:!1,additionalClasses:"-bg--grey-20"},{example:m(()=>[e("header",pt,[r[11]||(r[11]=e("div",{class:"chi-header__brandbar"},null,-1)),e("nav",mt,[r[9]||(r[9]=e("div",{class:"chi-header__brand"},[e("chi-link",{href:"#","alternative-text":"Lumen"},[e("chi-brand",{logo:"lumen"})]),e("span",{class:"chi-header__title"},"[Portal Name]")],-1)),r[10]||(r[10]=e("div",{class:"chi-header__start -d--flex -d-lg--none -d-xl--flex"},[e("chi-button",{id:"toggle-nav-imp",variant:"flat",size:"lg",type:"icon",color:"dark"},[e("chi-icon",{icon:"menu",size:"sm--3"})])],-1)),e("div",ut,[e("chi-dropdown",{class:"enterprise-id-switcher",position:"bottom-end",size:"sm","select-mode":"","retain-selection":M(c),button:M(c),"on:chiDropdownItemSelected":s},[r[5]||(r[5]=e("div",{slot:"menu-header"},[e("div",{class:"chi-grid"},[e("div",{class:"chi-col -w--4"},"Enterprise ID"),e("div",{class:"chi-col -w--7"},"Enterprise Name")])],-1)),(i(),a(f,null,w(l,d=>e("a",{class:$(["chi-dropdown__menu-item",{"-active":d.id===M(o)}]),key:d.id,slot:"menu",href:"#",onClick:r[0]||(r[0]=z(()=>{},["prevent"]))},[e("div",bt,[e("div",_t,k(d.id),1),e("div",gt,k(d.name),1),d.spinner?(i(),a("div",kt,[...r[4]||(r[4]=[e("chi-spinner",null,null,-1)])])):E("",!0)])],2)),64)),r[6]||(r[6]=e("div",{class:"chi-divider",slot:"menu-footer"},null,-1)),r[7]||(r[7]=e("chi-link",{slot:"menu-footer",href:"#"},"Manage My Enterprises",-1))],40,vt),r[8]||(r[8]=e("div",{class:"chi-divider -vertical"},null,-1)),e("chi-dropdown",ft,[(i(),a(f,null,w(p,d=>e("a",{class:"chi-dropdown__menu-item",key:d.label,slot:"menu",href:"#",onClick:r[1]||(r[1]=z(()=>{},["prevent"]))},[e("chi-icon",{icon:d.icon},null,8,wt),V(" "+k(d.label),1)])),64))])])])]),e("header",yt,[r[19]||(r[19]=e("div",{class:"chi-impersonation-bar"},[e("div",{class:"chi-impersonation-bar__content"},[e("span",{class:"chi-impersonation-bar__label"},"Signed in as:"),e("strong",{class:"chi-impersonation-bar__username"},"User"),e("div",{class:"chi-impersonation-bar__divider chi-divider -inverse -vertical -h--75"}),e("button",{class:"chi-button -flat -light -xs -icon -no-hover -b--0",id:"button-logout","aria-label":"Log out","data-tooltip":"Log out","data-position":"bottom"},[e("div",{class:"chi-button__content"},[e("chi-icon",{icon:"logout",size:"xs"})])])])],-1)),e("nav",xt,[r[17]||(r[17]=e("div",{class:"chi-header__brand"},[e("chi-link",{href:"#","alternative-text":"Lumen"},[e("chi-brand",{logo:"lumen"})]),e("span",{class:"chi-header__title"},"[Portal Name]")],-1)),r[18]||(r[18]=e("div",{class:"chi-header__start"},[e("chi-button",{class:"-d--flex -d-lg--none -d-xl--flex",id:"toggle-nav-imp",variant:"flat",size:"lg",type:"icon",color:"dark"},[e("chi-icon",{icon:"menu",size:"sm--3"})])],-1)),e("div",It,[e("chi-dropdown",{class:"enterprise-id-switcher",position:"bottom-end",size:"sm","select-mode":"","retain-selection":M(c),button:M(c),"on:chiDropdownItemSelected":s},[r[13]||(r[13]=e("div",{slot:"menu-header"},[e("div",{class:"chi-grid"},[e("div",{class:"chi-col -w--4"},"Enterprise ID"),e("div",{class:"chi-col -w--7"},"Enterprise Name")])],-1)),(i(),a(f,null,w(l,d=>e("a",{class:$(["chi-dropdown__menu-item",{"-active":d.id===M(o)}]),key:d.id,slot:"menu",href:"#",onClick:r[2]||(r[2]=z(()=>{},["prevent"]))},[e("div",Ct,[e("div",Pt,k(d.id),1),e("div",At,k(d.name),1),d.spinner?(i(),a("div",Dt,[...r[12]||(r[12]=[e("chi-spinner",null,null,-1)])])):E("",!0)])],2)),64)),r[14]||(r[14]=e("div",{class:"chi-divider",slot:"menu-footer"},null,-1)),r[15]||(r[15]=e("chi-link",{slot:"menu-footer",href:"#"},"Manage My Enterprises",-1))],40,St),r[16]||(r[16]=e("div",{class:"chi-divider -vertical"},null,-1)),e("chi-dropdown",Et,[(i(),a(f,null,w(p,d=>e("a",{class:"chi-dropdown__menu-item",key:d.label,slot:"menu",href:"#",onClick:r[3]||(r[3]=z(()=>{},["prevent"]))},[e("chi-icon",{icon:d.icon},null,8,$t),V(" "+k(d.label),1)])),64))])])])])]),"code-htmlblueprint":m(()=>[y(x,{class:"html",lang:"html",code:Mt})]),_:1},8,["title","id"])}}}),Nt={class:"chi-epanel__wrapper"},qt=["step","title","state"],Tt={slot:"active"},zt={class:"chi-epanel__subtitle"},Lt={class:"chi-epanel__text"},Rt={slot:"done"},Ft={slot:"footer"},Vt={key:0,variant:"flat"},Ot=["onClick"],Qt=["onClick"],Ht={key:0,slot:"change"},Ut=["onClick"],jt=`<chi-expansion-panel
  v-for="(panel, index) in panels"
  :key="index"
  :step="index + 1"
  :title="panel.title"
  :state="panel.state"
>
  <div slot="active">
    <div class="chi-epanel__subtitle">
      {{ panel.subtitle }}
    </div>

    <p class="chi-epanel__text">
      {{ panel.content }}
    </p>
  </div>

  <div slot="done">
    {{ panel.doneContent }}
  </div>

  <div slot="footer">
    <chi-button @click="setDone(index)" color="primary">
      {{ index + 1 === panels.length ? 'Finish' : 'Continue' }}
    </chi-button>
    <chi-button @click="setPrevious(index)" v-if="index">
      Previous
    </chi-button>
    <chi-button variant="flat" v-if="index">
      Cancel
    </chi-button>
  </div>

  <div slot="change" v-if="index > 0">
    <chi-button @click="setActive(index)" color="primary" variant="flat">
      Edit
    </chi-button>
  </div>
</chi-expansion-panel>

<!-- Data and Methods -->
data: {
  panels: [
    {
      state: "active",
      content: "Content for the panel in done state",
      title: "Panel title",
      subtitle: "Optional subtitle",
      doneContent: "Use this area to present a read-only summary of what the user entered or selected in step 1. (e.g.) a package selection",
      completed: false,
    },
    {
      state: "pending",
      content: "Content for the panel in active state",
      title: "Panel title",
      subtitle: "Optional subtitle",
      doneContent: "Use this area to present a read-only summary of what the user entered or selected in step 1. (e.g.) a package selection",
      completed: false,
    },
    {
      state: "pending",
      content: "Content for the panel in pending state",
      title: "Panel title",
      subtitle: "Optional subtitle",
      doneContent: "Use this area to present a read-only summary of what the user entered or selected in step 1. (e.g.) a package selection",
      completed: false,
    },
    {
      state: "pending",
      content: "Content for the panel in disabled state",
      title: "Panel title",
      subtitle: "Optional subtitle",
      doneContent: "Use this area to present a read-only summary of what the user entered or selected in step 1. (e.g.) a package selection",
      completed: false,
    }
  ]
},

methods: {
  updatePanels (index: number, newState: string) {
    panels.value.forEach((panel, i) => {
      if (panel.state === 'active') panel.state = panel.completed ? 'done' : 'pending';
      if (i === index) panel.state = newState;
    });
  }

  setDone(index: number) {
    panels.value[index].state = 'done';
    panels.value[index].completed = true;
    const nextPending = panels.value.findIndex((panel) => panel.state === 'pending');
    if (nextPending !== -1) updatePanels(nextPending, 'active');
  },

  setActive(index: number) => updatePanels(index, 'active'),

  setPrevious(index: number) => updatePanels(index - 1, 'active')
}
`,Wt=S({__name:"_expansion_panel",props:{id:{},title:{}},setup(v){const n=v;function o(u){return{state:u,content:"Content in expansion panel (e.g. a form to select a product package)",title:"Panel title",subtitle:"Optional subtitle",doneContent:"Use this area to present a read-only summary of what the user entered or selected in step 1. (e.g.) a package selection",completed:!1}}const c=q([o("active"),...Array.from({length:3},()=>o("pending"))]),l=(u,r)=>{c.value.forEach((x,b)=>{x.state==="active"&&(x.state=x.completed?"done":"pending"),b===u&&(x.state=r)})},p=u=>{c.value[u].state="done",c.value[u].completed=!0;const r=c.value.findIndex(x=>x.state==="pending");r!==-1&&l(r,"active")},_=u=>l(u,"active"),s=u=>l(u-1,"active");return(u,r)=>{const x=P,b=C;return i(),I(b,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[e("div",Nt,[(i(!0),a(f,null,w(c.value,(d,A)=>(i(),a("chi-expansion-panel",{key:A,step:A+1,title:d.title,state:d.state},[e("div",Tt,[e("div",zt,k(d.subtitle),1),e("p",Lt,k(d.content),1)]),e("div",Rt,k(d.doneContent),1),e("div",Ft,[A?(i(),a("chi-button",Vt,"Cancel")):E("",!0),A?(i(),a("chi-button",{key:1,onClick:B=>s(A)},"Previous",8,Ot)):E("",!0),e("chi-button",{onClick:B=>p(A),color:"primary"},k(A+1===c.value.length?"Finish":"Continue"),9,Qt)]),d.state==="done"?(i(),a("div",Ht,[e("chi-button",{onClick:B=>_(A),color:"primary",variant:"flat"},"Edit",8,Ut)])):E("",!0)],8,qt))),128))])]),"code-htmlblueprint":m(()=>[y(x,{class:"html",lang:"html",code:jt})]),_:1},8,["title","id"])}}}),Gt={ref:"mobile-nav-trigger",variant:"flat",type:"icon"},Kt={id:"main-menu"},Jt={class:"chi-mobile-nav__header"},Zt=["retain-selection","button"],Xt={class:"chi-grid"},Yt={class:"chi-col -w--4"},el={class:"chi-col -w--7"},il={key:0,class:"chi-col -w--1"},tl={class:"chi-mobile-nav__list"},ll=["href"],nl=["icon"],cl={key:1,icon:"chevron-right"},ol={class:"chi-mobile-nav__list"},al=["href"],sl=["icon"],rl={key:0,icon:"external-link",size:"sm"},dl={id:"services-menu"},hl={class:"chi-mobile-nav__list"},pl=["href"],ml={key:0,icon:"chevron-right"},ul={id:"apis-menu"},vl={class:"chi-mobile-nav__list"},bl=["href"],_l={key:0,icon:"chevron-right"},gl={id:"quotes-menu"},kl={class:"chi-mobile-nav__list"},fl={id:"service-portals-menu"},wl={class:"chi-mobile-nav__list"},yl={id:"view-apis-menu"},xl={class:"chi-mobile-nav__list"},Il=`<!--Trigger button-->
<chi-button id="mobile-nav-trigger" variant="flat" type="icon">
  <chi-icon icon="menu"></chi-icon>
</chi-button>

<!--Mobile navigation drawer-->
<div class="chi-mobile-nav -global" id="mobile-nav">
  <chi-drawer id="mobile-nav-drawer">
    <div id="main-menu">
      <div class="chi-mobile-nav__header">
        <chi-dropdown
          id="enterprise-dropdown"
          class="enterprise-id-switcher"
          position="bottom"
          button="Enterprise ID: 1234567"
          size="sm"
          select-mode
        >
          <div class="chi-grid" slot="menu-header">
            <div class="chi-col -w--4">Enterprise ID</div>
            <div class="chi-col -w--7">Enterprise Name</div>
          </div>
          <a class="chi-dropdown__menu-item -active" slot="menu">
            <div class="chi-grid">
              <div class="chi-col -w--4">1234567</div>
              <div class="chi-col -w--7">Acme Incorporated</div>
            </div>
          </a>
          <a class="chi-dropdown__menu-item" slot="menu">
            <div class="chi-grid">
              <div class="chi-col -w--4">1234568</div>
              <div class="chi-col -w--7">Acme Incorporated</div>
            </div>
          </a>
          <a class="chi-dropdown__menu-item" slot="menu">
            <div class="chi-grid">
              <div class="chi-col -w--4">1234569</div>
              <div class="chi-col -w--7">Acme Incorporated</div>
              <div class="chi-col -w--1"><chi-spinner></chi-spinner></div>
            </div>
          </a>
          <a class="chi-dropdown__menu-item" slot="menu">
            <div class="chi-grid">
              <div class="chi-col -w--4">1234560</div>
              <div class="chi-col -w--7">Acme Incorporated</div>
            </div>
          </a>
          <div class="chi-divider" slot="menu-footer"></div>
          <chi-link slot="menu-footer">Manage My Enterprises</chi-link>
        </chi-dropdown>
      </div>
      <div class="chi-divider -my--0"></div>
      <ul class="chi-mobile-nav__list">
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="dashboard"></chi-icon>
            <span>Dashboard</span>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="bell"></chi-icon>
            <span>Alerts & Notifications</span>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link class="-active" href="#services-menu">
            <chi-icon icon="list-alt"></chi-icon>
            <span>Services</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link href="#apis-menu">
            <chi-icon icon="api"></chi-icon>
            <span>APIs</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="chart-bar"></chi-icon>
            <span>Monitoring & Reports</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="mail-open-dollar"></chi-icon>
            <span>Billing</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="users"></chi-icon>
            <span>Admin</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="life-ring"></chi-icon>
            <span>Support</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
      </ul>
      <div class="chi-divider -my--0"></div>
      <ul class="chi-mobile-nav__list">
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="circle-question"></chi-icon>
            <span>[Portal Name] Help</span>
            <chi-icon icon="external-link" size="sm"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="compose"></chi-icon>
            <span>Contact Lumen</span>
            <chi-icon icon="external-link" size="sm"></chi-icon>
          </chi-link>
        </li>
      </ul>
      <div class="chi-divider -my--0"></div>
      <ul class="chi-mobile-nav__list">
        <li class="chi-mobile-nav__item">
          <span class="chi-mobile-nav__email">jamie.johnson@company.com</span>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="user"></chi-icon>
            <span>My Profile</span>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <chi-icon icon="logout"></chi-icon>
            <span>Sign out</span>
          </chi-link>
        </li>
      </ul>
    </div>
    <div id="services-menu">
      <ul class="chi-mobile-nav__list">
        <li class="chi-mobile-nav__item">
          <chi-link href="https://lib.lumen.com/"> Manage Services </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link> Add Services </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link> Order Status </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <span>Service Tools</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>
            <span>Service Requests</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link class="-active" href="#quotes-menu">
            <span>Quotes</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link href="#service-portals-menu">
            <span>Service Portals</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
      </ul>
    </div>
    <div id="apis-menu">
      <ul class="chi-mobile-nav__list">
        <li class="chi-mobile-nav__item">
          <chi-link href="#view-apis-menu">
            <span>View APIs</span>
            <chi-icon icon="chevron-right"></chi-icon>
          </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link> Edit APIs </chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link> API Settings </chi-link>
        </li>
      </ul>
    </div>
    <div id="quotes-menu">
      <ul class="chi-mobile-nav__list">
        <li class="chi-mobile-nav__item">
          <chi-link class="-active">View Quotes</chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>Create Quotes</chi-link>
        </li>
      </ul>
    </div>
    <div id="service-portals-menu">
      <ul class="chi-mobile-nav__list">
        <li class="chi-mobile-nav__item">
          <chi-link>Service Portal 1</chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>Service Portal 2</chi-link>
        </li>
      </ul>
    </div>
    <div id="view-apis-menu">
      <ul class="chi-mobile-nav__list">
        <li class="chi-mobile-nav__item">
          <chi-link>API 1</chi-link>
        </li>
        <li class="chi-mobile-nav__item">
          <chi-link>API 2</chi-link>
        </li>
      </ul>
    </div>
  </chi-drawer>
</div>

<script>
  const enterpriseDropdown = document.getElementById('enterprise-dropdown');
  const mobileNav = document.getElementById('mobile-nav');
  const mobileNavTrigger = document.getElementById('mobile-nav-trigger');
  const mobileNavDrawer = document.getElementById('mobile-nav-drawer');

  chi.globalMobileNav(mobileNav, mobileNavTrigger, mobileNavDrawer, enterpriseDropdown);

  enterpriseDropdown.addEventListener('chiDropdownItemSelected', (e) => {
    // Handle enterprise selection change with custom logic
  });
<\/script>
`,Sl=S({__name:"_mobile_nav",props:{id:{},title:{}},setup(v){const n=v,o=N("mobile-nav"),c=N("mobile-nav-trigger"),l=N("mobile-nav-drawer"),p=N("enterprise-dropdown"),_=T=>{T.target.closest('a[href^="#"]')&&T.preventDefault()},s=[{icon:"dashboard",label:"Dashboard"},{icon:"bell",label:"Alerts & Notifications"},{icon:"list-alt",label:"Services",href:"#services-menu",hasChevron:!0,active:!0},{icon:"api",label:"APIs",href:"#apis-menu",hasChevron:!0},{icon:"chart-bar",label:"Monitoring & Reports",hasChevron:!0},{icon:"mail-open-dollar",label:"Billing",hasChevron:!0},{icon:"users",label:"Admin",hasChevron:!0},{icon:"life-ring",label:"Support",hasChevron:!0}],u=[{icon:"circle-question",label:"[Portal Name] Help",showRightIcon:!0},{icon:"compose",label:"Contact Lumen",showRightIcon:!0}],r=[{label:"Manage Services",href:"https://lib.lumen.com/"},{label:"Add Services"},{label:"Order Status"},{label:"Service Tools",hasChevron:!0},{label:"Service Requests",hasChevron:!0},{label:"Quotes",href:"#quotes-menu",hasChevron:!0,active:!0},{label:"Service Portals",href:"#service-portals-menu",hasChevron:!0}],x=[{label:"View APIs",href:"#view-apis-menu",hasChevron:!0},{label:"Edit APIs"},{label:"API Settings"}],b=[{label:"View Quotes",active:!0},{label:"Create Quotes"}],d=[{label:"Service Portal 1"},{label:"Service Portal 2"}],A=[{label:"API 1"},{label:"API 2"}],B=q("1234567"),L=W(()=>`Enterprise ID: ${B.value}`),F=[{id:"1234567",name:"Acme Incorporated",active:!0},{id:"1234568",name:"Acme Incorporated"},{id:"1234569",name:"Acme Incorporated",spinner:!0},{id:"1234560",name:"Acme Incorporated"}],Q=T=>(T||"").split(`
`)[0];async function R(T){const D=Q(T.detail);T.currentTarget.resetSelection(),B.value=D}return te([o,c,l,p],()=>{o&&c&&l&&p&&chi.globalMobileNav(o.value,c.value,l.value,p.value)}),(T,D)=>{const G=P,K=C;return i(),I(K,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[e("chi-button",Gt,[...D[1]||(D[1]=[e("chi-icon",{icon:"menu"},null,-1),e("span",null,"Click to open Mobile Nav",-1)])],512),e("div",{class:"chi-mobile-nav -global",ref_key:"mobileNav",ref:o},[e("chi-drawer",{ref:"mobile-nav-drawer",onClickCapture:_},[e("div",Kt,[e("div",Jt,[e("chi-dropdown",{class:"enterprise-id-switcher",ref:"enterprise-dropdown",position:"bottom",size:"sm","select-mode":"","retain-selection":M(L),button:M(L),"on:chiDropdownItemSelected":R},[D[3]||(D[3]=e("div",{slot:"menu-header"},[e("div",{class:"chi-grid"},[e("div",{class:"chi-col -w--4"},"Enterprise ID"),e("div",{class:"chi-col -w--7"},"Enterprise Name")])],-1)),(i(),a(f,null,w(F,g=>e("a",{class:$(["chi-dropdown__menu-item",{"-active":g.id===M(B)}]),key:g.id,slot:"menu",href:"#",onClick:D[0]||(D[0]=z(()=>{},["prevent"]))},[e("div",Xt,[e("div",Yt,k(g.id),1),e("div",el,k(g.name),1),g.spinner?(i(),a("div",il,[...D[2]||(D[2]=[e("chi-spinner",null,null,-1)])])):E("",!0)])],2)),64)),D[4]||(D[4]=e("div",{class:"chi-divider",slot:"menu-footer"},null,-1)),D[5]||(D[5]=e("chi-link",{slot:"menu-footer"},"Manage My Enterprises",-1))],40,Zt)]),D[6]||(D[6]=e("div",{class:"chi-divider -my--0"},null,-1)),e("ul",tl,[(i(),a(f,null,w(s,g=>e("li",{class:"chi-mobile-nav__item",key:g.label},[e("chi-link",{href:g.href,class:$({"-active":g.active})},[g.icon?(i(),a("chi-icon",{key:0,icon:g.icon},null,8,nl)):E("",!0),e("span",null,k(g.label),1),g.hasChevron?(i(),a("chi-icon",cl)):E("",!0)],10,ll)])),64))]),D[7]||(D[7]=e("div",{class:"chi-divider -my--0"},null,-1)),e("ul",ol,[(i(),a(f,null,w(u,g=>e("li",{class:"chi-mobile-nav__item",key:g.label},[e("chi-link",{href:g.href},[e("chi-icon",{icon:g.icon},null,8,sl),e("span",null,k(g.label),1),g.showRightIcon?(i(),a("chi-icon",rl)):E("",!0)],8,al)])),64))]),D[8]||(D[8]=e("div",{class:"chi-divider -my--0"},null,-1)),D[9]||(D[9]=e("ul",{class:"chi-mobile-nav__list"},[e("li",{class:"chi-mobile-nav__item"},[e("span",{class:"chi-mobile-nav__email"},"jamie.johnson@company.com")]),e("li",{class:"chi-mobile-nav__item"},[e("chi-link",null,[e("chi-icon",{icon:"user"}),e("span",null,"My Profile")])]),e("li",{class:"chi-mobile-nav__item"},[e("chi-link",null,[e("chi-icon",{icon:"logout"}),e("span",null,"Sign out")])])],-1))]),e("div",dl,[e("ul",hl,[(i(),a(f,null,w(r,g=>e("li",{class:"chi-mobile-nav__item",key:g.label},[e("chi-link",{href:g.href,class:$({"-active":g.active})},[e("span",null,k(g.label),1),g.hasChevron?(i(),a("chi-icon",ml)):E("",!0)],10,pl)])),64))])]),e("div",ul,[e("ul",vl,[(i(),a(f,null,w(x,g=>e("li",{class:"chi-mobile-nav__item",key:g.label},[e("chi-link",{href:g.href,class:$({"-active":g.active})},[e("span",null,k(g.label),1),g.hasChevron?(i(),a("chi-icon",_l)):E("",!0)],10,bl)])),64))])]),e("div",gl,[e("ul",kl,[(i(),a(f,null,w(b,g=>e("li",{class:"chi-mobile-nav__item",key:g.label},[e("chi-link",{class:$({"-active":g.active})},k(g.label),3)])),64))])]),e("div",fl,[e("ul",wl,[(i(),a(f,null,w(d,g=>e("li",{class:"chi-mobile-nav__item",key:g.label},[e("chi-link",{class:$({"-active":g.active})},k(g.label),3)])),64))])]),e("div",yl,[e("ul",xl,[(i(),a(f,null,w(A,g=>e("li",{class:"chi-mobile-nav__item",key:g.label},[e("chi-link",{class:$({"-active":g.active})},k(g.label),3)])),64))])])],544)],512)]),"code-htmlblueprint":m(()=>[y(G,{class:"html",lang:"html",code:Il})]),_:1},8,["title","id"])}}}),Cl={class:"-d--flex",style:{gap:"1rem"}},Pl=`<!-- Base Modal -->
<chi-modal id="base-modal" button="Base" title="Modal Title">
  Modal content
  <chi-button slot="footer" color="primary">Save</chi-button>
  <chi-button id="cancel-button" slot="footer" variant="flat">Cancel</chi-button>
</chi-modal>

<!-- Form Modal -->
<chi-modal button="Form Modal" title="Modal Title">
  <div class="chi-form__item -mb--2">
    <chi-label for="example__base-1" required>Label</chi-label>
    <chi-text-input id="example__base-1"></chi-text-input>
  </div>
  <div class="chi-form__item">
    <chi-label for="example__base-2">Label</chi-label>
    <chi-text-input id="example__base-2"></chi-text-input>
  </div>
  <chi-button slot="footer" color="primary">Save</chi-button>
  <chi-button slot="footer" variant="outline">Reset</chi-button>
  <chi-button slot="footer" variant="flat">Cancel</chi-button>
</chi-modal>

<!-- Scrollable Modal -->
<chi-modal button="Scrollable" title="Modal Title" content-height="400">
  Lorem ipsum dolor sit amet...
  <chi-button slot="footer" color="primary">Save</chi-button>
  <chi-button slot="footer" variant="flat">Cancel</chi-button>
</chi-modal>

<!-- Full Page Modal -->
<chi-modal button="Full Page" title="Modal Title" full-page>
  Content Area
  <chi-button slot="footer" color="primary">Save</chi-button>
  <chi-button slot="footer" variant="flat">Cancel</chi-button>
</chi-modal>

<!-- Close button example -->
<script>
  const modal = document.getElementById('base-modal');
  const cancelButton = document.getElementById('cancel-button');

  cancelButton.addEventListener('click', () =>  modal.hide());
<\/script>
`,Al=S({__name:"_modal",props:{id:{},title:{}},setup(v){const n=v,o=N("baseModalRef"),c=N("formModalRef"),l=N("fullPageModalRef"),p=N("scrollableModalRef");return(_,s)=>{const u=P,r=C;return i(),I(r,{title:n.title,id:n.id,additionalStyle:"position: static;",showSnippetTabs:!1},{example:m(()=>[e("div",Cl,[e("chi-modal",{button:"Base",title:"Modal Title",ref_key:"baseModalRef",ref:o},[s[4]||(s[4]=V("Modal content",-1)),s[5]||(s[5]=e("chi-button",{slot:"footer",color:"primary"},"Save",-1)),e("chi-button",{slot:"footer",variant:"flat",onClick:s[0]||(s[0]=x=>o.value.hide())},"Cancel")],512),e("chi-modal",{button:"Form Modal",title:"Modal Title",ref_key:"formModalRef",ref:c},[s[6]||(s[6]=e("div",{class:"chi-form__item -mb--2"},[e("chi-label",{for:"example__base-1",required:""},"Label"),e("chi-text-input",{id:"example__base-1"})],-1)),s[7]||(s[7]=e("div",{class:"chi-form__item"},[e("chi-label",{for:"example__base-2"},"Label"),e("chi-text-input",{id:"example__base-2"})],-1)),s[8]||(s[8]=e("chi-button",{slot:"footer",color:"primary"},"Save",-1)),s[9]||(s[9]=e("chi-button",{slot:"footer",variant:"outline"},"Reset",-1)),e("chi-button",{slot:"footer",variant:"flat",onClick:s[1]||(s[1]=x=>c.value.hide())},"Cancel")],512),e("chi-modal",{button:"Scrollable",title:"Modal Title",contentHeight:"400",ref_key:"scrollableModalRef",ref:p},[s[10]||(s[10]=e("div",{class:"-mb--3"},"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam, quod. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.",-1)),s[11]||(s[11]=e("div",{class:"-mb--3"},"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam, quod. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.",-1)),s[12]||(s[12]=e("div",null,"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam, quod. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.",-1)),s[13]||(s[13]=e("chi-button",{slot:"footer",color:"primary"},"Save",-1)),e("chi-button",{slot:"footer",variant:"flat",onClick:s[2]||(s[2]=x=>p.value.hide())},"Cancel")],512),e("chi-modal",{button:"Full Page",title:"Modal Title","full-page":"",ref_key:"fullPageModalRef",ref:l},[s[14]||(s[14]=V("Content Area",-1)),s[15]||(s[15]=e("chi-button",{slot:"footer",color:"primary"},"Save",-1)),e("chi-button",{slot:"footer",variant:"flat",onClick:s[3]||(s[3]=x=>l.value.hide())},"Cancel")],512)])]),"code-htmlblueprint":m(()=>[y(u,{class:"html",lang:"html",code:Pl})]),_:1},8,["title","id"])}}}),Dl=`<!-- Base Search Input -->
<chi-search-input placeholder="Search"></chi-search-input>

<!-- Search Input with autocomplete -->
<chi-search-input id="example__autocomplete" placeholder="Search with autocomplete" mode="autocomplete" visible-items="4"></chi-search-input>

<!-- Disabled Search Input -->
<chi-search-input placeholder="Disabled Search Input" disabled></chi-search-input>

<script>
  const input = document.getElementById("example__autocomplete");

  input.menuItems = [
    { title: "Item 1", href: "#" },
    { title: "Item 2", href: "#" },
    { title: "Item 3", href: "#" },
    { title: "Item 4", href: "#" },
    { title: "Item 5", href: "#" }
  ];
<\/script>
`,El=S({__name:"_search_input",props:{id:{},title:{}},setup(v){const n=v,o=[{title:"Item 1",href:"#"},{title:"Item 2",href:"#"},{title:"Item 3",href:"#"},{title:"Item 4",href:"#"},{title:"Item 5",href:"#"}];return(c,l)=>{const p=P,_=C;return i(),I(_,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[e("div",{class:"-d--flex -g--2"},[l[0]||(l[0]=e("chi-search-input",{placeholder:"Search"},null,-1)),e("chi-search-input",{placeholder:"Search with autocomplete",mode:"autocomplete","visible-items":"4",menuItems:o}),l[1]||(l[1]=e("chi-search-input",{placeholder:"Disabled Search Input",disabled:""},null,-1))])]),"code-htmlblueprint":m(()=>[y(p,{class:"html",lang:"html",code:Dl})]),_:1},8,["title","id"])}}}),$l=`
<!-- Number Input with Predefined Value, Step, Min and Max -->
<chi-number-input value="20" step="5" min="0" max="50"></chi-number-input>

<!-- Disabled Number Input -->
<chi-number-input disabled></chi-number-input>
`,Ml=S({__name:"_number_input",props:{id:{},title:{}},setup(v){const n=v;return(o,c)=>{const l=P,p=C;return i(),I(p,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[...c[0]||(c[0]=[e("div",{class:"-d--flex -flex--wrap -g--2"},[e("chi-number-input",{value:"20",step:"5",min:"0",max:"50"}),e("chi-number-input",{disabled:""})],-1)])]),"code-htmlblueprint":m(()=>[y(l,{class:"html",lang:"html",code:$l})]),_:1},8,["title","id"])}}}),Bl=`
<!-- Phone Input with placeholder -->
<chi-number-input placeholder="e.g. (123) 456-7890"></chi-number-input>

<!-- Phone Input with default value and country -->
<chi-number-input value="+34-987654321" default-country="ES"></chi-number-input>

<!-- Phone Input with excluded countries -->
<chi-number-input excluded-countries="GB,DE,FR"></chi-number-input>

<!-- Disabled Phone Input -->
<chi-number-input disabled></chi-number-input>
`,Nl=S({__name:"_phone_input",props:{id:{},title:{}},setup(v){const n=v;return(o,c)=>{const l=P,p=C;return i(),I(p,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[...c[0]||(c[0]=[e("div",{class:"-d--flex -flex--wrap -g--2"},[e("chi-phone-input",{placeholder:"e.g. (123) 456-7890"}),e("chi-phone-input",{value:"+34-987654321","default-country":"ES"}),e("chi-phone-input",{"excluded-countries":"GB,DE,FR"}),e("chi-phone-input",{disabled:""})],-1)])]),"code-htmlblueprint":m(()=>[y(l,{class:"html",lang:"html",code:Bl})]),_:1},8,["title","id"])}}}),ql={class:"-d--flex -flex--wrap -g--2"},Tl=["options"],zl=`<!-- Base Picker -->
<chi-picker id="base-picker__example" label="Select options"></chi-picker>

<!-- Picker with pills -->
<chi-picker id="pill-picker__example" label="Pills variant" pill></chi-picker>

<!-- Picker with description -->
<chi-picker id="picker-with-description__example" label="With description" show-input></chi-picker>

<script>
  const basePicker = document.getElementById('base-picker__example');
  const pillPicker = document.getElementById('pill-picker__example');
  const pickerWithDescription = document.getElementById('picker-with-description__example');

  const options = [
    { label: 'One option' },
    { label: 'Option selected by default', checked: true },
    { label: 'Option Disabled', disabled: true },
  ];

  basePicker.options = options;
  pillPicker.options = options;

  pickerWithDescription.options = options.map((option) => ({
    ...option,
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer vehicula placerat iaculis. Ut rutrum pulvinar velit vitae molestie. Phasellus accumsan pharetra ex. Nulla iaculis velit sed velit vehicula dictum. Donec ut ultrices tortor. Vivamus sit amet lorem augue.'
  }));
<\/script>
`,Ll=S({__name:"_picker",props:{id:{},title:{}},setup(v){const n=v,o=[{label:"One option"},{label:"Option selected by default",checked:!0},{label:"Option Disabled",disabled:!0}],c=o.map(l=>({...l,description:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer vehicula placerat iaculis. Ut rutrum pulvinar velit vitae molestie. Phasellus accumsan pharetra ex. Nulla iaculis velit sed velit vehicula dictum. Donec ut ultrices tortor. Vivamus sit amet lorem augue."}));return(l,p)=>{const _=P,s=C;return i(),I(s,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[e("div",ql,[e("chi-picker",{label:"Select options",options:o}),e("chi-picker",{label:"Pills variant",options:o,pill:""}),e("chi-picker",{label:"With description",options:M(c),"show-input":""},null,8,Tl)])]),"code-htmlblueprint":m(()=>[y(_,{class:"html",lang:"html",code:zl})]),_:1},8,["title","id"])}}}),Rl=`<!-- Radio Button -->
<chi-form-wrapper
  type="radio"
  label="Select an option"
  id="form-wrapper-radio"
></chi-form-wrapper>

<script>
document.getElementById("form-wrapper-radio").options = [
  { label: 'Checked Option', name: 'radios', checked: true },
  { label: 'Disabled Option', name: 'radios', disabled: true },
  { label: 'Other option', name: 'radios' },
];
<\/script>
`,Fl=S({__name:"_radio_button",props:{id:{},title:{}},setup(v){const n=v,o=[{label:"Checked Option",name:"radios",checked:!0},{label:"Disabled Option",name:"radios",disabled:!0},{label:"Other option",name:"radios"}];return(c,l)=>{const p=P,_=C;return i(),I(_,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[e("chi-form-wrapper",{type:"radio",label:"Select an option",options:o})]),"code-htmlblueprint":m(()=>[y(p,{class:"html",lang:"html",code:Rl})]),_:1},8,["title","id"])}}}),Vl={class:"-d--flex"},Ol={class:"chi-sidenav -global",id:"global-nav",ref:"global-nav"},Ql={class:"chi-sidenav__content"},Hl={class:"chi-sidenav__list"},Ul={class:"chi-sidenav__item-wrapper"},jl={key:0},Wl=["icon"],Gl=["size"],Kl=["id"],Jl=["slot"],Zl={class:"chi-sidenav__item-guide"},Xl=["id"],Yl=["slot"],en={class:"chi-sidenav__item-guide"},tn={class:"chi-sidenav__item-wrapper"},ln=["icon"],nn=`<!-- Sidenav trigger -->
<chi-button id="toggle-nav" variant="flat" type="icon">
  <chi-icon icon="menu"></chi-icon>
</chi-button>

<!-- Sidenav -->
<aside id="global-nav" class="chi-sidenav -global">
  <div class="chi-sidenav__content">
    <nav>
      <ul class="chi-sidenav__list">
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-link>
              <chi-icon icon="dashboard"></chi-icon>
              <span>Dashboard</span>
            </chi-link>
          </div>
        </li>
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-link>
              <chi-icon icon="bell"></chi-icon>
              <chi-badge type="notification" size="xs" text-weight="bold">21</chi-badge>
              <span>Alerts & Notifications</span>
            </chi-link>
          </div>
        </li>
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-accordion id="services" type="link">
              <div slot="services-template">
                <div class="chi-sidenav__item-guide">
                  <chi-link>Manage Services</chi-link>
                  <chi-link>Add Services</chi-link>
                  <chi-link>Order Status</chi-link>
                  <chi-accordion id="services-tools" type="link">
                    <div slot="services-tools-template">
                      <div class="chi-sidenav__item-guide">
                        <chi-link>ELS & LI Managements</chi-link>
                        <chi-link>Network Storage</chi-link>
                        <chi-link class="-active">Edge Bare Metal</chi-link>
                        <chi-link>SASE Management</chi-link>
                        <chi-link>Voice Complete Features</chi-link>
                        <chi-link>+1 Switched Toll Free</chi-link>
                        <chi-link>Cross Connect</chi-link>
                        <chi-link>Enhanced Routing</chi-link>
                        <chi-link>Manage Voicemail</chi-link>
                        <chi-link>Security Certificate Management</chi-link>
                        <chi-link>Toll Free Management</chi-link>
                      </div>
                    </div>
                  </chi-accordion>
                  <chi-accordion id="services-requests" type="link">
                    <div slot="services-requests-template">
                      <div class="chi-sidenav__item-guide">
                        <chi-link>Requests Page 1</chi-link>
                        <chi-link>Requests Page 2</chi-link>
                        <chi-link>Requests Page 3</chi-link>
                      </div>
                    </div>
                  </chi-accordion>
                  <chi-accordion id="services-quotes" type="link">
                    <div slot="services-quotes-template">
                      <div class="chi-sidenav__item-guide">
                        <chi-link>Quotes Page 1</chi-link>
                        <chi-link>Quotes Page 2</chi-link>
                        <chi-link>Quotes Page 3</chi-link>
                      </div>
                    </div>
                  </chi-accordion>
                  <chi-accordion id="services-portals" type="link">
                    <div slot="services-portals-template">
                      <div class="chi-sidenav__item-guide">
                        <chi-link>Portals Page 1</chi-link>
                        <chi-link>Portals Page 2</chi-link>
                        <chi-link>Portals Page 3</chi-link>
                      </div>
                    </div>
                  </chi-accordion>
                </div>
              </div>
            </chi-accordion>
          </div>
        </li>
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-accordion id="apis" type="link">
              <div slot="apis-template">
                <div class="chi-sidenav__item-guide">
                  <chi-link>APIs page 1</chi-link>
                  <chi-link>APIs page 2</chi-link>
                  <chi-link>APIs page 3</chi-link>
                </div>
              </div>
            </chi-accordion>
          </div>
        </li>
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-accordion id="monitoring-and-reports" type="link">
              <div slot="monitoring-and-reports-template">
                <div class="chi-sidenav__item-guide">
                  <chi-link>Monitoring & Reports page 1</chi-link>
                  <chi-link>Monitoring & Reports page 2</chi-link>
                  <chi-link>Monitoring & Reports page 3</chi-link>
                </div>
              </div>
            </chi-accordion>
          </div>
        </li>
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-accordion id="billing" type="link">
              <div slot="billing-template">
                <div class="chi-sidenav__item-guide">
                  <chi-link>Billing page 1</chi-link>
                  <chi-link>Billing page 2</chi-link>
                  <chi-link>Billing page 3</chi-link>
                </div>
              </div>
            </chi-accordion>
          </div>
        </li>
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-accordion id="admin" type="link">
              <div slot="admin-template">
                <div class="chi-sidenav__item-guide">
                  <chi-link>Admin page 1</chi-link>
                  <chi-link>Admin page 2</chi-link>
                  <chi-link>Admin page 3</chi-link>
                </div>
              </div>
            </chi-accordion>
          </div>
        </li>
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-accordion id="support" type="link">
              <div slot="support-template">
                <div class="chi-sidenav__item-guide">
                  <chi-link>Support page 1</chi-link>
                  <chi-link>Support page 2</chi-link>
                  <chi-link>Support page 3</chi-link>
                </div>
              </div>
            </chi-accordion>
          </div>
        </li>
        <div class="chi-divider"></div>
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-link>
              <chi-icon icon="circle-question"></chi-icon>
              <span>[Portal Name] Help</span>
              <chi-icon icon="external-link" size="sm"></chi-icon>
            </chi-link>
          </div>
        </li>
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-link>
              <chi-icon icon="compose"></chi-icon>
              <span>Contact Lumen</span>
              <chi-icon icon="external-link" size="sm"></chi-icon>
            </chi-link>
          </div>
        </li>
      </ul>
    </nav>
  </div>
</aside>

<script>
  //#region Accordions
  const servicesAccordion = document.getElementById('services');
  const servicesToolsAccordion = document.getElementById('services-tools');
  const servicesRequestsAccordion = document.getElementById('services-requests');
  const servicesQuotesAccordion = document.getElementById('services-quotes');
  const servicesPortalsAccordion = document.getElementById('services-portals');

  servicesAccordion.accordions = [
    {
      title: 'Services',
      icon: 'list-alt',
      template: 'services-template',
    },
  ];
  servicesToolsAccordion.accordions = [
    {
      title: 'Service Tools',
      template: 'services-tools-template',
    },
  ];
  servicesRequestsAccordion.accordions = [
    {
      title: 'Service Requests',
      template: 'services-requests-template',
    },
  ];
  servicesQuotesAccordion.accordions = [
    {
      title: 'Quotes',
      template: 'services-quotes-template',
    },
  ];
  servicesPortalsAccordion.accordions = [
    {
      title: 'Service Portals',
      template: 'services-portals-template',
    },
  ];

  const apisAccordion = document.getElementById('apis');

  apisAccordion.accordions = [
    {
      title: 'APIs',
      icon: 'api',
      template: 'apis-template',
    },
  ];

  const monitoringAndReportsAccordion = document.getElementById('monitoring-and-reports');

  monitoringAndReportsAccordion.accordions = [
    {
      title: 'Monitoring & Reports',
      icon: 'chart-bar',
      template: 'monitoring-and-reports-template',
    },
  ];

  const billingAccordion = document.getElementById('billing');

  billingAccordion.accordions = [
    {
      title: 'Billing',
      icon: 'cost',
      template: 'billing-template',
    },
  ];

  const adminAccordion = document.getElementById('admin');

  adminAccordion.accordions = [
    {
      title: 'Admin',
      icon: 'users',
      template: 'admin-template',
    },
  ];

  const supportAccordion = document.getElementById('support');

  supportAccordion.accordions = [
    {
      title: 'Support',
      icon: 'life-ring',
      template: 'support-template',
    },
  ];
  //#endregion

  //#region Sidenav
  const sidenavElement = document.getElementById('global-nav');
  const globalNav = chi.globalNav(sidenavElement);
  const toggleNavButton = document.getElementById('toggle-nav');

  toggleNavButton.addEventListener('click', () => (globalNav.expanded = !globalNav.expanded));
  //#endregion
 <\/script>
`,cn=S({__name:"_sidenav",props:{id:{},title:{}},setup(v){const n=v,o=N("global-nav"),c=q(),l=[{title:"Dashboard",icon:"dashboard"},{title:"Alerts & Notifications",icon:"bell",badge:{label:"21",size:"xs"}},{title:"Services",icon:"list-alt",accordionId:"services",templateId:"services-template",children:[{title:"Manage Services"},{title:"Add Services"},{title:"Order Status"},{title:"Service Tools",accordionId:"services-tools",templateId:"services-tools-template",children:[{title:"ELS & LI Managements"},{title:"Network Storage"},{title:"Edge Bare Metal",active:!0},{title:"SASE Management"},{title:"Voice Complete Features"},{title:"+1 Switched Toll Free"},{title:"Cross Connect"},{title:"Enhanced Routing"},{title:"Manage Voicemail"},{title:"Security Certificate Management"},{title:"Toll Free Management"}]},{title:"Service Requests",accordionId:"services-requests",templateId:"services-requests-template",children:[{title:"Requests Page 1"},{title:"Requests Page 2"},{title:"Requests Page 3"}]},{title:"Quotes",accordionId:"services-quotes",templateId:"services-quotes-template",children:[{title:"Quotes Page 1"},{title:"Quotes Page 2"},{title:"Quotes Page 3"}]},{title:"Service Portals",accordionId:"services-portals",templateId:"services-portals-template",children:[{title:"Portals Page 1"},{title:"Portals Page 2"},{title:"Portals Page 3"}]}]},{title:"APIs",icon:"api",accordionId:"apis",templateId:"apis-template",children:[{title:"APIs page 1"},{title:"APIs page 2"},{title:"APIs page 3"}]},{title:"Monitoring & Reports",icon:"chart-bar",accordionId:"monitoring-and-reports",templateId:"monitoring-and-reports-template",children:[{title:"Monitoring & Reports page 1"},{title:"Monitoring & Reports page 2"},{title:"Monitoring & Reports page 3"}]},{title:"Billing",icon:"cost",accordionId:"billing",templateId:"billing-template",children:[{title:"Billing page 1"},{title:"Billing page 2"},{title:"Billing page 3"}]},{title:"Admin",icon:"users",accordionId:"admin",templateId:"admin-template",children:[{title:"Admin page 1"},{title:"Admin page 2"},{title:"Admin page 3"}]},{title:"Support",icon:"life-ring",accordionId:"support",templateId:"support-template",children:[{title:"Support page 1"},{title:"Support page 2"},{title:"Support page 3"}]}],p=[{title:"[Portal Name] Help",icon:"circle-question"},{title:"Contact Lumen",icon:"compose"}];function _(s){s.forEach(u=>{if(u.accordionId&&u.templateId){const r=document.getElementById(u.accordionId);r&&(r.accordions=[{title:u.title,icon:u.icon,template:u.templateId}])}u.children&&_(u.children)})}return oe(()=>{o.value&&(c.value=chi.globalNav(o.value))}),ee(()=>{ie(()=>{_(l)})}),(s,u)=>{const r=P,x=C;return i(),I(x,{title:n.title,id:n.id,showSnippetTabs:!1,padding:"-p--0"},{example:m(()=>[e("div",Vl,[e("aside",Ol,[e("div",Ql,[e("nav",null,[e("ul",Hl,[(i(),a(f,null,w(l,(b,d)=>e("li",{class:"chi-sidenav__item",key:d},[e("div",Ul,[!b.children&&!b.accordionId?(i(),a("chi-link",jl,[e("chi-icon",{icon:b.icon},null,8,Wl),b.badge?(i(),a("chi-badge",{key:0,size:b.badge.size,type:"notification","text-weight":"bold"},k(b.badge.label),9,Gl)):E("",!0),e("span",null,k(b.title),1)])):(i(),a("chi-accordion",{key:1,ref_for:!0,ref:b.accordionId,id:b.accordionId,type:"link"},[e("div",{slot:b.templateId},[e("div",Zl,[(i(!0),a(f,null,w(b.children,(A,B)=>(i(),a(f,{key:B},[A.accordionId?(i(),a("chi-accordion",{key:0,id:A.accordionId,type:"link"},[e("div",{slot:A.templateId},[e("div",en,[(i(!0),a(f,null,w(A.children,(L,F)=>(i(),a("chi-link",{key:F,class:$({"-active":L.active})},k(L.title),3))),128))])],8,Yl)],8,Xl)):(i(),a("chi-link",{key:1,class:$({"-active":A.active})},k(A.title),3))],64))),128))])],8,Jl)],8,Kl))])])),64)),u[2]||(u[2]=e("div",{class:"chi-divider"},null,-1)),(i(),a(f,null,w(p,(b,d)=>e("li",{class:"chi-sidenav__item",key:"footer-"+d},[e("div",tn,[e("chi-link",null,[e("chi-icon",{icon:b.icon},null,8,ln),e("span",null,k(b.title),1),u[1]||(u[1]=e("chi-icon",{icon:"external-link",size:"sm"},null,-1))])])])),64))])])])],512),e("chi-button",{class:"-d--block -mt--3 -ml--3",id:"toggle-nav",variant:"flat",type:"icon",onClick:u[0]||(u[0]=b=>c.value.expanded=!c.value.expanded)},[...u[3]||(u[3]=[e("chi-icon",{icon:"menu"},null,-1)])])])]),"code-htmlblueprint":m(()=>[y(r,{class:"html",lang:"html",code:nn})]),_:1},8,["title","id"])}}}),on=`<chi-tags id="predefined-tags" placeholder="Add tag"></chi-tags>

<script>
  document.getElementById('predefined-tags').tags = [
    { name: 'First tag' },
    { name: 'Second tag' },
  ];
<\/script>
`,an=S({__name:"_tags",props:{id:{},title:{}},setup(v){const n=v,o=[{name:"First tag"},{name:"Second tag"}];return(c,l)=>{const p=P,_=C;return i(),I(_,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[e("div",{class:"p--3"},[e("chi-tags",{placeholder:"Add tag",tags:o})])]),"code-htmlblueprint":m(()=>[y(p,{class:"html",lang:"html",code:on})]),_:1},8,["title","id"])}}}),sn=`<!-- Base Text Input -->
<chi-text-input value="Base Text Input"></chi-text-input>

<!-- Disabled Text Input -->
<chi-text-input placeholder="Disabled Text Input" disabled></chi-text-input>
`,rn=S({__name:"_text_input",props:{id:{},title:{}},setup(v){const n=v;return(o,c)=>{const l=P,p=C;return i(),I(p,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[...c[0]||(c[0]=[e("div",{class:"-d--flex -g--2"},[e("chi-text-input",{value:"Base Text Input"}),e("chi-text-input",{placeholder:"Disabled Text Input",disabled:""})],-1)])]),"code-htmlblueprint":m(()=>[y(l,{class:"html",lang:"html",code:sn})]),_:1},8,["title","id"])}}}),dn=`<!-- Base Textarea -->
<chi-textarea placeholder="Base Textarea"></chi-textarea>

<!-- Disabled Textarea -->
<chi-textarea placeholder="Disabled Textarea" disabled></chi-textarea>
`,hn=S({__name:"_textarea",props:{id:{},title:{}},setup(v){const n=v;return(o,c)=>{const l=P,p=C;return i(),I(p,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[...c[0]||(c[0]=[e("div",{class:"-d--flex -g--2"},[e("chi-textarea",{placeholder:"Base Textarea"}),e("chi-textarea",{placeholder:"Disabled Textarea",disabled:""})],-1)])]),"code-htmlblueprint":m(()=>[y(l,{class:"html",lang:"html",code:dn})]),_:1},8,["title","id"])}}}),pn=`<!-- Base Time Picker -->
<chi-time-picker></chi-time-picker>

<!-- Disabled Time Picker -->
<chi-time-picker disabled></chi-time-picker>
`,mn=S({__name:"_time_picker",props:{id:{},title:{}},setup(v){const n=v;return(o,c)=>{const l=P,p=C;return i(),I(p,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[...c[0]||(c[0]=[e("div",{class:"-d--flex -flex--wrap -g--2"},[e("chi-time-picker"),e("chi-time-picker",{disabled:""})],-1)])]),"code-htmlblueprint":m(()=>[y(l,{class:"html",lang:"html",code:pn})]),_:1},8,["title","id"])}}}),un={class:"toolbar-example"},vn={title:"Search & filter"},bn={slot:"start"},_n={class:"-d--flex -justify-content--end -align-items--center -w--100"},gn={slot:"end"},kn={class:"chi-grid"},fn={class:"chi-col -w--12 -mt--2"},wn=["value"],yn=["value"],xn={class:"chi-col -mt--2 -d--flex -g--1"},In={class:"-d--flex -justify-content--end -mt--2"},Sn=["items"],Cn=`<chi-toolbar title="Search & filter">
  <div slot="start">
    <div class="-d--flex -justify-content--end -align-items--center -w--100">
      <div class="-w--25">
        <ChiViews :views='views' @chiViewsDelete='chiViewsDelete' @chiViewsChange='chiViewsChange' @chiViewsChangeDefault='chiViewsChangeDefault' />
      </div>
    </div>
  </div>

  <div slot="end">
    <div class="chi-grid">
      <div class="chi-col">
        <chi-search-input placeholder="Search"></chi-search-input>
      </div>
      <div class="chi-col -d--flex -align-items--center">
        <chi-checkbox checked="" label="Search hidden columns"></chi-checkbox>
      </div>
      <div class="chi-col -w--12 -mt--2">
        <ChiFilters ref='filtersRef' :filtersData='filtersData'>
          <template #dateRangeFrom='{ filter }'>
            <chi-date-picker :value='filter.value'></chi-date-picker>
          </template>
          <template #dateRangeTo='{ filter }'>
            <chi-date-picker :value='filter.value'></chi-date-picker>
          </template>
        </ChiFilters>
      </div>
      <div class="chi-col -mt--2 -d--flex -g--1">
        <ChiSaveViews @chiViewSave='(data) => chiViewSave(data)' />
        <chi-button>Reset</chi-button>
      </div>
    </div>
  </div>
</chi-toolbar>

<div class="-d--flex -justify-content--end -mt--2">
  <chi-customize-panel :items='columns || []' :config='panelConfig'>
    <div class="chi-link" slot="trigger">
      <div class="chi-link__content">
        <chi-icon icon="table-column-settings"></chi-icon>
        <span>Customize Columns</span>
      </div>
    </div>
  </chi-customize-panel>
</div>

<script>
// Views
const views = ref([
  {
    id: 'all-results',
    label: 'All Results',
    default: true,
    actions: {
      default: {
        tooltipMessage: 'Current default view',
        disabled: true,
      },
      delete: {
        tooltipMessage: 'Default view cannot be deleted',
        disabled: true,
      },
    },
  },
  {
    id: 'view-1',
    label: 'On Demand Ports & Services',
    selected: true,
    actions: {
      default: {
        disabled: false,
        tooltipMessage: 'Set as default View',
      },
      delete: {
        tooltipMessage: 'Default view cannot be deleted',
        disabled: false,
      },
    },
  },
  {
    id: 'view-2',
    label: 'Customer Saved View',
    actions: {
      default: {
        tooltipMessage: 'Set as default View',
      },
      delete: {
        tooltipMessage: 'Delete Save view',
      },
    },
    viewData: {
      columns: [],
      searchString: 'abcde',
      filters: [],
    },
  },
]);

const chiViewsChange = (e: any) => {
  // Write your code here
};
const chiViewsDelete = (e: any) => {
  // Write your code here
};
const chiViewsChangeDefault = (e: any) => {
  // Write your code here
};
const chiViewSave = (data: any) => {
  // Write your code here
};

// Filters
const filtersRef = ref(null);
const filtersData = ref([
  {
    name: 'product',
    label: 'Product',
    type: 'select',
    options: [
      { label: 'DDos Essentials', checked: false },
      { label: 'IP Port', checked: false },
      { label: 'CPE', checked: false },
      { label: 'Zoom Phone', checked: false },
      { label: 'Voice Complete', checked: false },
    ],
    id: 'product',
    placeholder: 'Any Product',
  },
  {
    name: 'status',
    label: 'Status',
    type: 'select',
    options: [
      { label: 'Active', checked: false },
      { label: 'Connection Unsuccessful', checked: false },
      { label: 'Disconnect Unsuccessful', checked: false },
      { label: 'Disconnected', checked: false },
      { label: 'Pending Install', checked: false },
    ],
    id: 'status',
    placeholder: 'Any Status',
  },
  {
    name: 'alerts',
    label: 'Alerts',
    type: 'select',
    options: [
      { label: 'Active', checked: false },
      { label: 'Connection Unsuccessful', checked: false },
      { label: 'Disconnect Unsuccessful', checked: false },
      { label: 'Disconnected', checked: false },
      { label: 'Pending Install', checked: false },
    ],
    id: 'alerts',
    placeholder: 'With or Without Alerts',
  },
  {
    name: 'serviceId',
    label: 'Service ID',
    type: 'input',
    id: 'serviceId',
    advanced: true,
  },
  {
    name: 'serviceNickname',
    label: 'Service Nickname',
    type: 'input',
    id: 'serviceNickname',
    advanced: true,
  },
  {
    name: 'bandwidth',
    label: 'Bandwidth',
    type: 'select',
    options: [
      { label: '50 Mbps', checked: false },
      { label: '100 Mbps', checked: false },
      { label: '200 Mbps', checked: false },
      { label: '500 Mbps', checked: false },
      { label: '2 Gbps', checked: false },
      { label: '3 Gbps', checked: false },
      { label: '10 Gbps', checked: false },
    ],
    id: 'bandwidth',
    placeholder: 'Any Bandwidth',
    advanced: true,
  },
  {
    name: 'monitoredBy',
    label: 'Monitored By',
    type: 'select-multiple',
    options: [
      { label: 'Network Visibility', checked: false, id: 'monitored-by-option-1' },
      { label: 'Defender', checked: false, id: 'monitored-by-option-2' },
      { label: 'Security Operations Center', checked: false, id: 'monitored-by-option-3' },
      { label: 'No Monitoring', checked: false, id: 'monitored-by-option-4' },
    ],
    id: 'monitoredBy',
    advanced: true,
  },
  {
    name: 'location',
    label: 'Location',
    type: 'input',
    id: 'location',
    placeholder: 'Street, City, State or Zip',
    advanced: true,
  },
  {
    name: 'dateRangeFrom',
    label: 'Submit Date From',
    type: 'template',
    template: 'dateRangeFrom',
    id: 'dateRangeFrom',
    advanced: true,
  },
  {
    name: 'dateRangeTo',
    label: 'Submit Date To',
    type: 'template',
    template: 'dateRangeTo',
    id: 'dateRangeTo',
    advanced: true,
  },
  {
    name: 'additionalInformation',
    label: 'Additional Information',
    type: 'input',
    id: 'additionalInformation',
    advanced: true,
    hidden: true,
  },
]);

// Customize panel
const columns = ref([
  {
    name: 'columnA',
    label: 'Column A with a very long text',
  },
  {
    name: 'columnB',
    label: 'Column B',
  },
  {
    name: 'columnC',
    label: 'Column C',
    locked: true,
    selected: true,
  },
  {
    name: 'columnD',
    label: 'Column D',
    locked: true,
    selected: true,
  },
  {
    name: 'columnE',
    label: 'Column E with a very long text',
    selected: true,
    wildcard: true,
  },
  {
    name: 'columnF',
    label: 'Column F',
    selected: true,
    wildcard: true,
  },
  {
    name: 'columnG',
    label: 'Column G',
    selected: true,
    wildcard: true,
  },
  {
    name: 'columnH',
    label: 'Column H',
  },
  {
    name: 'columnI',
    label: 'Column I',
  },
  {
    name: 'columnJ',
    label: 'Column J',
  },
]);
const panelConfig = {
  itemsName: 'Columns',
};
<\/script>
`,Pn=S({__name:"_toolbar",props:{id:{},title:{}},setup(v){const n=v,o=q([{id:"all-results",label:"All Results",default:!0,actions:{default:{tooltipMessage:"Current default view",disabled:!0},delete:{tooltipMessage:"Default view cannot be deleted",disabled:!0}}},{id:"view-1",label:"On Demand Ports & Services",selected:!0,actions:{default:{disabled:!1,tooltipMessage:"Set as default View"},delete:{tooltipMessage:"Default view cannot be deleted",disabled:!1}}},{id:"view-2",label:"Customer Saved View",actions:{default:{tooltipMessage:"Set as default View"},delete:{tooltipMessage:"Delete Save view"}},viewData:{columns:[],searchString:"abcde",filters:[]}}]),c=q(null),l=q([{name:"product",label:"Product",type:"select",options:[{label:"DDos Essentials",checked:!1},{label:"IP Port",checked:!1},{label:"CPE",checked:!1},{label:"Zoom Phone",checked:!1},{label:"Voice Complete",checked:!1}],id:"product",placeholder:"Any Product"},{name:"status",label:"Status",type:"select",options:[{label:"Active",checked:!1},{label:"Connection Unsuccessful",checked:!1},{label:"Disconnect Unsuccessful",checked:!1},{label:"Disconnected",checked:!1},{label:"Pending Install",checked:!1}],id:"status",placeholder:"Any Status"},{name:"alerts",label:"Alerts",type:"select",options:[{label:"Active",checked:!1},{label:"Connection Unsuccessful",checked:!1},{label:"Disconnect Unsuccessful",checked:!1},{label:"Disconnected",checked:!1},{label:"Pending Install",checked:!1}],id:"alerts",placeholder:"With or Without Alerts"},{name:"serviceId",label:"Service ID",type:"input",id:"serviceId",advanced:!0},{name:"serviceNickname",label:"Service Nickname",type:"input",id:"serviceNickname",advanced:!0},{name:"bandwidth",label:"Bandwidth",type:"select",options:[{label:"50 Mbps",checked:!1},{label:"100 Mbps",checked:!1},{label:"200 Mbps",checked:!1},{label:"500 Mbps",checked:!1},{label:"2 Gbps",checked:!1},{label:"3 Gbps",checked:!1},{label:"10 Gbps",checked:!1}],id:"bandwidth",placeholder:"Any Bandwidth",advanced:!0},{name:"monitoredBy",label:"Monitored By",type:"select-multiple",options:[{label:"Network Visibility",checked:!1,id:"monitored-by-option-1"},{label:"Defender",checked:!1,id:"monitored-by-option-2"},{label:"Security Operations Center",checked:!1,id:"monitored-by-option-3"},{label:"No Monitoring",checked:!1,id:"monitored-by-option-4"}],id:"monitoredBy",advanced:!0},{name:"location",label:"Location",type:"input",id:"location",placeholder:"Street, City, State or Zip",advanced:!0},{name:"dateRangeFrom",label:"Submit Date From",type:"template",template:"dateRangeFrom",id:"dateRangeFrom",advanced:!0},{name:"dateRangeTo",label:"Submit Date To",type:"template",template:"dateRangeTo",id:"dateRangeTo",advanced:!0},{name:"additionalInformation",label:"Additional Information",type:"input",id:"additionalInformation",advanced:!0,hidden:!0}]),p=q([{name:"columnA",label:"Column A with a very long text"},{name:"columnB",label:"Column B"},{name:"columnC",label:"Column C",locked:!0,selected:!0},{name:"columnD",label:"Column D",locked:!0,selected:!0},{name:"columnE",label:"Column E with a very long text",selected:!0,wildcard:!0},{name:"columnF",label:"Column F",selected:!0,wildcard:!0},{name:"columnG",label:"Column G",selected:!0,wildcard:!0},{name:"columnH",label:"Column H"},{name:"columnI",label:"Column I"},{name:"columnJ",label:"Column J"}]),_={itemsName:"Columns"},s=b=>{o.value=o.value.map(d=>({...d,selected:d.id===b.id}))},u=b=>o.value=o.value.filter(d=>d.id!==b.id),r=b=>{o.value=o.value.map(d=>({...d,default:d.id===b.id,actions:{default:{...d.actions?.default||{},disabled:d.id===b.id||!d.default&&d.actions?.default?.disabled},delete:{...d.actions?.delete||{},disabled:d.id===b.id||!d.default&&d.actions?.default?.disabled}}}))},x=b=>{const d={label:b.viewName,default:!!b.options[1].checked,selected:!0};o.value.forEach(A=>{d.default&&(A.default=!1),A.selected=!1}),o.value.push(d)};return(b,d)=>{const A=j("ChiViews"),B=j("ChiFilters"),L=j("ChiSaveViews"),F=P,Q=C;return i(),I(Q,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[e("div",un,[e("chi-toolbar",vn,[e("div",bn,[e("div",_n,[y(A,{class:"-w--25",views:o.value,onChiViewsDelete:u,onChiViewsChange:s,onChiViewsChangeDefault:r},null,8,["views"])])]),e("div",gn,[e("div",kn,[d[2]||(d[2]=e("div",{class:"chi-col"},[e("chi-search-input",{placeholder:"Search"})],-1)),d[3]||(d[3]=e("div",{class:"chi-col -d--flex -align-items--center"},[e("chi-checkbox",{checked:"",label:"Search hidden columns"})],-1)),e("div",fn,[y(B,{ref_key:"filtersRef",ref:c,filtersData:l.value},{dateRangeFrom:m(({filter:R})=>[e("chi-date-picker",{value:R.value},null,8,wn)]),dateRangeTo:m(({filter:R})=>[e("chi-date-picker",{value:R.value},null,8,yn)]),_:1},8,["filtersData"])]),e("div",xn,[y(L,{onChiViewSave:d[0]||(d[0]=R=>x(R))}),d[1]||(d[1]=e("chi-button",null,"Reset",-1))])])])]),e("div",In,[e("chi-customize-panel",{items:p.value||[],config:_},[...d[4]||(d[4]=[e("div",{class:"chi-link",slot:"trigger"},[e("div",{class:"chi-link__content"},[e("chi-icon",{icon:"table-column-settings"}),e("span",null,"Customize Columns")])],-1)])],8,Sn)])])]),"code-htmlblueprint":m(()=>[y(F,{class:"html",lang:"html",code:Cn})]),_:1},8,["title","id"])}}}),An=S({__name:"_customize-panel",props:{id:{},title:{}},setup(v){const n=v,o=[{label:"Pay balance due",description:"Outstanding balance across billing accounts",selected:!0},{label:"Active repair tickets",description:"Active repair tickets within the past 90 days",selected:!0},{label:"Open orders",description:"Lorem ipsum dolor amet",selected:!0},{label:"Change requests",description:"Lorem ipsum dolor amet",selected:!0},{label:"Active portal support tickets",description:"Lorem ipsum dolor amet",selected:!1},{label:"Disconnect requests",description:"Lorem ipsum dolor amet",selected:!1},{label:"Outstanding billing accounts",description:"Lorem ipsum dolor amet",selected:!1},{label:"Potential repair tickets",description:"Lorem ipsum dolor amet",selected:!1}],c={itemsName:"Snapshots"},l=`<chi-customize-panel
  name="Columns"
  id="customize-panel"
>
  <chi-link slot="trigger">Customize</chi-link>
</chi-customize-panel>

<!-- Script -->
const panel = document.getElementById('customize-panel');

const panelItems = ${JSON.stringify(o,null,2)};
const panelConfig = ${JSON.stringify(c,null,2)};

panel.items = panelItems;
panel.config = panelConfig;
`;return(p,_)=>{const s=P,u=C;return i(),I(u,{title:n.title,id:n.id,showSnippetTabs:!1},{example:m(()=>[e("chi-customize-panel",{name:"Columns",items:o,config:c},[..._[0]||(_[0]=[e("div",{class:"chi-link",slot:"trigger"},"Customize",-1)])])]),"code-htmlblueprint":m(()=>[y(s,{class:"html",lang:"html",code:l})]),_:1},8,["title","id"])}}}),Dn={style:{"padding-left":"0"}},En=["href"],zn=S({__name:"index",setup(v){const n=[{name:"Badge",component:fe},{name:"Button",component:ye},{name:"Card",component:Ie},{name:"Card Alert",component:Ee},{name:"Checkbox",component:Me},{name:"Customize Panel",component:An},{name:"Dashboard",component:Gi},{name:"Data Table",component:Zi},{name:"Date Picker",component:Yi},{name:"Drag and Drop",component:it},{name:"Drawer",component:nt},{name:"Dropdown Select",component:ot},{name:"Expansion Panel",component:Wt},{name:"File Input",component:rt},{name:"Footer",component:ht},{name:"Header",component:Bt},{name:"Mobile Nav",component:Sl},{name:"Modal",component:Al},{name:"Search Input",component:El},{name:"Number Input",component:Ml},{name:"Phone Input",component:Nl},{name:"Picker",component:Ll},{name:"Radio Button",component:Fl},{name:"Sidenav",component:cn},{name:"Tags",component:an},{name:"Text Input",component:rn},{name:"Textarea",component:hn},{name:"Time Picker",component:mn},{name:"Toolbar",component:Pn}];return(o,c)=>(i(),a("div",null,[e("ul",Dn,[(i(),a(f,null,w(n,l=>e("li",{key:`${l.name}-link`,style:{"list-style":"none","margin-left":"0"}},[e("chi-link",{href:`#${l.name.toLowerCase()}`},k(l.name),9,En)])),64))]),(i(),a(f,null,w(n,l=>y(ae(l.component),{key:`${l.name}-example`,id:l.name.toLowerCase(),title:l.name},null,8,["id","title"])),64))]))}});export{zn as _};
