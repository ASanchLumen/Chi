import{a as i,_ as c}from"./BPxlMu2A.js";import{_ as m}from"./DcT5Qbwl.js";import{c as p,o as l,a as n,b as t,F as d,e as u,i as _,w as r}from"./DBXeQHmC.js";import{_ as f}from"./DlAUqK2U.js";import"./DS5ErHUP.js";import"./CFKeqgEC.js";import"./B1maN0n6.js";import"./DY7FbNsl.js";import"./DnPF01B5.js";import"./CdcsEwU-.js";import"./DDFyDyTO.js";function g(s,e){const o=i;return l(),p(d,null,[e[0]||(e[0]=n("h2",null,"Web Component",-1)),t(o,{tag:"chi-drag"}),e[1]||(e[1]=n("h3",null,"Interfaces and types",-1)),e[2]||(e[2]=n("section",{class:"chi-table -bordered -my--3"},[n("div",{style:{"overflow-x":"auto"}},[n("table",{class:"-types",cellpadding:"0",cellspacing:"0"},[n("thead",null,[n("tr",null,[n("th",null,[n("div",null,"Name")]),n("th",null,[n("div",null,"Interface")])])]),n("tbody",null,[n("tr",null,[n("td",null,[n("div",null,[n("code",null,"DragItem")])]),n("td",{class:"-p--0"},[n("pre",{class:"-mb--0"},`{
  closable?: boolean;

  icon?: string;
  id?: string;
  data?: {
    title?: string;
    description?: string;
    template?: string;
    infoIcon?: InfoIconConfig;
  }
}`)])]),n("tr",null,[n("td",null,[n("div",null,[n("code",null,"InfoIconConfig")])]),n("td",{class:"-p--0"},[n("pre",{class:"-mb--0"},`{
  message: string;
  icon?: string;
  color?: IconColors;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '';
}`)])])])])])],-1))],64)}const b={},x=f(b,[["render",g]]),$=u({__name:"index",setup(s){return(e,o)=>{const a=c;return l(),_(a,{"hide-builder":"",title:"Drag and Drop",description:"Drag and drop is a user interface interaction method that allows users to select an object and move it to a different location. They are commonly used in lists to change the order of the elements."},{examples:r(()=>[t(m)]),properties:r(()=>[t(x)]),_:1})}}});export{$ as default};
