import{_ as K}from"./sH0GR7G2.js";import{_ as $}from"./DnPF01B5.js";import{_ as M}from"./CdcsEwU-.js";import{e as T,Q as E,q as X,R as y,x as Y,a8 as Z,i as C,o as e,w as I,b as _,a as i,c as s,r,S as O,t,F as d,l as p,d as w,g as J,k as V,K as ii}from"./DBXeQHmC.js";import{_ as N}from"./Bo0goINO.js";const ci={class:"-d--flex"},ai={class:"chi-sidenav -global",id:"global-nav",ref:"global-nav"},ei={class:"chi-sidenav__content"},ni={class:"chi-sidenav__list"},ti={class:"chi-sidenav__item-wrapper"},si={key:0},oi=["icon"],di=["size"],ri=["id"],li=["slot"],hi={class:"chi-sidenav__item-guide"},_i=["id"],vi=["slot"],mi={class:"chi-sidenav__item-guide"},ui={class:"chi-sidenav__item-wrapper"},pi=["icon"],gi=`<!-- Sidenav trigger -->
<chi-button id="toggle-nav" variant="flat" type="icon">
  <chi-icon icon="menu"></chi-icon>
</chi-button>

<!-- Sidenav -->
<aside id="global-nav" class="chi-sidenav -global">
  <div class="chi-sidenav__content">
    <nav>
      <ul class="chi-sidenav__list">
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-link>
              <chi-icon icon="dashboard"></chi-icon>
              <span>Dashboard</span>
            </chi-link>
          </div>
        </li>
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-link>
              <chi-icon icon="bell"></chi-icon>
              <chi-badge type="notification" size="xs" text-weight="bold">21</chi-badge>
              <span>Alerts & Notifications</span>
            </chi-link>
          </div>
        </li>
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-accordion id="services" type="link">
              <div slot="services-template">
                <div class="chi-sidenav__item-guide">
                  <chi-link>Manage Services</chi-link>
                  <chi-link>Add Services</chi-link>
                  <chi-link>Order Status</chi-link>
                  <chi-accordion id="services-tools" type="link">
                    <div slot="services-tools-template">
                      <div class="chi-sidenav__item-guide">
                        <chi-link>ELS & LI Managements</chi-link>
                        <chi-link>Network Storage</chi-link>
                        <chi-link class="-active">Edge Bare Metal</chi-link>
                        <chi-link>SASE Management</chi-link>
                        <chi-link>Voice Complete Features</chi-link>
                        <chi-link>+1 Switched Toll Free</chi-link>
                        <chi-link>Cross Connect</chi-link>
                        <chi-link>Enhanced Routing</chi-link>
                        <chi-link>Manage Voicemail</chi-link>
                        <chi-link>Security Certificate Management</chi-link>
                        <chi-link>Toll Free Management</chi-link>
                      </div>
                    </div>
                  </chi-accordion>
                  <chi-accordion id="services-requests" type="link">
                    <div slot="services-requests-template">
                      <div class="chi-sidenav__item-guide">
                        <chi-link>Requests Page 1</chi-link>
                        <chi-link>Requests Page 2</chi-link>
                        <chi-link>Requests Page 3</chi-link>
                      </div>
                    </div>
                  </chi-accordion>
                  <chi-accordion id="services-quotes" type="link">
                    <div slot="services-quotes-template">
                      <div class="chi-sidenav__item-guide">
                        <chi-link>Quotes Page 1</chi-link>
                        <chi-link>Quotes Page 2</chi-link>
                        <chi-link>Quotes Page 3</chi-link>
                      </div>
                    </div>
                  </chi-accordion>
                  <chi-accordion id="services-portals" type="link">
                    <div slot="services-portals-template">
                      <div class="chi-sidenav__item-guide">
                        <chi-link>Portals Page 1</chi-link>
                        <chi-link>Portals Page 2</chi-link>
                        <chi-link>Portals Page 3</chi-link>
                      </div>
                    </div>
                  </chi-accordion>
                </div>
              </div>
            </chi-accordion>
          </div>
        </li>
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-accordion id="apis" type="link">
              <div slot="apis-template">
                <div class="chi-sidenav__item-guide">
                  <chi-link>APIs page 1</chi-link>
                  <chi-link>APIs page 2</chi-link>
                  <chi-link>APIs page 3</chi-link>
                </div>
              </div>
            </chi-accordion>
          </div>
        </li>
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-accordion id="monitoring-and-reports" type="link">
              <div slot="monitoring-and-reports-template">
                <div class="chi-sidenav__item-guide">
                  <chi-link>Monitoring & Reports page 1</chi-link>
                  <chi-link>Monitoring & Reports page 2</chi-link>
                  <chi-link>Monitoring & Reports page 3</chi-link>
                </div>
              </div>
            </chi-accordion>
          </div>
        </li>
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-accordion id="billing" type="link">
              <div slot="billing-template">
                <div class="chi-sidenav__item-guide">
                  <chi-link>Billing page 1</chi-link>
                  <chi-link>Billing page 2</chi-link>
                  <chi-link>Billing page 3</chi-link>
                </div>
              </div>
            </chi-accordion>
          </div>
        </li>
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-accordion id="admin" type="link">
              <div slot="admin-template">
                <div class="chi-sidenav__item-guide">
                  <chi-link>Admin page 1</chi-link>
                  <chi-link>Admin page 2</chi-link>
                  <chi-link>Admin page 3</chi-link>
                </div>
              </div>
            </chi-accordion>
          </div>
        </li>
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-accordion id="support" type="link">
              <div slot="support-template">
                <div class="chi-sidenav__item-guide">
                  <chi-link>Support page 1</chi-link>
                  <chi-link>Support page 2</chi-link>
                  <chi-link>Support page 3</chi-link>
                </div>
              </div>
            </chi-accordion>
          </div>
        </li>
        <div class="chi-divider"></div>
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-link>
              <chi-icon icon="circle-question"></chi-icon>
              <span>[Portal Name] Help</span>
              <chi-icon icon="external-link" size="sm"></chi-icon>
            </chi-link>
          </div>
        </li>
        <li class="chi-sidenav__item">
          <div class="chi-sidenav__item-wrapper">
            <chi-link>
              <chi-icon icon="compose"></chi-icon>
              <span>Contact Lumen</span>
              <chi-icon icon="external-link" size="sm"></chi-icon>
            </chi-link>
          </div>
        </li>
      </ul>
    </nav>
  </div>
</aside>

<script>
  //#region Accordions
  const servicesAccordion = document.getElementById('services');
  const servicesToolsAccordion = document.getElementById('services-tools');
  const servicesRequestsAccordion = document.getElementById('services-requests');
  const servicesQuotesAccordion = document.getElementById('services-quotes');
  const servicesPortalsAccordion = document.getElementById('services-portals');

  servicesAccordion.accordions = [
    {
      title: 'Services',
      icon: 'list-alt',
      template: 'services-template',
    },
  ];
  servicesToolsAccordion.accordions = [
    {
      title: 'Service Tools',
      template: 'services-tools-template',
    },
  ];
  servicesRequestsAccordion.accordions = [
    {
      title: 'Service Requests',
      template: 'services-requests-template',
    },
  ];
  servicesQuotesAccordion.accordions = [
    {
      title: 'Quotes',
      template: 'services-quotes-template',
    },
  ];
  servicesPortalsAccordion.accordions = [
    {
      title: 'Service Portals',
      template: 'services-portals-template',
    },
  ];

  const apisAccordion = document.getElementById('apis');

  apisAccordion.accordions = [
    {
      title: 'APIs',
      icon: 'api',
      template: 'apis-template',
    },
  ];

  const monitoringAndReportsAccordion = document.getElementById('monitoring-and-reports');

  monitoringAndReportsAccordion.accordions = [
    {
      title: 'Monitoring & Reports',
      icon: 'chart-bar',
      template: 'monitoring-and-reports-template',
    },
  ];

  const billingAccordion = document.getElementById('billing');

  billingAccordion.accordions = [
    {
      title: 'Billing',
      icon: 'cost',
      template: 'billing-template',
    },
  ];

  const adminAccordion = document.getElementById('admin');

  adminAccordion.accordions = [
    {
      title: 'Admin',
      icon: 'users',
      template: 'admin-template',
    },
  ];

  const supportAccordion = document.getElementById('support');

  supportAccordion.accordions = [
    {
      title: 'Support',
      icon: 'life-ring',
      template: 'support-template',
    },
  ];

  const sidenavElement = document.getElementById('global-nav');
  const globalNav = chi.globalNav(sidenavElement);
  const toggleNavButton = document.getElementById('toggle-nav');
  toggleNavButton.addEventListener('click', () => (globalNav.expanded = !globalNav.expanded));
 <\/script>
`,bi=T({__name:"_global-sidenav",setup(H){const u=[{active:!0,id:"webcomponent",label:"Web Component"},{disabled:!0,id:"htmlblueprint",label:"HTML Blueprint"}],v=E("global-nav"),o=X(),h=[{title:"Dashboard",icon:"dashboard"},{title:"Alerts & Notifications",icon:"bell",badge:{label:"21",size:"xs"}},{title:"Services",icon:"list-alt",accordionId:"services",templateId:"services-template",children:[{title:"Manage Services"},{title:"Add Services"},{title:"Order Status"},{title:"Service Tools",accordionId:"services-tools",templateId:"services-tools-template",children:[{title:"ELS & LI Managements"},{title:"Network Storage"},{title:"Edge Bare Metal",active:!0},{title:"SASE Management"},{title:"Voice Complete Features"},{title:"+1 Switched Toll Free"},{title:"Cross Connect"},{title:"Enhanced Routing"},{title:"Manage Voicemail"},{title:"Security Certificate Management"},{title:"Toll Free Management"}]},{title:"Service Requests",accordionId:"services-requests",templateId:"services-requests-template",children:[{title:"Requests Page 1"},{title:"Requests Page 2"},{title:"Requests Page 3"}]},{title:"Quotes",accordionId:"services-quotes",templateId:"services-quotes-template",children:[{title:"Quotes Page 1"},{title:"Quotes Page 2"},{title:"Quotes Page 3"}]},{title:"Service Portals",accordionId:"services-portals",templateId:"services-portals-template",children:[{title:"Portals Page 1"},{title:"Portals Page 2"},{title:"Portals Page 3"}]}]},{title:"APIs",icon:"api",accordionId:"apis",templateId:"apis-template",children:[{title:"APIs page 1"},{title:"APIs page 2"},{title:"APIs page 3"}]},{title:"Monitoring & Reports",icon:"chart-bar",accordionId:"monitoring-and-reports",templateId:"monitoring-and-reports-template",children:[{title:"Monitoring & Reports page 1"},{title:"Monitoring & Reports page 2"},{title:"Monitoring & Reports page 3"}]},{title:"Billing",icon:"cost",accordionId:"billing",templateId:"billing-template",children:[{title:"Billing page 1"},{title:"Billing page 2"},{title:"Billing page 3"}]},{title:"Admin",icon:"users",accordionId:"admin",templateId:"admin-template",children:[{title:"Admin page 1"},{title:"Admin page 2"},{title:"Admin page 3"}]},{title:"Support",icon:"life-ring",accordionId:"support",templateId:"support-template",children:[{title:"Support page 1"},{title:"Support page 2"},{title:"Support page 3"}]}],b=[{title:"[Portal Name] Help",icon:"circle-question"},{title:"Contact Lumen",icon:"compose"}];function k(x){x.forEach(m=>{if(m.accordionId&&m.templateId){const f=document.getElementById(m.accordionId);f&&(f.accordions=[{title:m.title,icon:m.icon,template:m.templateId}])}m.children&&k(m.children)})}y(()=>{v.value&&(o.value=chi.globalNav(v.value))}),Y(()=>{Z(()=>{k(h)})});const c={webcomponent:gi,htmlblueprint:""};return(x,m)=>{const f=$,a=M;return e(),C(a,{title:"Global Sidenav",id:"global-sidenav",tabs:u,padding:"-p--0"},{example:I(()=>[i("div",ci,[i("aside",ai,[i("div",ei,[i("nav",null,[i("ul",ni,[(e(),s(d,null,r(h,(n,l)=>i("li",{class:"chi-sidenav__item",key:l},[i("div",ti,[!n.children&&!n.accordionId?(e(),s("chi-link",si,[i("chi-icon",{icon:n.icon},null,8,oi),n.badge?(e(),s("chi-badge",{key:0,size:n.badge.size,type:"notification","text-weight":"bold"},t(n.badge.label),9,di)):O("",!0),i("span",null,t(n.title),1)])):(e(),s("chi-accordion",{key:1,ref_for:!0,ref:n.accordionId,id:n.accordionId,type:"link"},[i("div",{slot:n.templateId},[i("div",hi,[(e(!0),s(d,null,r(n.children,(g,j)=>(e(),s(d,{key:j},[g.accordionId?(e(),s("chi-accordion",{key:0,id:g.accordionId,type:"link"},[i("div",{slot:g.templateId},[i("div",mi,[(e(!0),s(d,null,r(g.children,(W,G)=>(e(),s("chi-link",{key:G,class:p({"-active":W.active})},t(W.title),3))),128))])],8,vi)],8,_i)):(e(),s("chi-link",{key:1,class:p({"-active":g.active})},t(g.title),3))],64))),128))])],8,li)],8,ri))])])),64)),m[2]||(m[2]=i("div",{class:"chi-divider"},null,-1)),(e(),s(d,null,r(b,(n,l)=>i("li",{class:"chi-sidenav__item",key:"footer-"+l},[i("div",ui,[i("chi-link",null,[i("chi-icon",{icon:n.icon},null,8,pi),i("span",null,t(n.title),1),m[1]||(m[1]=i("chi-icon",{icon:"external-link",size:"sm"},null,-1))])])])),64))])])])],512),i("chi-button",{class:"-d--block -mt--3 -ml--3",id:"toggle-nav",variant:"flat",type:"icon",onClick:m[0]||(m[0]=n=>o.value.expanded=!o.value.expanded)},[...m[3]||(m[3]=[i("chi-icon",{icon:"menu"},null,-1)])])])]),"code-webcomponent":I(()=>[_(f,{class:"html",lang:"html",code:c.webcomponent},null,8,["code"])]),_:1})}}}),Ii={class:"-d--flex -overflow--hidden"},xi={class:"chi-sidenav -flex--shrink0 -animated",ref:"sidenav"},wi={class:"chi-sidenav__content"},fi={class:"chi-sidenav__list"},Ti=["href"],Hi={class:"chi-sidenav__drawers"},ki=["id"],$i={class:"chi-drawer__header"},Mi={class:"chi-drawer__title"},Ei={class:"chi-drawer__content"},yi={class:"chi-accordion"},Ci={class:"chi-accordion__trigger"},Si={class:"chi-accordion__title"},Ai={class:"chi-accordion__content"},qi={class:"chi-accordion"},Bi={class:"chi-accordion__trigger"},Pi={class:"chi-accordion__title"},Ri={class:"chi-accordion__content"},Ni={class:"-flex--grow1 -p--3 -pb--4"},L="1",S="2",Li=T({__name:"_base_lumen_centurylink",setup(H){const u=["1","2","3","4"],v=["1","2"],o=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],h={webcomponent:"",htmlblueprint:`<aside class="chi-sidenav" id="example-base">
  <div class="chi-sidenav__content">
    <nav>
      <ul class="chi-sidenav__list">
        <li class="-active">
          <a href="#drawer-0-1">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Active Item</span>
          </a>
        </li>
        <li>
          <a href="#drawer-0-2">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Menu Item</span>
          </a>
        </li>
        <li>
          <a href="#drawer-0-3">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Menu Item</span>
          </a>
        </li>
        <li>
          <a href="#drawer-0-4">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Menu Item</span>
          </a>
        </li>
      </ul>
    </nav>
  </div>
  <div class="chi-sidenav__drawers">
    <div class="chi-drawer -animated -left" id="drawer-0-1">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 1</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item -active">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item -active">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a class="-active" href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
    <div class="chi-drawer -animated -left" id="drawer-0-2">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 2</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
    <div class="chi-drawer -animated -left" id="drawer-0-3">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 3</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
    <div class="chi-drawer -animated -left" id="drawer-0-4">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 4</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
  </div>
</aside>

<script>
  chi.sidenav(document.getElementById('example-base'));
<\/script>`},b=E("sidenav");return y(()=>{b.value&&chi.sidenav(b.value)}),(k,c)=>{const x=$,m=N,f=M;return e(),C(f,{title:"Base",id:"base-lumen-centurylink",tabs:o,padding:"-p--0"},{example:I(()=>[i("div",Ii,[i("aside",xi,[i("div",wi,[i("nav",null,[i("ul",fi,[(e(),s(d,null,r(u,a=>i("li",{class:p(a===L?"-active":"")},[i("a",{href:`#drawer-0-${a}`},[c[0]||(c[0]=i("i",{class:"chi-icon icon-atom","aria-hidden":"true"},null,-1)),i("span",null,t(a===L?"Active Item":"Menu Item"),1)],8,Ti)],2)),64))])])]),i("div",Hi,[(e(),s(d,null,r(u,a=>i("div",{class:"chi-drawer -animated -left",id:`drawer-0-${a}`},[i("div",$i,[i("div",Mi,"Menu item "+t(a),1),c[1]||(c[1]=i("button",{class:"chi-button -icon -close","aria-label":"Close"},[i("div",{class:"chi-button__content"},[i("i",{class:"chi-icon icon-x","aria-hidden":"true"})])],-1))]),i("div",Ei,[i("div",yi,[(e(),s(d,null,r(v,n=>i("div",{class:p(["chi-accordion__item",a===L&&n===S?"-active -expanded":""])},[i("button",Ci,[i("div",Si,"Item "+t(n),1),c[2]||(c[2]=i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"},null,-1))]),i("div",Ai,[i("div",qi,[(e(),s(d,null,r(v,l=>i("div",{class:p(["chi-accordion__item",`${a===L&&n===S&&l===S?"-active -expanded":""}`])},[i("button",Bi,[i("div",Pi,"Item "+t(n)+"."+t(l),1),c[3]||(c[3]=i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"},null,-1))]),i("div",Ri,[(e(),s(d,null,r(v,g=>i("a",{href:"#exampleHashTarget",class:p(`${a===L&&n===S&&l===S&&g===S?"-active":""}`)},[i("span",null,"Item "+t(n)+"."+t(l)+"."+t(g),1)],2)),64))])],2)),64))])])],2)),64)),c[4]||(c[4]=i("a",{href:"#exampleHashTarget"},[i("span",null,[w("External"),i("i",{class:"chi-icon icon-external-link -xs","aria-hidden":"true"})])],-1))])])],8,ki)),64))])],512),i("div",Ni,[(e(),s(d,null,r([1,2,3,4],a=>i("p",null,"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.")),64))])])]),"code-webcomponent":I(()=>[_(x,{class:"html",lang:"html",code:h.webcomponent},null,8,["code"])]),"code-htmlblueprint":I(()=>[_(m),_(x,{lang:"html",code:h.htmlblueprint},null,8,["code"])]),_:1})}}}),zi={class:"-d--flex -overflow--hidden"},Di={class:"chi-sidenav -flex--shrink0 -animated",ref:"sidenav"},Qi={class:"chi-sidenav__content"},Fi={class:"chi-sidenav__list"},Ui=["href"],Vi={class:"chi-sidenav__drawers"},Oi=["id"],Wi={class:"chi-drawer__header"},Ji={class:"chi-drawer__title"},ji={class:"chi-drawer__content"},Gi={class:"chi-accordion"},Ki={class:"chi-accordion__trigger"},Xi={class:"chi-accordion__title"},Yi={class:"chi-accordion__content"},Zi={class:"chi-accordion"},ic={class:"chi-accordion__trigger"},cc={class:"chi-accordion__title"},ac={class:"chi-accordion__content"},ec={class:"-flex--grow1 -p--3 -pb--4"},z="1",A="2",nc=T({__name:"_open-on-hover",setup(H){const u=["1","2","3","4"],v=["1","2"],o=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],h={webcomponent:"",htmlblueprint:`<aside class="chi-sidenav" id="example-open-on-hover">
  <div class="chi-sidenav__content">
    <nav>
      <ul class="chi-sidenav__list">
        <li class="-active">
          <a href="#drawer-2-1" class="">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Active Item</span>
          </a>
        </li>
        <li>
          <a href="#drawer-2-2">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Menu Item</span>
          </a>
        </li>
        <li>
          <a href="#drawer-2-3">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Menu Item</span>
          </a>
        </li>
        <li>
          <a href="#drawer-2-4">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Menu Item</span>
          </a>
        </li>
      </ul>
    </nav>
  </div>
  <div class="chi-sidenav__drawers">
    <div class="chi-drawer -animated -left" id="drawer-2-1">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 1</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item -active">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item -active">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a class="-active" href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
    <div class="chi-drawer -left -animated" id="drawer-2-2">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 2</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
    <div class="chi-drawer -left -animated" id="drawer-2-3">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 3</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
    <div class="chi-drawer -left -animated" id="drawer-2-4">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 4</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
  </div>
</aside>

<script>
  chi.sidenav(document.getElementById('example-open-on-hover'), {
    openOnHover: true,
    autoClose: true
  });
<\/script>`},b=E("sidenav");return y(()=>{b.value&&chi.sidenav(b.value,{openOnHover:!0,autoClose:!0})}),(k,c)=>{const x=$,m=N,f=M;return e(),C(f,{title:"Open on hover",id:"open-on-hover",padding:"-p--0",tabs:o},{example:I(()=>[i("div",zi,[i("aside",Di,[i("div",Qi,[i("nav",null,[i("ul",Fi,[(e(),s(d,null,r(u,a=>i("li",{class:p(a===z?"-active":"")},[i("a",{href:`#drawer-2-${a}`},[c[0]||(c[0]=i("i",{class:"chi-icon icon-atom","aria-hidden":"true"},null,-1)),i("span",null,t(a===z?"Active Item":"Menu Item"),1)],8,Ui)],2)),64))])])]),i("div",Vi,[(e(),s(d,null,r(u,a=>i("div",{class:"chi-drawer -animated -left",id:`drawer-2-${a}`},[i("div",Wi,[i("div",Ji,"Menu item "+t(a),1),c[1]||(c[1]=i("button",{class:"chi-button -icon -close","aria-label":"Close"},[i("div",{class:"chi-button__content"},[i("i",{class:"chi-icon icon-x","aria-hidden":"true"})])],-1))]),i("div",ji,[i("div",Gi,[(e(),s(d,null,r(v,n=>i("div",{class:p(["chi-accordion__item",a===z&&n===A?"-active -expanded":""])},[i("button",Ki,[i("div",Xi,"Item "+t(n),1),c[2]||(c[2]=i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"},null,-1))]),i("div",Yi,[i("div",Zi,[(e(),s(d,null,r(v,l=>i("div",{class:p(["chi-accordion__item",`${a===z&&n===A&&l===A?"-active -expanded":""}`])},[i("button",ic,[i("div",cc,"Item "+t(n)+"."+t(l),1),c[3]||(c[3]=i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"},null,-1))]),i("div",ac,[(e(),s(d,null,r(v,g=>i("a",{href:"#exampleHashTarget",class:p(`${a===z&&n===A&&l===A&&g===A?"-active":""}`)},[i("span",null,"Item "+t(n)+"."+t(l)+"."+t(g),1)],2)),64))])],2)),64))])])],2)),64)),c[4]||(c[4]=i("a",{href:"#exampleHashTarget"},[i("span",null,[w("External"),i("i",{class:"chi-icon icon-external-link -xs","aria-hidden":"true"})])],-1))])])],8,Oi)),64))])],512),i("div",ec,[(e(),s(d,null,r([1,2,3,4],a=>i("p",null,"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.")),64))])])]),"code-webcomponent":I(()=>[_(x,{class:"html",lang:"html",code:h.webcomponent},null,8,["code"])]),"code-htmlblueprint":I(()=>[_(m),_(x,{lang:"html",code:h.htmlblueprint},null,8,["code"])]),_:1})}}}),tc={class:"-d--flex -overflow--hidden"},sc={class:"chi-sidenav -flex--shrink0 -sm -animated",ref:"sidenav"},oc={class:"chi-sidenav__content"},dc={class:"chi-sidenav__list"},rc=["href"],lc={class:"chi-sidenav__drawers"},hc=["id"],_c={class:"chi-drawer__header"},vc={class:"chi-drawer__title"},mc={class:"chi-drawer__content"},uc={class:"chi-accordion"},pc={class:"chi-accordion__trigger"},gc={class:"chi-accordion__title"},bc={class:"chi-accordion__content"},Ic={class:"chi-accordion"},xc={class:"chi-accordion__trigger"},wc={class:"chi-accordion__title"},fc={class:"chi-accordion__content"},Tc={class:"-flex--grow1 -p--3 -pb--4"},D="1",q="2",Hc=T({__name:"_sm_lumen_centurylink",setup(H){const u=["1","2","3","4"],v=["1","2"],o=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],h={webcomponent:"",htmlblueprint:`<aside class="chi-sidenav -sm" id="example-size-sm">
  <div class="chi-sidenav__content">
    <nav>
      <ul class="chi-sidenav__list">
        <li class="-active">
          <a href="#drawer-3-1">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Active Item</span>
          </a>
        </li>
        <li>
          <a href="#drawer-3-2">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Menu Item</span>
          </a>
        </li>
        <li>
          <a href="#drawer-3-3">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Menu Item</span>
          </a>
        </li>
        <li>
          <a href="#drawer-3-4">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Menu Item</span>
          </a>
        </li>
      </ul>
    </nav>
  </div>
  <div class="chi-sidenav__drawers">
    <div class="chi-drawer -animated -left" id="drawer-3-1">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 1</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item -active">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item -active">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a class="-active" href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
    <div class="chi-drawer -animated -left" id="drawer-3-2">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 2</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
    <div class="chi-drawer -animated -left" id="drawer-3-3">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 3</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
    <div class="chi-drawer -animated -left" id="drawer-3-4">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 4</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
  </div>
</aside>

<script>chi.sidenav(document.getElementById('example-size-sm'));<\/script>`},b=E("sidenav");return y(()=>{b.value&&chi.sidenav(b.value)}),(k,c)=>{const x=$,m=N,f=M;return e(),C(f,{title:"-sm",id:"sm-size-lumen-centurylink",tabs:o,padding:"-p--0"},{example:I(()=>[i("div",tc,[i("aside",sc,[i("div",oc,[i("nav",null,[i("ul",dc,[(e(),s(d,null,r(u,a=>i("li",{class:p(a===D?"-active":"")},[i("a",{href:`#drawer-3-${a}`},[c[0]||(c[0]=i("i",{class:"chi-icon icon-atom","aria-hidden":"true"},null,-1)),i("span",null,t(a===D?"Active Item":"Menu Item"),1)],8,rc)],2)),64))])])]),i("div",lc,[(e(),s(d,null,r(u,a=>i("div",{class:"chi-drawer -animated -left",id:`drawer-3-${a}`},[i("div",_c,[i("div",vc,"Menu item "+t(a),1),c[1]||(c[1]=i("button",{class:"chi-button -icon -close","aria-label":"Close"},[i("div",{class:"chi-button__content"},[i("i",{class:"chi-icon icon-x","aria-hidden":"true"})])],-1))]),i("div",mc,[i("div",uc,[(e(),s(d,null,r(v,n=>i("div",{class:p(["chi-accordion__item",a===D&&n===q?"-active -expanded":""])},[i("button",pc,[i("div",gc,"Item "+t(n),1),c[2]||(c[2]=i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"},null,-1))]),i("div",bc,[i("div",Ic,[(e(),s(d,null,r(v,l=>i("div",{class:p(["chi-accordion__item",`${a===D&&n===q&&l===q?"-active -expanded":""}`])},[i("button",xc,[i("div",wc,"Item "+t(n)+"."+t(l),1),c[3]||(c[3]=i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"},null,-1))]),i("div",fc,[(e(),s(d,null,r(v,g=>i("a",{href:"#exampleHashTarget",class:p(`${a===D&&n===q&&l===q&&g===q?"-active":""}`)},[i("span",null,"Item "+t(n)+"."+t(l)+"."+t(g),1)],2)),64))])],2)),64))])])],2)),64)),c[4]||(c[4]=i("a",{href:"#exampleHashTarget"},[i("span",null,[w("External"),i("i",{class:"chi-icon icon-external-link -xs","aria-hidden":"true"})])],-1))])])],8,hc)),64))])],512),i("div",Tc,[(e(),s(d,null,r([1,2,3,4],a=>i("p",null,"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.")),64))])])]),"code-webcomponent":I(()=>[_(x,{class:"html",lang:"html",code:h.webcomponent},null,8,["code"])]),"code-htmlblueprint":I(()=>[_(m),_(x,{lang:"html",code:h.htmlblueprint},null,8,["code"])]),_:1})}}}),kc={class:"-d--flex -overflow--hidden"},$c={class:"chi-sidenav -flex--shrink0 -animated -md",ref:"sidenav"},Mc={class:"chi-sidenav__content"},Ec={class:"chi-sidenav__list"},yc=["href"],Cc={class:"chi-sidenav__drawers"},Sc=["id"],Ac={class:"chi-drawer__header"},qc={class:"chi-drawer__title"},Bc={class:"chi-drawer__content"},Pc={class:"chi-accordion"},Rc={class:"chi-accordion__trigger"},Nc={class:"chi-accordion__title"},Lc={class:"chi-accordion__content"},zc={class:"chi-accordion"},Dc={class:"chi-accordion__trigger"},Qc={class:"chi-accordion__title"},Fc={class:"chi-accordion__content"},Uc={class:"-flex--grow1 -p--3 -pb--4"},Q="1",B="2",Vc=T({__name:"_md_lumen_centurylink",setup(H){const u=["1","2","3","4"],v=["1","2"],o=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],h={webcomponent:"",htmlblueprint:`<aside class="chi-sidenav -md" id="example-size-md">
  <div class="chi-sidenav__content">
    <nav>
      <ul class="chi-sidenav__list">
        <li class="-active">
          <a href="#drawer-3-1">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Active Item</span>
          </a>
        </li>
        <li>
          <a href="#drawer-3-2">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Menu Item</span>
          </a>
        </li>
        <li>
          <a href="#drawer-3-3">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Menu Item</span>
          </a>
        </li>
        <li>
          <a href="#drawer-3-4">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Menu Item</span>
          </a>
        </li>
      </ul>
    </nav>
  </div>
  <div class="chi-sidenav__drawers">
    <div class="chi-drawer -animated -left" id="drawer-3-1">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 1</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item -active">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item -active">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a class="-active" href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
    <div class="chi-drawer -animated -left" id="drawer-3-2">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 2</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
    <div class="chi-drawer -animated -left" id="drawer-3-3">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 3</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
    <div class="chi-drawer -animated -left" id="drawer-3-4">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 4</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
  </div>
</aside>

<script>chi.sidenav(document.getElementById('example-size-md'));<\/script>`},b=E("sidenav");return y(()=>{b.value&&chi.sidenav(b.value)}),(k,c)=>{const x=$,m=N,f=M;return e(),C(f,{title:"-md",id:"md-size-lumen-centurylink",tabs:o,padding:"-p--0"},{example:I(()=>[i("div",kc,[i("aside",$c,[i("div",Mc,[i("nav",null,[i("ul",Ec,[(e(),s(d,null,r(u,a=>i("li",{class:p(a===Q?"-active":"")},[i("a",{href:`#drawer-4-${a}`},[c[0]||(c[0]=i("i",{class:"chi-icon icon-atom","aria-hidden":"true"},null,-1)),i("span",null,t(a===Q?"Active Item":"Menu Item"),1)],8,yc)],2)),64))])])]),i("div",Cc,[(e(),s(d,null,r(u,a=>i("div",{class:"chi-drawer -animated -left",id:`drawer-4-${a}`},[i("div",Ac,[i("div",qc,"Menu item "+t(a),1),c[1]||(c[1]=i("button",{class:"chi-button -icon -close","aria-label":"Close"},[i("div",{class:"chi-button__content"},[i("i",{class:"chi-icon icon-x","aria-hidden":"true"})])],-1))]),i("div",Bc,[i("div",Pc,[(e(),s(d,null,r(v,n=>i("div",{class:p(["chi-accordion__item",a===Q&&n===B?"-active -expanded":""])},[i("button",Rc,[i("div",Nc,"Item "+t(n),1),c[2]||(c[2]=i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"},null,-1))]),i("div",Lc,[i("div",zc,[(e(),s(d,null,r(v,l=>i("div",{class:p(["chi-accordion__item",`${a===Q&&n===B&&l===B?"-active -expanded":""}`])},[i("button",Dc,[i("div",Qc,"Item "+t(n)+"."+t(l),1),c[3]||(c[3]=i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"},null,-1))]),i("div",Fc,[(e(),s(d,null,r(v,g=>i("a",{href:"#exampleHashTarget",class:p(`${a===Q&&n===B&&l===B&&g===B?"-active":""}`)},[i("span",null,"Item "+t(n)+"."+t(l)+"."+t(g),1)],2)),64))])],2)),64))])])],2)),64)),c[4]||(c[4]=i("a",{href:"#exampleHashTarget"},[i("span",null,[w("External"),i("i",{class:"chi-icon icon-external-link -xs","aria-hidden":"true"})])],-1))])])],8,Sc)),64))])],512),i("div",Uc,[(e(),s(d,null,r([1,2,3,4],a=>i("p",null,"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.")),64))])])]),"code-webcomponent":I(()=>[_(x,{class:"html",lang:"html",code:h.webcomponent},null,8,["code"])]),"code-htmlblueprint":I(()=>[_(m),_(x,{lang:"html",code:h.htmlblueprint},null,8,["code"])]),_:1})}}}),Oc={class:"-d--flex -overflow--hidden"},Wc={class:"chi-sidenav -flex--shrink0 -animated -lg",ref:"sidenav"},Jc={class:"chi-sidenav__content"},jc={class:"chi-sidenav__list"},Gc=["href"],Kc={class:"chi-sidenav__drawers"},Xc=["id"],Yc={class:"chi-drawer__header"},Zc={class:"chi-drawer__title"},ia={class:"chi-drawer__content"},ca={class:"chi-accordion"},aa={class:"chi-accordion__trigger"},ea={class:"chi-accordion__title"},na={class:"chi-accordion__content"},ta={class:"chi-accordion"},sa={class:"chi-accordion__trigger"},oa={class:"chi-accordion__title"},da={class:"chi-accordion__content"},ra={class:"-flex--grow1 -p--3 -pb--4"},F="1",P="2",la=T({__name:"_lg_lumen_centurylink",setup(H){const u=["1","2","3","4"],v=["1","2"],o=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],h={webcomponent:"",htmlblueprint:`<aside class="chi-sidenav -lg" id="example-size-lg">
  <div class="chi-sidenav__content">
    <nav>
      <ul class="chi-sidenav__list">
        <li class="-active">
          <a href="#drawer-3-1">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Active Item</span>
          </a>
        </li>
        <li>
          <a href="#drawer-3-2">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Menu Item</span>
          </a>
        </li>
        <li>
          <a href="#drawer-3-3">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Menu Item</span>
          </a>
        </li>
        <li>
          <a href="#drawer-3-4">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Menu Item</span>
          </a>
        </li>
      </ul>
    </nav>
  </div>
  <div class="chi-sidenav__drawers">
    <div class="chi-drawer -animated -left" id="drawer-3-1">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 1</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item -active">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item -active">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a class="-active" href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
    <div class="chi-drawer -animated -left" id="drawer-3-2">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 2</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
    <div class="chi-drawer -animated -left" id="drawer-3-3">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 3</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
    <div class="chi-drawer -animated -left" id="drawer-3-4">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 4</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
  </div>
</aside>

<script>chi.sidenav(document.getElementById('example-size-lg'));<\/script>`},b=E("sidenav");return y(()=>{b.value&&chi.sidenav(b.value)}),(k,c)=>{const x=$,m=N,f=M;return e(),C(f,{title:"-lg",id:"lg-size-lumen-centurylink",tabs:o,padding:"-p--0"},{example:I(()=>[i("div",Oc,[i("aside",Wc,[i("div",Jc,[i("nav",null,[i("ul",jc,[(e(),s(d,null,r(u,a=>i("li",{class:p(a===F?"-active":"")},[i("a",{href:`#drawer-5-${a}`},[c[0]||(c[0]=i("i",{class:"chi-icon icon-atom","aria-hidden":"true"},null,-1)),i("span",null,t(a===F?"Active Item":"Menu Item"),1)],8,Gc)],2)),64))])])]),i("div",Kc,[(e(),s(d,null,r(u,a=>i("div",{class:"chi-drawer -animated -left",id:`drawer-5-${a}`},[i("div",Yc,[i("div",Zc,"Menu item "+t(a),1),c[1]||(c[1]=i("button",{class:"chi-button -icon -close","aria-label":"Close"},[i("div",{class:"chi-button__content"},[i("i",{class:"chi-icon icon-x","aria-hidden":"true"})])],-1))]),i("div",ia,[i("div",ca,[(e(),s(d,null,r(v,n=>i("div",{class:p(["chi-accordion__item",a===F&&n===P?"-active -expanded":""])},[i("button",aa,[i("div",ea,"Item "+t(n),1),c[2]||(c[2]=i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"},null,-1))]),i("div",na,[i("div",ta,[(e(),s(d,null,r(v,l=>i("div",{class:p(["chi-accordion__item",`${a===F&&n===P&&l===P?"-active -expanded":""}`])},[i("button",sa,[i("div",oa,"Item "+t(n)+"."+t(l),1),c[3]||(c[3]=i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"},null,-1))]),i("div",da,[(e(),s(d,null,r(v,g=>i("a",{href:"#exampleHashTarget",class:p(`${a===F&&n===P&&l===P&&g===P?"-active":""}`)},[i("span",null,"Item "+t(n)+"."+t(l)+"."+t(g),1)],2)),64))])],2)),64))])])],2)),64)),c[4]||(c[4]=i("a",{href:"#exampleHashTarget"},[i("span",null,[w("External"),i("i",{class:"chi-icon icon-external-link -xs","aria-hidden":"true"})])],-1))])])],8,Xc)),64))])],512),i("div",ra,[(e(),s(d,null,r([1,2,3,4],a=>i("p",null,"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.")),64))])])]),"code-webcomponent":I(()=>[_(x,{class:"html",lang:"html",code:h.webcomponent},null,8,["code"])]),"code-htmlblueprint":I(()=>[_(m),_(x,{lang:"html",code:h.htmlblueprint},null,8,["code"])]),_:1})}}}),ha=T({__name:"_recommended-layout",setup(H){const u={base:`<div class="-d--flex">
  <aside class="chi-sidenav -flex--shrink0">
    <!-- Sidenav content goes here -->
  </aside>
  <div class="-flex--grow1">
    <!-- Page content goes here -->
  </div>
</div>`,floating:`<div class="-d--flex">
  <aside class="chi-sidenav -float -flex--shrink0">
    <!-- Sidenav content goes here -->
  </aside>
  <div class="-flex--grow1">
    <!-- Page content goes here -->
  </div>
</div>`},v=J();return(o,h)=>{const b=$;return e(),s(d,null,[h[1]||(h[1]=i("h2",null,"Recommended layout",-1)),h[2]||(h[2]=i("p",{class:"-text"},"Use this layout to ensure the sidenav renders correctly in your project.",-1)),["lumen","centurylink"].includes(V(v))?(e(),s(d,{key:0},[h[0]||(h[0]=i("h3",null,"Base",-1)),_(b,{class:"-mb--3 html",lang:"html",code:u.base},null,8,["code"])],64)):O("",!0),h[3]||(h[3]=i("h3",null,"Floating",-1)),_(b,{class:"html",lang:"html",code:u.floating},null,8,["code"])],64)}}}),_a={class:"-d--flex -overflow--hidden"},va={class:"chi-sidenav -flex--shrink0 -animated -float",ref:"sidenav"},ma={class:"chi-sidenav__content"},ua={class:"chi-sidenav__list"},pa=["href"],ga={class:"chi-sidenav__drawers"},ba=["id"],Ia={class:"chi-drawer__header"},xa={class:"chi-drawer__title"},wa={class:"chi-drawer__content"},fa={class:"chi-accordion"},Ta={class:"chi-accordion__trigger"},Ha={class:"chi-accordion__title"},ka={class:"chi-accordion__content"},$a={class:"chi-accordion"},Ma={class:"chi-accordion__trigger"},Ea={class:"chi-accordion__title"},ya={class:"chi-accordion__content"},Ca={class:"-flex--grow1 -p--3 -pb--4"},U="1",R="2",Sa=T({__name:"_floating",setup(H){const u=["1","2","3","4"],v=["1","2"],o=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],h={webcomponent:"",htmlblueprint:`<aside class="chi-sidenav -float" id="example-floating">
  <div class="chi-sidenav__content">
    <nav>
      <ul class="chi-sidenav__list">
        <li class="-active">
          <a href="#drawer-2-1" class="">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Active Item</span>
          </a>
        </li>
        <li>
          <a href="#drawer-2-2">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Menu Item</span>
          </a>
        </li>
        <li>
          <a href="#drawer-2-3">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Menu Item</span>
          </a>
        </li>
        <li>
          <a href="#drawer-2-4">
            <i class="chi-icon icon-atom" aria-hidden="true"></i>
            <span>Menu Item</span>
          </a>
        </li>
      </ul>
    </nav>
  </div>
  <div class="chi-sidenav__drawers">
    <div class="chi-drawer -animated -left" id="drawer-2-1">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 1</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item -active">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item -active">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a class="-active" href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
    <div class="chi-drawer -left -animated" id="drawer-2-2">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 2</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
    <div class="chi-drawer -left -animated" id="drawer-2-3">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 3</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
    <div class="chi-drawer -left -animated" id="drawer-2-4">
      <div class="chi-drawer__header">
        <div class="chi-drawer__title">Menu item 4</div>
        <button class="chi-button -icon -close" aria-label="Close">
          <div class="chi-button__content">
            <i class="chi-icon icon-x" aria-hidden="true"></i>
          </div>
        </button>
      </div>
      <div class="chi-drawer__content">
        <div class="chi-accordion">
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 1</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 1.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 1.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="chi-accordion__item">
            <button class="chi-accordion__trigger">
              <div class="chi-accordion__title">Item 2</div>
              <i class="chi-icon icon-chevron-down" aria-hidden="true"></i>
            </button>
            <div class="chi-accordion__content">
              <div class="chi-accordion">
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.1</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.1.2</span>
                    </a>
                  </div>
                </div>
                <div class="chi-accordion__item">
                  <button class="chi-accordion__trigger">
                    <div class="chi-accordion__title">Item 2.2</div>
                    <i
                      class="chi-icon icon-chevron-down"
                      aria-hidden="true"
                    ></i>
                  </button>
                  <div class="chi-accordion__content">
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.1</span>
                    </a>
                    <a href="#exampleHashTarget">
                      <span>Item 2.2.2</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a href="#exampleHashTarget">
            <span>
              External
              <i class="chi-icon icon-external-link -xs" aria-hidden="true"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
  </div>
</aside>

<script>
  chi.sidenav(document.getElementById('example-floating'), {
    openOnHover: true,
    autoClose: true
  });
<\/script>`},b=E("sidenav");return y(()=>{b.value&&chi.sidenav(b.value,{openOnHover:!0,autoClose:!0})}),(k,c)=>{const x=$,m=N,f=M;return e(),C(f,{title:"Floating",id:"floating",padding:"-p--0",tabs:o},{example:I(()=>[i("div",_a,[i("aside",va,[i("div",ma,[i("nav",null,[i("ul",ua,[(e(),s(d,null,r(u,a=>i("li",{class:p(a===U?"-active":"")},[i("a",{href:`#drawer-floating-${a}`},[c[0]||(c[0]=i("i",{class:"chi-icon icon-atom","aria-hidden":"true"},null,-1)),i("span",null,t(a===U?"Active Item":"Menu Item"),1)],8,pa)],2)),64))])])]),i("div",ga,[(e(),s(d,null,r(u,a=>i("div",{class:"chi-drawer -animated -left",id:`drawer-floating-${a}`},[i("div",Ia,[i("div",xa,"Menu item "+t(a),1),c[1]||(c[1]=i("button",{class:"chi-button -icon -close","aria-label":"Close"},[i("div",{class:"chi-button__content"},[i("i",{class:"chi-icon icon-x","aria-hidden":"true"})])],-1))]),i("div",wa,[i("div",fa,[(e(),s(d,null,r(v,n=>i("div",{class:p(["chi-accordion__item",a===U&&n===R?"-active -expanded":""])},[i("button",Ta,[i("div",Ha,"Item "+t(n),1),c[2]||(c[2]=i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"},null,-1))]),i("div",ka,[i("div",$a,[(e(),s(d,null,r(v,l=>i("div",{class:p(["chi-accordion__item",`${a===U&&n===R&&l===R?"-active -expanded":""}`])},[i("button",Ma,[i("div",Ea,"Item "+t(n)+"."+t(l),1),c[3]||(c[3]=i("i",{class:"chi-icon icon-chevron-down","aria-hidden":"true"},null,-1))]),i("div",ya,[(e(),s(d,null,r(v,g=>i("a",{href:"#exampleHashTarget",class:p(`${a===U&&n===R&&l===R&&g===R?"-active":""}`)},[i("span",null,"Item "+t(n)+"."+t(l)+"."+t(g),1)],2)),64))])],2)),64))])])],2)),64)),c[4]||(c[4]=i("a",{href:"#exampleHashTarget"},[i("span",null,[w("External"),i("i",{class:"chi-icon icon-external-link -xs","aria-hidden":"true"})])],-1))])])],8,ba)),64))])],512),i("div",Ca,[(e(),s(d,null,r([1,2,3,4],a=>i("p",null,"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.")),64))])])]),"code-webcomponent":I(()=>[_(x,{class:"html",lang:"html",code:h.webcomponent},null,8,["code"])]),"code-htmlblueprint":I(()=>[_(m),_(x,{lang:"html",code:h.htmlblueprint},null,8,["code"])]),_:1})}}}),Aa={class:"-text"},La=T({__name:"index",setup(H){const u=J();return ii().public.baseUrl,(v,o)=>{const h=K;return e(),s(d,null,[o[14]||(o[14]=i("h2",null,"Examples",-1)),_(bi),["lumen","centurylink"].includes(V(u))?(e(),s(d,{key:0},[_(Li),_(nc)],64)):O("",!0),_(Sa),["lumen","centurylink"].includes(V(u))?(e(),s(d,{key:1},[o[11]||(o[11]=i("h2",null,"Active Usage",-1)),i("p",Aa,[o[1]||(o[1]=w("The ",-1)),o[2]||(o[2]=i("code",null,"-active",-1)),o[3]||(o[3]=w(" class can be applied to ",-1)),o[4]||(o[4]=i("code",null,"ul.chi-sidenav__list > li",-1)),o[5]||(o[5]=w(" for activating the elements in the sidenav menu, ",-1)),o[6]||(o[6]=i("code",null,".drawer",-1)),o[7]||(o[7]=w(" for opening the ",-1)),_(h,{to:`/components/drawer/?theme=${V(u)}`},{default:I(()=>[...o[0]||(o[0]=[w("drawer",-1)])]),_:1},8,["to"]),o[8]||(o[8]=w(", and ",-1)),o[9]||(o[9]=i("code",null,"ul.chi-sidenav__drawer-list > li",-1)),o[10]||(o[10]=w(" for activating the menu items inside the drawer.",-1))]),o[12]||(o[12]=i("h2",null,"Sizes",-1)),o[13]||(o[13]=i("p",{class:"-text"},[w("Sidenav supports the following sizes: "),i("code",null,"-sm"),w(", "),i("code",null,"-md"),w(" and "),i("code",null,"-lg"),w(". The default size is "),i("code",null,"-md"),w(".")],-1)),_(Hc),_(Vc),_(la)],64)):O("",!0),_(ha)],64)}}});export{La as _};
