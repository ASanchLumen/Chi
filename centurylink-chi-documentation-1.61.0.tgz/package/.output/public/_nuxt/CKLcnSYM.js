import{_ as A}from"./DnPF01B5.js";import{_ as w}from"./CdcsEwU-.js";import{e as b,i as y,o as c,w as n,b as o,a,c as p,r as T,F as _,S as C,d as t,l as f,t as $,K as E,q as L,k as H}from"./DBXeQHmC.js";import{_ as I}from"./DHu6vfya.js";const S={class:"chi-grid"},j={key:0,class:"-mb--1 chi-col -w--6 -w-sm--4 -w-md--6 -w-lg--4 -w-xl--3"},M={class:"chi-avatar-group"},W=b({__name:"_avatar-groups",setup(g){const d=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],e=["grey","red","pink","purple","indigo","navy","blue","cyan","teal","green","yellow","orange","secondary","primary"],v={webcomponent:"",htmlblueprint:`<div class="chi-avatar-group">
  <div class="chi-avatar">L</div>Label text
</div>`};return(l,r)=>{const s=A,m=w;return c(),y(m,{title:"Avatar Groups",id:"avatar-groups",tabs:d},{"example-description":n(()=>[...r[0]||(r[0]=[a("p",{class:"-text"},[t("Use avatar groups to group multiple avatars or add descriptive text such as a users name. Render an avatar group by wrapping an avatar in the class "),a("code",null,"chi-avatar-group"),t(".")],-1)])]),example:n(()=>[a("div",S,[(c(),p(_,null,T(e,u=>(c(),p(_,null,[u!=="secondary"?(c(),p("div",j,[a("div",M,[a("div",{class:f(`chi-avatar -${u}`)},"L",2),t("Label "+$(u),1)])])):C("",!0)],64))),64))])]),"code-webcomponent":n(()=>[o(s,{lang:"html",code:v.webcomponent},null,8,["code"])]),"code-htmlblueprint":n(()=>[o(s,{lang:"html",code:v.htmlblueprint},null,8,["code"])]),_:1})}}}),z=b({__name:"_base",setup(g){const d=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],e={webcomponent:"",htmlblueprint:`<div class="chi-avatar">
  <img src="path/to/image.jpg" alt="avatar">
</div>`};return(v,l)=>{const r=A,s=w;return c(),y(s,{title:"Base",id:"base",tabs:d},{example:n(()=>[...l[0]||(l[0]=[a("div",{class:"chi-avatar"},[a("img",{src:I,alt:"avatar"})],-1)])]),"code-webcomponent":n(()=>[o(r,{class:"html",lang:"html",code:e.webcomponent},null,8,["code"])]),"code-htmlblueprint":n(()=>[o(r,{class:"html",lang:"html",code:e.htmlblueprint},null,8,["code"])]),_:1})}}}),U={class:"-text"},N=["href"],V={class:"-p--0"},F={class:"chi-grid -align-items--end"},R={key:0,class:"chi-col -w--2 -text--center"},q={key:0,class:"chi-icon icon-user","aria-hidden":"true"},D={class:"-text"},G=b({__name:"_color-customization",setup(g){const d=E().public.baseUrl,e=L(!1),v=L("initial"),l=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],r=[{active:!0,id:"initial",label:"Initial"},{id:"icon",label:"Icon"}],s=["grey","red","pink","purple","indigo","navy","blue","cyan","teal","green","yellow","orange","secondary","primary"],m={webcomponent:"",htmlblueprint:{initial:`<div class="chi-avatar -grey">AA</div>
<div class="chi-avatar -red">AA</div>
<div class="chi-avatar -pink">AA</div>
<div class="chi-avatar -purple">AA</div>
<div class="chi-avatar -indigo">AA</div>
<div class="chi-avatar -navy">AA</div>
<div class="chi-avatar -blue">AA</div>
<div class="chi-avatar -cyan">AA</div>
<div class="chi-avatar -teal">AA</div>
<div class="chi-avatar -green">AA</div>
<div class="chi-avatar -yellow">AA</div>
<div class="chi-avatar -orange">AA</div>
<div class="chi-avatar -primary">AA</div>`,icon:`<div class="chi-avatar -grey">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>
<div class="chi-avatar -red">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>
<div class="chi-avatar -pink">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>
<div class="chi-avatar -purple">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>
<div class="chi-avatar -indigo">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>
<div class="chi-avatar -navy">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>
<div class="chi-avatar -blue">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>
<div class="chi-avatar -cyan">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>
<div class="chi-avatar -teal">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>
<div class="chi-avatar -green">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>
<div class="chi-avatar -yellow">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>
<div class="chi-avatar -orange">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>
<div class="chi-avatar -primary">
<i class="chi-icon icon-user" aria-hidden="true"></i>
</div>`}},u=h=>{v.value=h.id,e.value=h.id==="icon"};return(h,i)=>{const k=A,x=w;return c(),y(x,{title:"Color",id:"color",tabs:l,"head-tabs":r,onChiHeadTabsChange:u},{"example-description":n(()=>[a("p",U,[i[0]||(i[0]=t("Both icon and initial avatars support ",-1)),a("a",{href:`${H(d)}foundations/color/`},"Chi colors",8,N),i[1]||(i[1]=t(". To color an icon, apply any of the following color classes: ",-1)),i[2]||(i[2]=a("code",null,"-grey",-1)),i[3]||(i[3]=t(", ",-1)),i[4]||(i[4]=a("code",null,"-red",-1)),i[5]||(i[5]=t(", ",-1)),i[6]||(i[6]=a("code",null,"-pink",-1)),i[7]||(i[7]=t(", ",-1)),i[8]||(i[8]=a("code",null,"-purple",-1)),i[9]||(i[9]=t(", ",-1)),i[10]||(i[10]=a("code",null,"-indigo",-1)),i[11]||(i[11]=t(", ",-1)),i[12]||(i[12]=a("code",null,"-navy",-1)),i[13]||(i[13]=t(", ",-1)),i[14]||(i[14]=a("code",null,"-blue",-1)),i[15]||(i[15]=t(", ",-1)),i[16]||(i[16]=a("code",null,"-teal",-1)),i[17]||(i[17]=t(", ",-1)),i[18]||(i[18]=a("code",null,"-green",-1)),i[19]||(i[19]=t(", ",-1)),i[20]||(i[20]=a("code",null,"-yellow",-1)),i[21]||(i[21]=t(", ",-1)),i[22]||(i[22]=a("code",null,"-orange",-1)),i[23]||(i[23]=t(", ",-1)),i[24]||(i[24]=a("code",null,"-secondary",-1)),i[25]||(i[25]=t(", ",-1)),i[26]||(i[26]=a("code",null,"-primary",-1))])]),example:n(()=>[a("div",V,[a("div",F,[(c(),p(_,null,T(s,B=>(c(),p(_,null,[B!=="secondary"?(c(),p("div",R,[a("div",{class:f(`chi-avatar -${B}`)},[t($(e.value?"":"AA"),1),e.value?(c(),p("i",q)):C("",!0)],2),a("p",D,$(B),1)])):C("",!0)],64))),64))])])]),"code-htmlblueprint":n(()=>[o(k,{lang:"html",code:m.htmlblueprint[v.value]},null,8,["code"])]),_:1})}}}),K={class:"-text"},J=["href"],O={class:"chi-grid"},P={class:"chi-col -w--2 -w-sm--1"},Q={class:"chi-avatar"},X=b({__name:"_icon-avatar",setup(g){const d=E().public.baseUrl,e=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],v=["user","users","atom"],l={webcomponent:"",htmlblueprint:`<div class="chi-avatar">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>`};return(r,s)=>{const m=A,u=w;return c(),y(u,{title:"Icon Avatars",id:"icon-avatars",tabs:e},{"example-description":n(()=>[a("p",K,[s[0]||(s[0]=t("Icon avatars can be used when an image is not available. To use, wrap any ",-1)),a("a",{href:`${H(d)}components/icon/`},"Chi icon",8,J),s[1]||(s[1]=t(" with ",-1)),s[2]||(s[2]=a("code",null,"chi-avatar",-1)),s[3]||(s[3]=t(".",-1))])]),example:n(()=>[a("div",O,[(c(),p(_,null,T(v,h=>a("div",P,[a("div",Q,[a("i",{class:f(`chi-icon icon-${h}`),"aria-hidden":"true"},null,2)])])),64))])]),"code-webcomponent":n(()=>[o(m,{class:"html",lang:"html",code:l.webcomponent},null,8,["code"])]),"code-htmlblueprint":n(()=>[o(m,{class:"html",lang:"html",code:l.htmlblueprint},null,8,["code"])]),_:1})}}}),Y=b({__name:"_initial-avatar",setup(g){const d=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],e={webcomponent:"",htmlblueprint:'<div class="chi-avatar">AA</div>'};return(v,l)=>{const r=A,s=w;return c(),y(s,{title:"Initial Avatars",id:"initial-avatars",tabs:d},{"example-description":n(()=>[...l[0]||(l[0]=[a("p",{class:"-text"},[t("Initial avatars can also be used when an image is not available. They are more versatile than icon avatars and support up to two letters. Text utility classes such as "),a("code",null,"-text--uppercase"),t(", "),a("code",null,"-text--lowercase"),t(", and "),a("code",null,"-text--capitalized"),t(" can be applied to force specific casing.")],-1)])]),example:n(()=>[...l[1]||(l[1]=[a("div",{class:"chi-grid"},[a("div",{class:"chi-col -w--2 -w-sm--1"},[a("div",{class:"chi-avatar"},"AA")]),a("div",{class:"chi-col -w--2 -w-sm--1"},[a("div",{class:"chi-avatar"},"M")])],-1)])]),"code-webcomponent":n(()=>[o(r,{class:"html",lang:"html",code:e.webcomponent},null,8,["code"])]),"code-htmlblueprint":n(()=>[o(r,{lang:"html",code:e.htmlblueprint},null,8,["code"])]),_:1})}}}),Z=b({__name:"_light-transparent",setup(g){const d=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],e={webcomponent:"",htmlblueprint:`<div class="-bg--black">
  <div class="chi-avatar -light">AA</div>
  <div class="chi-avatar -secondary -transparent">AA</div>
  <div class="chi-avatar -light">
    <i class="chi-icon icon-user" aria-hidden="true"></i>
  </div>
  <div class="chi-avatar -secondary -transparent">
    <i class="chi-icon icon-user" aria-hidden="true"></i>
  </div>
</div>`};return(v,l)=>{const r=A,s=w;return c(),y(s,{title:"Light and transparent background",additionalClasses:"-bg--black",id:"light-transparent",tabs:d},{"example-description":n(()=>[...l[0]||(l[0]=[a("p",{class:"-text"},"Both icon and initial avatars support light and transparent versions for dark backgrounds.",-1)])]),example:n(()=>[...l[1]||(l[1]=[a("div",{class:"chi-grid -align-items--end"},[a("div",{class:"chi-col -w--3 -text--center"},[a("div",{class:"chi-avatar -light"},"AA")]),a("div",{class:"chi-col -w--3 -text--center"},[a("div",{class:"chi-avatar -secondary -transparent"},"AA")]),a("div",{class:"chi-col -w--3 -text--center"},[a("div",{class:"chi-avatar -light"},[a("i",{class:"chi-icon icon-user","aria-hidden":"true"})])]),a("div",{class:"chi-col -w--3 -text--center"},[a("div",{class:"chi-avatar -secondary -transparent"},[a("i",{class:"chi-icon icon-user","aria-hidden":"true"})])])],-1)])]),"code-webcomponent":n(()=>[o(r,{class:"html",lang:"html",code:e.webcomponent},null,8,["code"])]),"code-htmlblueprint":n(()=>[o(r,{class:"html",lang:"html",code:e.htmlblueprint},null,8,["code"])]),_:1})}}}),aa={class:"-p--0"},ia={class:"chi-grid -align-items--end"},ta={key:0,class:"chi-icon icon-user","aria-hidden":"true"},ea={key:1,src:I,alt:"avatar"},sa={class:"-text"},na=b({__name:"_sizes",setup(g){const d=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],e=[{active:!0,id:"initial",label:"Initial"},{id:"icon",label:"Icon"},{id:"image",label:"Image"}],v=["xs","sm","sm--2","sm--3","md","lg","xl","xxl"],l={xs:["4","3","1"],sm:["4","3","1"],"sm--2":["4","3","1"],"sm--3":["4","3","1"],md:["4","2","1"],lg:["4","3","2"],xl:["6","3","2"],xxl:["6","4","3"]},r={webcomponent:"",htmlblueprint:{initial:`<div class="chi-avatar -xs">AA</div>
<div class="chi-avatar -sm">AA</div>
<div class="chi-avatar -sm--2">AA</div>
<div class="chi-avatar -sm--3">AA</div>
<div class="chi-avatar -md">AA</div>
<div class="chi-avatar -lg">AA</div>
<div class="chi-avatar -xl">AA</div>
<div class="chi-avatar -xxl">AA</div>`,icon:`<div class="chi-avatar -xs">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>
<div class="chi-avatar -sm">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>
<div class="chi-avatar -sm--2">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>
<div class="chi-avatar -sm--3">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>
<div class="chi-avatar -md">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>
<div class="chi-avatar -lg">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>
<div class="chi-avatar -xl">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>
<div class="chi-avatar -xxl">
  <i class="chi-icon icon-user" aria-hidden="true"></i>
</div>`,image:`<div class="chi-avatar -xs">
  <img src="path/to/image.jpg">
</div>
<div class="chi-avatar -sm">
  <img src="path/to/image.jpg">
</div>
<div class="chi-avatar -sm--2">
  <img src="path/to/image.jpg">
</div>
<div class="chi-avatar -sm--3">
  <img src="path/to/image.jpg">
</div>
<div class="chi-avatar -md">
  <img src="path/to/image.jpg">
</div>
<div class="chi-avatar -lg">
  <img src="path/to/image.jpg">
</div>
<div class="chi-avatar -xl">
  <img src="path/to/image.jpg">
</div>
<div class="chi-avatar -xxl">
  <img src="path/to/image.jpg">
</div>`}},s=L("initial"),m=u=>{s.value=u.id};return(u,h)=>{const i=A,k=w;return c(),y(k,{title:"Size",id:"size",tabs:d,"head-tabs":e,onChiHeadTabsChange:m},{"example-description":n(()=>[...h[0]||(h[0]=[a("p",{class:"-text"},[t("All three avatar styles support a full spectrum of sizes: "),a("code",null,"-xs"),t(", "),a("code",null,"-sm"),t(", "),a("code",null,"-sm--2"),t(", "),a("code",null,"-sm--3"),t(", "),a("code",null,"-md"),t(", "),a("code",null,"-lg"),t(", "),a("code",null,"-xl"),t(", "),a("code",null,"-xxl"),t(". "),a("code",null,"-md"),t(" is the default size.")],-1)])]),example:n(()=>[a("div",aa,[a("div",ia,[(c(),p(_,null,T(v,x=>a("div",{class:f(`chi-col -w--${l[x][0]} -w-lg--${l[x][1]} -w-xl--${l[x][2]} -text--center`)},[a("div",{class:f(`chi-avatar -${x}`)},[t($(s.value==="initial"?"AA":""),1),s.value==="icon"?(c(),p("i",ta)):C("",!0),s.value==="image"?(c(),p("img",ea)):C("",!0)],2),a("p",sa,$(x),1)],2)),64))])])]),"code-htmlblueprint":n(()=>[o(i,{lang:"html",code:r.htmlblueprint[s.value]},null,8,["code"])]),_:1})}}}),da=b({__name:"index",setup(g){return(d,e)=>(c(),p(_,null,[e[0]||(e[0]=a("h2",null,"Examples",-1)),e[1]||(e[1]=a("p",{class:"-text"},[t("To render an avatar, apply the class "),a("code",null,"chi-avatar"),t(" to a div element and place an image inside.")],-1)),o(z),o(X),o(Y),e[2]||(e[2]=a("h2",null,"Customizations",-1)),o(G),o(Z),o(na),o(W)],64))}});export{da as _};
