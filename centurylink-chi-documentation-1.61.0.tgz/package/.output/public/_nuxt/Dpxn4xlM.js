import{_ as y}from"./DnPF01B5.js";import{_ as g}from"./CdcsEwU-.js";import{e as h,i as v,o as r,w as s,a as e,b as a,g as C,q as E,H as T,c as x,r as B,t as $,l as H,k as M,F as N,d as u}from"./DBXeQHmC.js";const q=h({__name:"_base",setup(_){const p=o=>{const t=o.target,{files:n,value:m,nextElementSibling:f}=t,d=n?.length>1?`${n.length} files selected`:m.split("\\").pop();f&&d&&(f.innerHTML=d)},i=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],c={webcomponent:"",htmlblueprint:`<input type="file" class="chi-file-input" id="file01" aria-label="Choose file">
<label for="file01">No file chosen</label>
<script>
var inputFiles = document.querySelectorAll('input[type="file"].chi-file-input');

Array.prototype.forEach.call(inputFiles, function(input) {
  var label = input.nextElementSibling;

  input.addEventListener('change', function() {
    var fileName = '';

    if (this.files && this.files.length > 1) {
      fileName = this.files.length + ' files selected';
    } else {
      fileName = this.value.split('\\').pop();
    }

    if (label && fileName) {
      label.innerHTML = fileName;
    }
  });
});
<\/script>`};return(o,t)=>{const n=y,m=g;return r(),v(m,{title:"Base",id:"base",tabs:i},{example:s(()=>[e("input",{class:"chi-file-input",type:"file",id:"file01","aria-label":"Choose file",onChange:p},null,32),t[0]||(t[0]=e("label",{for:"file01"},"No file chosen",-1))]),"code-webcomponent":s(()=>[a(n,{class:"html",lang:"html",code:c.webcomponent},null,8,["code"])]),"code-htmlblueprint":s(()=>[t[1]||(t[1]=e("div",{class:"chi-tab__description -text--grey"},"This HTML Blueprint requires JavaScript to update the label content once a file or files have been selected. You may use your own JavaScript solution, or use Chi's example below.",-1)),a(n,{lang:"html",code:c.htmlblueprint},null,8,["code"])]),_:1})}}}),F=h({__name:"_disabled",setup(_){const p=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],i={webcomponent:"",htmlblueprint:`<input type="file" class="chi-file-input" id="unique-id-di1" aria-label="Choose file" disabled>
<label for="unique-id-di1">No file chosen</label>

<script>
var inputFiles = document.querySelectorAll('input[type="file"].chi-file-input');

Array.prototype.forEach.call(inputFiles, function(input) {
  var label = input.nextElementSibling;

  input.addEventListener('change', function() {
    var fileName = '';

    if (this.files && this.files.length > 1) {
      fileName = this.files.length + ' files selected';
    } else {
      fileName = this.value.split('\\').pop();
    }

    if (label && fileName) {
      label.innerHTML = fileName;
    }
  });
});
<\/script>`};return(c,o)=>{const t=y,n=g;return r(),v(n,{title:"Disabled",id:"disabled",tabs:p},{example:s(()=>[...o[0]||(o[0]=[e("input",{class:"chi-file-input",id:"unique-id-di1",type:"file","aria-label":"Choose file",disabled:""},null,-1),e("label",{for:"unique-id-di1"},"No file chosen",-1)])]),"code-webcomponent":s(()=>[a(t,{lang:"html",code:i.webcomponent},null,8,["code"])]),"code-htmlblueprint":s(()=>[o[1]||(o[1]=e("div",{class:"chi-tab__description -text--grey"},"This HTML Blueprint requires JavaScript to update the label content once a file or files have been selected. You may use your own JavaScript solution, or use Chi's example below.",-1)),a(t,{lang:"html",code:i.htmlblueprint},null,8,["code"])]),_:1})}}}),k={class:"-text"},z=["innerHTML"],A={class:"-text--bold -mt--0"},I=["id"],J=["for"],V=h({__name:"_sizes",setup(_){const p=["xs","sm","md","lg"],i=["xs","sm","md","lg","xl"],c=C(),o=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],t={portal:p,centurylink:i,lumen:i},n=E(C()),m=T(()=>t[n.value.toLowerCase()].map(l=>`
<!-- -${l} -->
<input type="file" class="chi-file-input -${l}" id="example-file-input_${l}" aria-label="Choose file">
<label for="example-file-input_${l}">No file chosen</label>
`).join("")),f=T(()=>t[n.value.toLowerCase()].map(l=>`<code>-${l}</code>`).join());return(d,l)=>{const S=y,L=g;return r(),v(L,{title:"Sizes",id:"sizes",tabs:o},{"example-description":s(()=>[e("p",k,[l[0]||(l[0]=u("File inputs support sizes:",-1)),e("span",{innerHTML:f.value},null,8,z),l[1]||(l[1]=u(". The default size is ",-1)),l[2]||(l[2]=e("code",null,"-md",-1)),l[3]||(l[3]=u(".",-1))])]),example:s(()=>[(r(!0),x(N,null,B(t[M(c)],(b,w)=>(r(),x("div",{class:"-p--2",key:w},[e("p",A,"-"+$(b),1),e("input",{class:H(`chi-file-input -${b}`),type:"file",id:`example-file-${b}`,"aria-label":"Choose file"},null,10,I),e("label",{for:`example-file-${b}`},"No file chosen",8,J)]))),128))]),"code-htmlblueprint":s(()=>[a(S,{lang:"html",code:m.value},null,8,["code"])]),_:1})}}}),D=h({__name:"index",setup(_){return(p,i)=>(r(),x(N,null,[i[0]||(i[0]=e("h2",null,"Examples",-1)),i[1]||(i[1]=e("p",{class:"-text"},[u("To render a file input, apply the class "),e("code",null,"chi-file-input"),u("to an "),e("code",null,'input type="file"'),u(" and add a label next to it.")],-1)),a(q),a(F),a(V)],64))}});export{D as _};
