import{_ as v}from"./DnPF01B5.js";import{_ as h}from"./Bo0goINO.js";import{_ as g}from"./CdcsEwU-.js";import{e as m,q as u,x,z as w,i as y,o as _,w as s,b as n,a as e,c as k,r as C,t as $,F as T,d as f}from"./DBXeQHmC.js";const E={class:"chi-form__item"},R=m({__name:"_base",setup(b){const r=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],t={webcomponent:"",htmlblueprint:`<div class="chi-form__item">
  <label class="chi-label" for="range01">Range label</label>
  <input class="chi-range-slider" type="range" id="range01">
</div>

<script>chi.rangeSlider(document.getElementById('range01'));<\/script>`},o=u(null),a=u(null);return x(()=>{o.value=chi.rangeSlider(a.value)}),w(()=>{o.value?.dispose()}),(c,l)=>{const i=v,d=h,p=g;return _(),y(p,{title:"Base",id:"base",tabs:r},{example:s(()=>[e("div",E,[l[0]||(l[0]=e("label",{class:"chi-label",for:"range01"},"Range label",-1)),e("input",{class:"chi-range-slider",id:"range01",type:"range",ref_key:"range",ref:a},null,512)])]),"code-webcomponent":s(()=>[n(i,{class:"html",lang:"html",code:t.webcomponent},null,8,["code"])]),"code-htmlblueprint":s(()=>[n(d),n(i,{lang:"html",code:t.htmlblueprint},null,8,["code"])]),_:1})}}}),M={class:"chi-form__item"},L={class:"chi-input__wrapper"},N=m({__name:"_base_consistent",setup(b){const r=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],t={webcomponent:"",htmlblueprint:`<div class="chi-form__item">
  <label class="chi-label" for="range04">Range label</label>
  <div class="chi-input__wrapper">
    <input class="chi-range-slider" type="range" id="range04">
    <div class="chi-input__progress"></div>
    <div class="chi-input__thumb"></div>
  </div>
</div>

<script>chi.rangeSlider(document.getElementById('range04'));<\/script>`},o=u(null),a=u(null);return x(()=>{o.value=chi.rangeSlider(a.value)}),w(()=>{o.value?.dispose()}),(c,l)=>{const i=v,d=h,p=g;return _(),y(p,{title:"Base",id:"base-consistent",tabs:r},{example:s(()=>[e("div",M,[l[2]||(l[2]=e("label",{class:"chi-label",for:"range04"},"Range label",-1)),e("div",L,[e("input",{class:"chi-range-slider",id:"range04",type:"range",ref_key:"range",ref:a},null,512),l[0]||(l[0]=e("div",{class:"chi-input__progress"},null,-1)),l[1]||(l[1]=e("div",{class:"chi-input__thumb"},null,-1))])])]),"code-webcomponent":s(()=>[n(i,{class:"html",lang:"html",code:t.webcomponent},null,8,["code"])]),"code-htmlblueprint":s(()=>[n(d),n(i,{lang:"html",code:t.htmlblueprint},null,8,["code"])]),_:1})}}}),J=m({__name:"_disabled",setup(b){const r=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],t={webcomponent:"",htmlblueprint:`<div class="chi-form__item">
  <label class="chi-label" for="range02">Range label</label>
  <input class="chi-range-slider" type="range" id="range02" disabled>
</div>

<script>chi.rangeSlider(document.getElementById('range02'));<\/script>`};return(o,a)=>{const c=v,l=h,i=g;return _(),y(i,{title:"Disabled",id:"disabled",tabs:r},{example:s(()=>[...a[0]||(a[0]=[e("div",{class:"chi-form__item"},[e("label",{class:"chi-label",for:"range02"},"Range label"),e("input",{class:"chi-range-slider",type:"range",id:"range02",disabled:""})],-1)])]),"code-webcomponent":s(()=>[n(c,{class:"html",lang:"html",code:t.webcomponent},null,8,["code"])]),"code-htmlblueprint":s(()=>[n(l),n(c,{lang:"html",code:t.htmlblueprint},null,8,["code"])]),_:1})}}}),W=m({__name:"_disabled_consistent",setup(b){const r=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],t={webcomponent:"",htmlblueprint:`<div class="chi-form__item">
  <label class="chi-label" for="range05">Range label</label>
  <div class="chi-input__wrapper">
    <input class="chi-range-slider" type="range" id="range05" disabled>
    <div class="chi-input__progress"></div>
    <div class="chi-input__thumb"></div>
  </div>
</div>

<script>chi.rangeSlider(document.getElementById('range05'));<\/script>`};return(o,a)=>{const c=v,l=h,i=g;return _(),y(i,{title:"Disabled",id:"disabled-consistent",tabs:r},{example:s(()=>[...a[0]||(a[0]=[e("div",{class:"chi-form__item"},[e("label",{class:"chi-label",for:"range05"},"Range label"),e("div",{class:"chi-input__wrapper"},[e("input",{class:"chi-range-slider",type:"range",id:"range05",disabled:""}),e("div",{class:"chi-input__progress"}),e("div",{class:"chi-input__thumb"})])],-1)])]),"code-webcomponent":s(()=>[n(c,{class:"html",lang:"html",code:t.webcomponent},null,8,["code"])]),"code-htmlblueprint":s(()=>[n(l),n(c,{lang:"html",code:t.htmlblueprint},null,8,["code"])]),_:1})}}}),H={class:"chi-form__item"},I={class:"chi-input__wrapper -d--flex"},D={class:"chi-input__wrapper -w--100"},G=m({__name:"_multiple_consistent",setup(b){const r=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],t={webcomponent:"",htmlblueprint:`<div class="chi-form__item">
  <label class="chi-label" for="range06">Range label</label>
  <div class="chi-input__wrapper -d--flex">
    <span class="-text -mr--2">200GB</span>
    <div class="chi-input__wrapper -w--100">
      <input class="chi-range-slider" type="range" id="range06">
      <div class="chi-input__progress"></div>
      <div class="chi-input__thumb"></div>
    </div>
    <span class="-text -ml--2">5TB</span>
  </div>
</div>

<script>chi.rangeSlider(document.getElementById('range06'));<\/script>`},o=u(null),a=u(null);return x(()=>{o.value=chi.rangeSlider(a.value)}),w(()=>{o.value?.dispose()}),(c,l)=>{const i=v,d=h,p=g;return _(),y(p,{title:"Multiple Labels",id:"multiple-labels-consistent",tabs:r},{example:s(()=>[e("div",H,[l[4]||(l[4]=e("label",{class:"chi-label",for:"range06"},"Range label",-1)),e("div",I,[l[2]||(l[2]=e("span",{class:"-text -mr--2"},"200GB",-1)),e("div",D,[e("input",{class:"chi-range-slider",type:"range",id:"range06",ref_key:"range",ref:a},null,512),l[0]||(l[0]=e("div",{class:"chi-input__progress"},null,-1)),l[1]||(l[1]=e("div",{class:"chi-input__thumb"},null,-1))]),l[3]||(l[3]=e("span",{class:"-text -ml--2"},"5TB",-1))])])]),"code-webcomponent":s(()=>[n(i,{class:"html",lang:"html",code:t.webcomponent},null,8,["code"])]),"code-htmlblueprint":s(()=>[n(d),n(i,{lang:"html",code:t.htmlblueprint},null,8,["code"])]),_:1})}}}),z={class:"chi-form__item"},V={class:"chi-input__wrapper -d--flex"},A=m({__name:"_multiple_labels",setup(b){const r=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],t={webcomponent:"",htmlblueprint:`<div class="chi-form__item">
  <label class="chi-label" for="range03">Range label</label>
  <div class="chi-input__wrapper -d--flex">
    <span class="-text">200GB</span>
    <input class="chi-range-slider -mx--2" type="range" id="range03">
    <span class="-text">5TB</span>
  </div>
</div>

<script>chi.rangeSlider(document.getElementById('range03'));<\/script>`},o=u(null),a=u(null);return x(()=>{o.value=chi.rangeSlider(a.value)}),w(()=>{o.value?.dispose()}),(c,l)=>{const i=v,d=h,p=g;return _(),y(p,{title:"Multiple Labels",id:"multiple-labels",tabs:r},{example:s(()=>[e("div",z,[l[2]||(l[2]=e("label",{class:"chi-label",for:"range03"},"Range label",-1)),e("div",V,[l[0]||(l[0]=e("span",{class:"-text -mr--2"},"200GB",-1)),e("input",{class:"chi-range-slider",type:"range",id:"range03",ref_key:"range",ref:a},null,512),l[1]||(l[1]=e("span",{class:"-text -ml--2"},"5TB",-1))])])]),"code-webcomponent":s(()=>[n(i,{class:"html",lang:"html",code:t.webcomponent},null,8,["code"])]),"code-htmlblueprint":s(()=>[n(d),n(i,{lang:"html",code:t.htmlblueprint},null,8,["code"])]),_:1})}}}),F={class:"chi-form__item"},q={class:"chi-input__wrapper"},K={class:"chi-input__tick-bar"},U={class:"chi-input__tick-label"},Y=m({__name:"_radio_consistent",setup(b){const r=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],t=["Monthly","1 year","2 years","3 years","> 3 years"],o={webcomponent:"",htmlblueprint:`<div class="chi-form__item">
  <label class="chi-label" for="range09">Range label</label>
  <div class="chi-input__wrapper">
    <input class="chi-range-slider" type="range" min="0" max="4" step="1" id="range09">
    <div class="chi-input__tick-bar">
      <div>
        <div class="chi-input__tick"></div>
        <div class="chi-input__tick-label">Monthly</div>
      </div>
      <div>
        <div class="chi-input__tick"></div>
        <div class="chi-input__tick-label">1 year</div>
      </div>
      <div>
        <div class="chi-input__tick"></div>
        <div class="chi-input__tick-label">2 years</div>
      </div>
      <div>
        <div class="chi-input__tick"></div>
        <div class="chi-input__tick-label">3 years</div>
      </div>
      <div>
        <div class="chi-input__tick"></div>
        <div class="chi-input__tick-label">&gt; 3 years</div>
      </div>
    </div>
    <div class="chi-input__progress"></div>
    <div class="chi-input__thumb"></div>
  </div>
</div>

<script>chi.rangeSlider(document.getElementById('range09'));<\/script>`},a=u(null),c=u(null);return x(()=>{a.value=chi.rangeSlider(c.value)}),w(()=>{a.value?.dispose()}),(l,i)=>{const d=v,p=h,S=g;return _(),y(S,{title:"Consistent rendering in WebKit browsers",id:"radio-consistent",tabs:r},{example:s(()=>[e("div",F,[i[4]||(i[4]=e("label",{class:"chi-label",for:"range09"},"Range label",-1)),e("div",q,[e("input",{class:"chi-range-slider",id:"range09",type:"range",min:"0",max:"4",step:"1",ref_key:"range",ref:c},null,512),e("div",K,[(_(),k(T,null,C(t,B=>e("div",null,[i[0]||(i[0]=e("div",null,null,-1)),i[1]||(i[1]=e("div",{class:"chi-input__tick"},null,-1)),e("div",U,$(B),1)])),64))]),i[2]||(i[2]=e("div",{class:"chi-input__progress"},null,-1)),i[3]||(i[3]=e("div",{class:"chi-input__thumb"},null,-1))])])]),"code-webcomponent":s(()=>[n(d,{class:"html",lang:"html",code:o.webcomponent},null,8,["code"])]),"code-htmlblueprint":s(()=>[n(p),n(d,{lang:"html",code:o.htmlblueprint},null,8,["code"])]),_:1})}}}),j={class:"chi-form__item"},O={class:"chi-input__wrapper"},P={class:"chi-input__tick-bar"},Q={class:"chi-input__tick-label"},X=m({__name:"_radio_disabled",setup(b){const r=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],t=["Monthly","1 year","2 years","3 years","> 3 years"],o={webcomponent:"",htmlblueprint:`<div class="chi-form__item">
  <label class="chi-label" for="range08">Range label</label>
  <div class="chi-input__wrapper">
    <input class="chi-range-slider" type="range" min="0" max="4" step="1" id="range08" disabled>
    <div class="chi-input__tick-bar">
      <div>
        <div class="chi-input__tick"></div>
        <div class="chi-input__tick-label">Monthly</div>
      </div>
      <div>
        <div class="chi-input__tick"></div>
        <div class="chi-input__tick-label">1 year</div>
      </div>
      <div>
        <div class="chi-input__tick"></div>
        <div class="chi-input__tick-label">2 years</div>
      </div>
      <div>
        <div class="chi-input__tick"></div>
        <div class="chi-input__tick-label">3 years</div>
      </div>
      <div>
        <div class="chi-input__tick"></div>
        <div class="chi-input__tick-label">&gt; 3 years</div>
      </div>
    </div>
  </div>
</div>

<script>chi.rangeSlider(document.getElementById('range08'));<\/script>`};return(a,c)=>{const l=v,i=h,d=g;return _(),y(d,{title:"Disabled",id:"radio-disabled",tabs:r},{example:s(()=>[e("div",j,[c[3]||(c[3]=e("label",{class:"chi-label",for:"range08"},"Range label",-1)),e("div",O,[c[2]||(c[2]=e("input",{class:"chi-range-slider",type:"range",min:"0",max:"4",step:"1",id:"range08",disabled:""},null,-1)),e("div",P,[(_(),k(T,null,C(t,p=>e("div",null,[c[0]||(c[0]=e("div",null,null,-1)),c[1]||(c[1]=e("div",{class:"chi-input__tick"},null,-1)),e("div",Q,$(p),1)])),64))])])])]),"code-webcomponent":s(()=>[n(l,{class:"html",lang:"html",code:o.webcomponent},null,8,["code"])]),"code-htmlblueprint":s(()=>[n(i),n(l,{lang:"html",code:o.htmlblueprint},null,8,["code"])]),_:1})}}}),Z={class:"chi-form__item"},ee={class:"chi-input__wrapper"},ie={class:"chi-input__tick-bar"},le={class:"chi-input__tick-label"},ne=m({__name:"_radio_slider",setup(b){const r=[{disabled:!0,id:"webcomponent",label:"Web Component"},{active:!0,id:"htmlblueprint",label:"HTML Blueprint"}],t=["Monthly","1 year","2 years","3 years","> 3 years"],o={webcomponent:"",htmlblueprint:`<div class="chi-form__item">
  <label class="chi-label" for="range07">Range label</label>
  <div class="chi-input__wrapper">
    <input class="chi-range-slider" type="range" min="0" max="4" step="1" id="range07">
    <div class="chi-input__tick-bar">
      <div>
        <div class="chi-input__tick"></div>
        <div class="chi-input__tick-label">Monthly</div>
      </div>
      <div>
        <div class="chi-input__tick"></div>
        <div class="chi-input__tick-label">1 year</div>
      </div>
      <div>
        <div class="chi-input__tick"></div>
        <div class="chi-input__tick-label">2 years</div>
      </div>
      <div>
        <div class="chi-input__tick"></div>
        <div class="chi-input__tick-label">3 years</div>
      </div>
      <div>
        <div class="chi-input__tick"></div>
        <div class="chi-input__tick-label">&gt; 3 years</div>
      </div>
    </div>
  </div>
</div>

<script>chi.rangeSlider(document.getElementById('range07'));<\/script>`},a=u(null),c=u(null);return x(()=>{a.value=chi.rangeSlider(c.value)}),w(()=>{a.value?.dispose()}),(l,i)=>{const d=v,p=h,S=g;return _(),y(S,{title:"Radio buttons as range slider","title-size":"h2",id:"radio-slider",tabs:r},{"example-description":s(()=>[...i[0]||(i[0]=[e("div",{class:"p-text -mb--3 -text"},"Enable range sliders to function like radio buttons.",-1)])]),example:s(()=>[e("div",Z,[i[3]||(i[3]=e("label",{class:"chi-label",for:"range07"},"Range label",-1)),e("div",ee,[e("input",{class:"chi-range-slider",id:"range07",type:"range",min:"0",max:"4",step:"1",ref_key:"range",ref:c},null,512),e("div",ie,[(_(),k(T,null,C(t,B=>e("div",null,[i[1]||(i[1]=e("div",null,null,-1)),i[2]||(i[2]=e("div",{class:"chi-input__tick"},null,-1)),e("div",le,$(B),1)])),64))])])])]),"code-webcomponent":s(()=>[n(d,{class:"html",lang:"html",code:o.webcomponent},null,8,["code"])]),"code-htmlblueprint":s(()=>[n(p),n(d,{lang:"html",code:o.htmlblueprint},null,8,["code"])]),_:1})}}}),oe=m({__name:"index",setup(b){return(r,t)=>(_(),k("div",null,[t[0]||(t[0]=e("h2",null,"Examples",-1)),t[1]||(t[1]=e("p",{class:"-text"},[f("To render a range slider, apply the class "),e("code",null,"chi-range-slider"),f(" to an "),e("code",null,'input type="range"'),f(". Range widths are fluid by default.")],-1)),n(R),n(J),n(A),t[2]||(t[2]=e("h2",null,"Achieve consistent rendering",-1)),t[3]||(t[3]=e("p",{class:"-text"},[f("As webkit browsers don't support an active track bar, we've created our own. You will either need a JavaScript solution for moving the "),e("code",null,"chi-input__thumb"),f(" element and changing the size of "),e("code",null,"chi-input__progress"),f(", or you can use Chi's JavaScript library as it provides this functionality out of the box.")],-1)),n(N),n(W),n(G),n(ne),n(X),n(Y)]))}});export{oe as _};
