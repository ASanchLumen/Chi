import{am as o}from"./DBXeQHmC.js";const a=(s,p)=>`<${s}${o(p)}>
  Success
</${s}>`;export{a as snippet};
