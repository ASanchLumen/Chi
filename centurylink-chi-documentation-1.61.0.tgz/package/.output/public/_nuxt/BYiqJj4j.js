import{_ as u}from"./DnPF01B5.js";import{_ as d}from"./CdcsEwU-.js";import{e as i,i as _,o as m,w as p,b as t,a as e,c as h,d as r}from"./DBXeQHmC.js";const b=i({__name:"_base",setup(a){const s={webcomponent:'<chi-price value="100"></chi-price>',htmlblueprint:`<div class="chi-price">
  <sup>$</sup>
  100
  <sup>00</sup>
</div>`};return(c,l)=>{const n=u,o=d;return m(),_(o,{title:"Base",id:"base"},{example:p(()=>[...l[0]||(l[0]=[e("chi-price",{class:"-m--3",value:"100"},null,-1)])]),"code-webcomponent":p(()=>[t(n,{class:"html",lang:"html",code:s.webcomponent},null,8,["code"])]),"code-htmlblueprint":p(()=>[t(n,{class:"html",lang:"html",code:s.htmlblueprint},null,8,["code"])]),_:1})}}}),v=i({__name:"_sizes",setup(a){const s={webcomponent:`<!-- sm -->
<chi-price value="100" size="sm"></chi-price>

<!-- md -->
<chi-price value="100" size="md"></chi-price>

<!-- lg -->
<chi-price value="100" size="lg"></chi-price>
`,htmlblueprint:`<div class="chi-price -sm">
  <sup>$</sup>
  100
  <sup>00</sup>
</div>
<div class="chi-price -md">
  <sup>$</sup>
  100
  <sup>00</sup>
</div>
<div class="chi-price -lg">
  <sup>$</sup>
  100
  <sup>00</sup>
</div>`};return(c,l)=>{const n=u,o=d;return m(),_(o,{title:"Sizes",id:"sizes",padding:"-p--0"},{example:p(()=>[...l[0]||(l[0]=[e("div",{class:"-p--3"},[e("p",{class:"-text--bold -mb--3"},"sm"),e("chi-price",{value:"100",size:"sm"}),e("p",{class:"-text--bold -mb--3"},"md"),e("chi-price",{value:"100",size:"md"}),e("p",{class:"-text--bold -mb--3"},"lg"),e("chi-price",{value:"100",size:"lg"})],-1)])]),"code-webcomponent":p(()=>[t(n,{class:"html",lang:"html",code:s.webcomponent},null,8,["code"])]),"code-htmlblueprint":p(()=>[t(n,{class:"html",lang:"html",code:s.htmlblueprint},null,8,["code"])]),_:1})}}}),z=i({__name:"index",setup(a){return(s,c)=>(m(),h("div",null,[c[0]||(c[0]=e("h2",null,"Examples",-1)),c[1]||(c[1]=e("p",{class:"-text"},[r("To render price, use "),e("code",null,"chi-price"),r(" web component.")],-1)),t(b),t(v)]))}});export{z as _};
