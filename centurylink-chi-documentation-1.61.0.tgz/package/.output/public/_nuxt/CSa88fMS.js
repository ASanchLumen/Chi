import{aP as h,ap as o,aQ as I,aR as _,aS as v,aT as x,aU as S,an as a,aL as b,aV as P,as as L,aG as T,aH as f}from"./DBXeQHmC.js";const N=e=>({row:["inline-label","inline-label-percentage","inline-label-grid"].includes(e)?` ${S}`:"",grid:e==="inline-label-grid"?` ${v} ${x}`:"",inline:e==="inline-input"?` ${I} ${_}`:"",percentage:e==="inline-label-percentage"?`${o.SIZING.W50}`:"",gridLabel:e==="inline-label-grid"?`${h} ${o.SIZING.W3}`:"",gridInput:e==="inline-label-grid"?`${h} ${o.SIZING.W9}`:""}),z=(e,n)=>[`id="${n}"`,a("helper-message",e.helperMessageText,!!e.helperMessage),a("state","danger",!!e.error),a("helper-message",e.errorText,!!e.error),a("icon-left",e.leftIconName,!!e.leftIcon),a("icon-right",e.rightIconName,!!e.rightIcon)].filter(Boolean),y=(e,n,l)=>{const r=[`for="${n}"`,l.percentage||l.gridLabel?`class="${l.percentage}${l.gridLabel}"`:"",a("size",e.labelSize,e.labelSize!=="md"),a("required",!0,!!e.required),a("info-icon",!0,!!e.helpIcon),a("info-icon-message",e.helpIconText,!!e.helpIcon),a("optional",!0,!!e.optional)].filter(Boolean),i=f(r,4,2),s=r.length>3?"  ":"",t=$=>r.length>3?`
`+" ".repeat($):"";return`<chi-label${i}${s}>${t(3)}${e.label}${t(2)}</chi-label>`},G=e=>e.floatingLabel?`<div class="${b.INPUT_WRAPPER} ${P}">
  <input class="${b.INPUT} ${L[e?.floatingSize?.toUpperCase()||""]}" type="text" id="floating-label"/>
  <label for="floating-label">${e.placeholder}</label>
</div>`:null,W=(e,n)=>{const l=n.dynamicComputedProps,r="example_id",i=N(l?.layout??""),s=z(l,r),t=y(l,r,i),$=G(l),c=[i.percentage,i.gridInput].filter(Boolean).join(" "),m=[...s,c?`class="${c}"`:""],d=T(n,m),p=f(d,4,2),u=d.length>3?"  ":"";let g=$||`<div class="chi-form__item${i.row}${i.grid}">
  ${t}
  <${e}${p}${u}></${e}>
</div>`;return l.layout==="inline-input"&&(g=`<div class="${o.DISPLAY.FLEX}">
  <div class="chi-form__item${i.row}${i.grid}${i.inline}">
    ${t}
    <${e}${p}></${e}>
  </div>
  <div class="chi-form__item${i.row}${i.grid}${i.inline}">
    <chi-label for="example_id_2">Label Text</chi-label>
    <${e} placeholder="Placeholder Text" size="md" id="example_id_2"></${e}>
  </div>
</div>`),g};export{W as snippet};
