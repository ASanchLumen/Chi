import{_}from"./DnPF01B5.js";import{_ as u}from"./CdcsEwU-.js";import{e as d,i as w,o as r,w as o,b as c,a as t,k as h,d as l,c as x,F as O}from"./DBXeQHmC.js";const S=["items"],C=`<chi-dropdown-select id="example__base" button="Dropdown, click me"></chi-dropdown-select>

<script>
  const dropdownSelectBase = document.getElementById('example__base');

  dropdownSelectBase.items = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
    { label: 'Option 4' },
    { label: 'Option 5' }
  ];
<\/script>`,y=d({__name:"_base",setup(b){const p=[{active:!0,id:"webcomponent",label:"Web Component"},{disabled:!0,id:"htmlblueprint",label:"HTML Blueprint"}],n=Array.from({length:5},(i,e)=>({label:`Option ${e+1}`})),s={webcomponent:C,htmlblueprint:""};return(i,e)=>{const m=_,a=u;return r(),w(a,{title:"Base",id:"base",tabs:p},{example:o(()=>[t("chi-dropdown-select",{button:"Dropdown, click me",items:h(n)},null,8,S)]),"code-webcomponent":o(()=>[c(m,{class:"html",lang:"html",code:s.webcomponent},null,8,["code"])]),_:1})}}}),$=["items"],f=`<chi-dropdown-select id="example__multiple" button="Dropdown, click me" multiple></chi-dropdown-select>

<script>
  const dropdownSelectMultiple = document.getElementById('example__multiple');

  dropdownSelectMultiple.items = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
    { label: 'Option 4' },
    { label: 'Option 5' }
  ];
<\/script>`,B=d({__name:"_multiple",setup(b){const p=[{active:!0,id:"webcomponent",label:"Web Component"},{disabled:!0,id:"htmlblueprint",label:"HTML Blueprint"}],n=Array.from({length:5},(i,e)=>({label:`Option ${e+1}`})),s={webcomponent:f,htmlblueprint:""};return(i,e)=>{const m=_,a=u;return r(),w(a,{title:"Multiple",id:"multiple",tabs:p},{"example-description":o(()=>[...e[0]||(e[0]=[t("p",{class:"-text"},[l("Add the the "),t("code",null,"multiple"),l(" property to allow multiple selections.")],-1)])]),example:o(()=>[t("chi-dropdown-select",{button:"Dropdown, click me",items:h(n),multiple:""},null,8,$)]),"code-webcomponent":o(()=>[c(m,{class:"html",lang:"html",code:s.webcomponent},null,8,["code"])]),_:1})}}}),g=["items"],k=`<chi-dropdown-select id="example__search" button="Dropdown, click me" search></chi-dropdown-select>

<script>
  const dropdownSelectSearch = document.getElementById('example__search');

  dropdownSelectSearch.items = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
    { label: 'Option 4' },
    { label: 'Option 5' }
  ];
<\/script>`,v=d({__name:"_search",setup(b){const p=[{active:!0,id:"webcomponent",label:"Web Component"},{disabled:!0,id:"htmlblueprint",label:"HTML Blueprint"}],n=Array.from({length:5},(i,e)=>({label:`Option ${e+1}`})),s={webcomponent:k,htmlblueprint:""};return(i,e)=>{const m=_,a=u;return r(),w(a,{title:"Search input",id:"search",tabs:p},{"example-description":o(()=>[...e[0]||(e[0]=[t("p",{class:"-text"},[l("Add the the "),t("code",null,"search"),l(" property to display a search input.")],-1)])]),example:o(()=>[t("chi-dropdown-select",{button:"Dropdown, click me",items:h(n),search:""},null,8,g)]),"code-webcomponent":o(()=>[c(m,{class:"html",lang:"html",code:s.webcomponent},null,8,["code"])]),_:1})}}}),D=["items"],E=`<chi-dropdown-select
  id="example__show-selected"
  button="Dropdown, click me"
  multiple
  show-selected
></chi-dropdown-select>

<script>
  const dropdownSelectShowSelected = document.getElementById('example__show-selected');

  dropdownSelectShowSelected.items = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
    { label: 'Option 4' },
    { label: 'Option 5' }
  ];
<\/script>`,I=d({__name:"_show_selected",setup(b){const p=[{active:!0,id:"webcomponent",label:"Web Component"},{disabled:!0,id:"htmlblueprint",label:"HTML Blueprint"}],n=Array.from({length:5},(i,e)=>({label:`Option ${e+1}`})),s={webcomponent:E,htmlblueprint:""};return(i,e)=>{const m=_,a=u;return r(),w(a,{title:"Show selected",id:"showSelected",tabs:p},{"example-description":o(()=>[...e[0]||(e[0]=[t("p",{class:"-text"},[l("Use "),t("code",null,"multiple"),l(" and "),t("code",null,"show-selected"),l(" properties to display a checkbox that can limit the visible elements to only the ones selected.")],-1)])]),example:o(()=>[t("chi-dropdown-select",{button:"Dropdown, click me",items:h(n),multiple:"","show-selected":""},null,8,D)]),"code-webcomponent":o(()=>[c(m,{class:"html",lang:"html",code:s.webcomponent},null,8,["code"])]),_:1})}}}),T=["items"],A=`<chi-dropdown-select id="example__visible-items" button="Dropdown, click me" visible-items="5"></chi-dropdown-select>

<script>
  const dropdownSelectVisibleItems = document.getElementById('example__visible-items');

  dropdownSelectVisibleItems.items = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
    { label: 'Option 4' },
    { label: 'Option 5' },
    { label: 'Option 6' },
    { label: 'Option 7' },
    { label: 'Option 8' },
    { label: 'Option 9' },
    { label: 'Option 10' }
  ];
<\/script>`,M=d({__name:"_visible_items",setup(b){const p=[{active:!0,id:"webcomponent",label:"Web Component"},{disabled:!0,id:"htmlblueprint",label:"HTML Blueprint"}],n=Array.from({length:10},(i,e)=>({label:`Option ${e+1}`})),s={webcomponent:A,htmlblueprint:""};return(i,e)=>{const m=_,a=u;return r(),w(a,{title:"Visible items",id:"visible",tabs:p},{"example-description":o(()=>[...e[0]||(e[0]=[t("p",{class:"-text"},[l("Add the the "),t("code",null,"visible-items"),l(" property to limit the amount of visible items in the component.")],-1)])]),example:o(()=>[t("chi-dropdown-select",{button:"Dropdown, click me",items:h(n),"visible-items":"5"},null,8,T)]),"code-webcomponent":o(()=>[c(m,{class:"html",lang:"html",code:s.webcomponent},null,8,["code"])]),_:1})}}}),W=d({__name:"index",setup(b){return(p,n)=>(r(),x(O,null,[n[0]||(n[0]=t("div",null,[t("h2",null,"Examples"),t("p",{class:"-text"},[l("To render the dropdown select, use the web component "),t("code",null,"dropdown-select"),l(".")])],-1)),c(y),c(B),c(I),c(v),c(M)],64))}});export{W as _};
